package _adrian.graphics;

import java.awt.Graphics;
import java.util.TreeMap;
import animal.graphics.PTText;

public class PTDFS {
  
  public static final String TYPE_LABEL = "DFS";

  PTGraph                  graph;
  TreeMap<PTNode, Integer> color;
  TreeMap<PTNode, Integer> f;
  TreeMap<PTNode, Integer> d;
  int                      time;

  public PTDFS(PTGraph graph) {
    this.graph = graph;
    dfs();
  }

  public void dfs() {
    color = new TreeMap<PTNode, Integer>();
    f = new TreeMap<PTNode, Integer>();
    d = new TreeMap<PTNode, Integer>();
    for (PTNode nodes : graph.getGraphNodes()) {
      color.put(nodes, 0);
    }
    time = 0;
    for (PTNode nodes : color.keySet()) {
      if (color.get(nodes) == 0)
        dfsVisit(nodes);
    }
  }

  private void dfsVisit(PTNode nodes) {
    color.put(nodes, 1);
    time += 1;
    d.put(nodes, time);
    for (PTNode succs : nodes.getSuccessors().keySet()) {
      if (color.get(succs) == 0)
        dfsVisit(succs);
    }
    color.put(nodes, 2);
//    time += 1;
//    f.put(nodes, time);
  }

  public void paint(Graphics g, int dfsDrawX, int dfsDrawY) {
    String[] dfs = new String[d.keySet().size()];
    for(PTNode n : d.keySet()){
      dfs[d.get(n)-1]=n.getName();
    }
    for(int i=0;i<dfs.length;i++){
      PTText tmp = new PTText();
      int pos = i+1;
      tmp.setText(pos+". "+dfs[i]);
      tmp.setPosition(dfsDrawX, dfsDrawY+i*13);
      tmp.paint(g);
    }
  }

}
