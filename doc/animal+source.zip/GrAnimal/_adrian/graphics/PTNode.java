package _adrian.graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import animal.graphics.PTArc;
import animal.graphics.PTCircle;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTLine;
import animal.graphics.PTPoint;
import animal.graphics.PTText;
import animal.graphics.meta.ImmediateTextContainer;
import _adrian.GraphDrawing.Bezier;
import _adrian.GraphInterfaces.INodeOperations;
import _adrian.exceptions.SuccessorDoesntExists;

public class PTNode extends PTGraphicObject implements ImmediateTextContainer,
    INodeOperations<PTNode> {

  public static final String       TYPE_LABEL = "Node";

  private String                   nodeName;
  private int                      x, y, drawx, drawy;
  private double                   force      = 0;
  private double                   forceX     = 0;
  private double                   forceY     = 0;
  private TreeMap<PTNode, Integer> successors = new TreeMap<PTNode, Integer>();
  private int                      radius     = 8;
  private boolean                  isMarked   = false;
  private LinkedList<PTNode>       markedEdgesTo;
  private Color                    nodeTextColor, edgeTextColor, nodeFillColor,
      edgeColor, markNodeTextColor, markEdgeTextColor, markNodeColor,
      markEdgeColor;
  private boolean                  isDirected, isDrawn = false;
  
  private LinkedList<PTNode> addedEdges = new LinkedList<PTNode>();

  /**
   * Sets the color settings. Expects an array with size 8, where 1.
   * NodeTextcolor 2. EdgeTextColor 3. NodeFillColor 4. EdgeColor 5.
   * MarkNodeTextColor 6. MarkEdgeTextColor 7. MarkNodeColor 8. MarkEdgeColor
   * 
   * @param definitions
   */

  /**
   * Sets the node name to the given parameter and the coordinates to 0;
   * 
   * @param name
   */
  public PTNode(String name) {
    nodeName = name;
    x = y = 0;
    setDefaultColorSettings();
  }

  /**
   * Sets the node name to the given parameter. Also sets the coordinates to the
   * given parameters.
   * 
   * @param name
   * @param x
   * @param y
   */
  public PTNode(String name, int x, int y) {
    nodeName = name;
    this.x = x;
    this.y = y;
    setDefaultColorSettings();
  }

  private void setDefaultColorSettings() {
    nodeTextColor = Color.white;
    edgeTextColor = Color.green;
    nodeFillColor = Color.black;
    edgeColor = Color.green;
    markNodeTextColor = Color.black;
    markEdgeTextColor = Color.pink;
    markNodeColor = Color.yellow;
    markEdgeColor = Color.PINK;
  }

  public boolean addSuccessor(PTNode succ) {
    if (isSuccessor(succ))
      return false;
    else {
      successors.put(succ, 0);
      return true;
    }
  }

  public boolean addSuccessor(PTNode succ, int weigth) {
    if (isSuccessor(succ))
      return false;
    else {
      successors.put(succ, weigth);
      return true;
    }
  }

  public boolean isSuccessor(PTNode node) {
    for (PTNode s : successors.keySet()) {
      if (s.compareTo(node) == 0)
        return true;
    }
    return false;
  }

  public boolean removeSuccessor(PTNode succ) {
    for (PTNode s : successors.keySet()) {
      if (s.compareTo(succ) == 0) {
        successors.remove(s);
        return true;
      }
    }
    return false;
  }

  public String getName() {
    return nodeName;
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public void setName(String name) {
    nodeName = name;
  }

  public void setX(int x) {
    this.x = x;
  }

  public void setY(int y) {
    this.y = y;
  }

  /**
   * Compares the given node with current node and returns a difference value.
   */
  public int compareTo(PTNode o) {
    return getName().compareTo(o.getName());
  }

  public int getWeigth(PTNode succ) throws SuccessorDoesntExists {
    for (PTNode s : successors.keySet()) {
      if (s.compareTo(succ) == 0) {
        return successors.get(s);
      }
    }
    throw new SuccessorDoesntExists(this, succ);
  }

  public Map<PTNode, Integer> getSuccessors() {
    return successors;
  }

  @Override
  public Rectangle getBoundingBox() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String getType() {
    return TYPE_LABEL;
  }

  @Override
  public String[] handledKeywords() {
    return new String[] { "Node" };
  }

  @Override
  public void paint(Graphics g) {
    PTCircle node = new PTCircle();
    if (isMarkedNode())
      node.setFillColor(markNodeColor);
    else
      node.setFillColor(nodeFillColor);
    node.setCenter(x, y);
    node.setRadius(radius);
    node.paint(g);
    PTText nodeNameText = new PTText();
    nodeNameText.setText(nodeName);
    nodeNameText.setPosition(x - radius / 2, y + radius / 2);
    if (isMarkedNode())
      nodeNameText.setColor(markNodeTextColor);
    else
      nodeNameText.setColor(nodeTextColor);
    nodeNameText.paint(g);
    for (PTNode succs : getSuccessors().keySet()) {
      drawConnectionBetweenNodes(successors.get(succs), succs.getX(),
          succs.getY(), x - succs.getX(), y - succs.getY(), g,
          isMarkedEdgeToNode(succs));
    }
  }

  public void paint(Graphics g, int marginLeft, int marginTop,
      boolean isDirected) {
    this.isDirected = isDirected;
    PTCircle node = new PTCircle();
    if (isMarkedNode())
      node.setFillColor(markNodeColor);
    else
      node.setFillColor(nodeFillColor);
    drawx = x + marginLeft;
    drawy = y + marginTop;
    node.setCenter(drawx, drawy);
    node.setRadius(radius);
    node.paint(g);
    PTText nodeNameText = new PTText();
    nodeNameText.setText(nodeName);
    nodeNameText.setPosition(drawx - radius / 2, drawy + radius / 2);
    if (isMarkedNode())
      nodeNameText.setColor(markNodeTextColor);
    else
      nodeNameText.setColor(nodeTextColor);
    nodeNameText.paint(g);
    for (PTNode succs : getSuccessors().keySet()) {
      // draw just one line if graph is not directed
      if (!isDirected) {
        if(!isAddedEdgeTo(succs) && !succs.isAddedEdgeTo(this)){
          drawConnectionBetweenNodes(successors.get(succs), succs.getX()
              + marginLeft, succs.getY() + marginTop, drawx
              - (succs.getX() + marginLeft),
              drawy - (succs.getY() + marginTop), g, isMarkedEdgeToNode(succs));
          addEdgeTo(succs);
          succs.addEdgeTo(this);
        }
      } else {
        drawConnectionBetweenNodes(successors.get(succs), succs.getX()
            + marginLeft, succs.getY() + marginTop, drawx
            - (succs.getX() + marginLeft), drawy - (succs.getY() + marginTop),
            g, isMarkedEdgeToNode(succs));
      }
    }
  }

  private void drawConnectionBetweenNodes(int weigth, int succX, int succY,
      int deltaX, int deltaY, Graphics g, boolean isMarked) {
    if (succX == drawx && succY == drawy) {
      PTArc arc = new PTArc();
      arc.setRadius(10);
      arc.setCenter(drawx-10-radius, drawy);
      arc.setFWArrow(true);
      arc.setCircle(true);
      arc.setFilled(false);
      arc.setTotalAngle(359);
      if (isMarked)
        arc.setColor(markEdgeColor);
      else
        arc.setColor(edgeColor);
      arc.paint(g);
      drawArrowDescription(weigth, drawx-radius-10, drawy-12, g, isMarked);
    } else {
      double euklid = Math.sqrt(Math.pow((drawx - succX), 2)
          + Math.pow((drawy - succY), 2));
      double cos = (succX - drawx) / euklid;
      double sin = (succY - drawy) / euklid;
      double acos = Math.toDegrees(Math.acos(cos));
      acos = (succY <= drawy) ? acos : 360.0 - acos; // Anpassung an Quadranten
      acos += 45; // weitere Drehung um 45 Grad
      acos = (acos > 360) ? 360 - acos : acos; // das Bogenmass
      acos = Math.toRadians(acos);
      cos = Math.cos(acos); // neuer Punkt x-coordinate
      sin = Math.sin(acos); // neuer Punkt y-coordinate
      euklid = euklid / 1.75; // je groesser der Nenner, desto kleiner der
                              // Boogen
      int bezierX = (int) ((cos * euklid) + drawx);
      int bezierY = (int) (drawy - (sin * euklid));
      Bezier bezier = new Bezier(new Point(drawx, drawy), new Point(bezierX,
          bezierY), new Point(bezierX, bezierY), new Point(succX, succY));
      int[][] points = bezier.bezier();
      // System.out.println(drawx + " " + drawy + " " + succX + " " + succY +
      // " "
      // + " " + bezierX + " " + bezierY);
      int border = points.length / (radius*8);
      for (int i = border; i < points.length - border; i++) {
        PTPoint tmp = new PTPoint(points[i][0], points[i][1]);
        if (isMarked)
          tmp.setColor(markEdgeColor);
        else
          tmp.setColor(edgeColor);
        tmp.paint(g);
      }
      if ((succX != drawx || drawy != succY) && isDirected) {
        int diff = points.length - (radius * 5);
        diff = (diff < 0) ? 0 : diff;
        int end = (diff+radius*4 > points.length) ? points.length-1 : diff+radius*4;
        PTLine line = new PTLine(points[diff][0], points[diff][1],
            points[end][0],
            points[end][1]);
        line.setFWArrow(true);
        if (isMarked)
          line.setColor(markEdgeColor);
        else
          line.setColor(edgeColor);
        line.paint(g);
      }
      int half = points.length / 2;
      if (half > 0) {
        euklid = euklid * 1.25; // je groesser der Nenner, desto kleiner der
                                // Bogen
        int bx = (int) ((cos * euklid) + drawx);
        int by = (int) (drawy - (sin * euklid));
        Bezier bezierDesc = new Bezier(new Point(drawx, drawy), new Point(bx,
            by), new Point(bx, by), new Point(succX, succY));
        int[][] points2 = bezierDesc.bezier();
        drawArrowDescription(weigth, points2[half][0], points2[half][1], g,isMarked);
      }
    }
  }

  private void drawArrowDescription(int weigth, int x, int y, Graphics g,
      boolean isMarked) {
    PTText weigthName = new PTText();
    if(weigth == Integer.MAX_VALUE){
      char t = (char) 8734; //unicode for infinity symbol
      String t2 = String.valueOf(t);
      weigthName.setText(t2);
    }
    else
      weigthName.setText(String.valueOf(weigth));
    weigthName.setPosition(x, y);
    if (isMarked)
      weigthName.setColor(markEdgeTextColor);
    else
      weigthName.setColor(edgeTextColor);
    weigthName.paint(g);
  }

  @Override
  public void translate(int deltaX, int deltaY) {
    // TODO Auto-generated method stub

  }

  @Override
  public String getText() {
    return getName();
  }

  @Override
  public void setText(String targetText) {
    setName(targetText);
  }

  @Override
  public Font getFont() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void setFont(Font targetFont) {
    // TODO Auto-generated method stub
  }

  @Override
  public void addForce(double force) {
    this.force += force;
  }

  @Override
  public double getForce() {
    return force;
  }

  @Override
  public void setForce(double force) {
    this.force = force;
  }

  @Override
  public boolean isMarkedNode() {
    return isMarked;
  }

  @Override
  public void markNode() {
    isMarked = true;
  }

  @Override
  public void unmarkNode() {
    isMarked = false;
  }

  @Override
  public boolean isMarkedEdgeToNode(PTNode node) {
    if (markedEdgesTo != null) {
      return markedEdgesTo.contains(node);
    }
    return false;
  }

  @Override
  public void markEdgeToNode(PTNode node) {
    if (markedEdgesTo == null)
      markedEdgesTo = new LinkedList<PTNode>();
    if (!markedEdgesTo.contains(node))
      markedEdgesTo.add(node);
  }

  @Override
  public void unmarkEdgeToNode(PTNode node) {
    if (markedEdgesTo != null)
      markedEdgesTo.remove(node);
  }

  @Override
  public Color getEdgeColor() {
    return edgeColor;
  }

  @Override
  public Color getEdgeTextColor() {
    return edgeTextColor;
  }

  @Override
  public Color getMarkEdgeColor() {
    return markEdgeColor;
  }

  @Override
  public Color getMarkEdgeTextColor() {
    return markEdgeTextColor;
  }

  @Override
  public Color getMarkNodeColor() {
    return markNodeColor;
  }

  @Override
  public Color getMarkNodeTextColor() {
    return markNodeTextColor;
  }

  @Override
  public Color getNodeFillColor() {
    return nodeFillColor;
  }

  @Override
  public Color getNodeTextColor() {
    return nodeTextColor;
  }

  @Override
  public void setEdgeColor(Color col) {
    edgeColor = col;
  }

  @Override
  public void setEdgeTextColor(Color col) {
    edgeTextColor = col;
  }

  @Override
  public void setMarkEdgeColor(Color col) {
    markEdgeColor = col;
  }

  @Override
  public void setMarkEdgeTextColor(Color col) {
    markEdgeColor = col;
  }

  @Override
  public void setMarkNodeColor(Color col) {
    markNodeColor = col;
  }

  @Override
  public void setMarkNodeTextColor(Color col) {
    markNodeTextColor = col;
  }

  @Override
  public void setNodeFillColor(Color col) {
    nodeFillColor = col;
  }

  @Override
  public void setNodeTextColor(Color col) {
    nodeTextColor = col;
  }

  @Override
  public void setWeigth(PTNode succ, int weigth) throws SuccessorDoesntExists {
    boolean isSucc = false;
    for (PTNode s : successors.keySet()) {
      if (s.compareTo(succ) == 0) {
        successors.remove(s);
        successors.put(s, weigth);
        isSucc = true;
      }
    }
    if (!isSucc)
      throw new SuccessorDoesntExists(this, succ);
  }

  @Override
  public void addForceX(double force) {
    forceX += force;
  }

  @Override
  public void addForceY(double force) {
    forceY += force;
  }

  @Override
  public double getForceX() {
    return forceX;
  }

  @Override
  public double getForceY() {
    return forceY;
  }

  @Override
  public void setForceX(double force) {
    forceX = force;
  }

  @Override
  public void setForceY(double force) {
    forceY = force;
  }

  @Override
  public void addEdgeTo(PTNode succ) {
    addedEdges.add(succ);
  }

  @Override
  public boolean isAddedEdgeTo(PTNode isAdded) {
    for(PTNode node : addedEdges){
      if(isAdded.compareTo(node)==0)
        return true;
    }
    return false;
  }

  @Override
  public void resetEdgesTo() {
    addedEdges = new LinkedList<PTNode>();
  }
}
