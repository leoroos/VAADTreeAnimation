package _adrian.graphics;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.List;
import animal.graphics.PTGraphicObject;
import _adrian.GraphInterfaces.IGraph;
import _adrian.exceptions.NodeDoesntExists;

public class PTGraph extends PTGraphicObject implements IGraph<PTNode>{

	public static final String TYPE_LABEL = "Graph";

	private LinkedList<PTNode> nodes = new LinkedList<PTNode>();
	private boolean isDirected = false, dfsDraw = false;
	private int width = 500, height = 500, margin_left = 0, margin_top = 0;
	private int dfsDrawX, dfsDrawY;
	
	public PTGraph(boolean isDirected){
		this.isDirected = isDirected;
	}
	
	public PTGraph(boolean isDirected, int width, int height){
		this.isDirected = isDirected;
		this.width = width;
		this.height = height;
	}

	public PTGraph(boolean isDirected, int width, int height, int margin_left, int margin_top) {
	  this.isDirected = isDirected;
    this.width = width;
    this.height = height;
    this.margin_left = margin_left;
    this.margin_top = margin_top;
	}

	public boolean addNode(PTNode nodeToAdd) {
		if (isNode(nodeToAdd))
			return false;
		nodes.add(nodeToAdd);
		return true;
	}

	public List<PTNode> getGraphNodes() {
		return nodes;
	}

	public boolean removeNode(PTNode nodeToRemove) {
		PTNode remove = null;
		for (PTNode k : nodes) {
			if (k.compareTo(nodeToRemove) == 0)
				remove = k;
			k.removeSuccessor(nodeToRemove);
		}
		if (remove != null) {
			nodes.remove(remove);
			return true;
		} else
			return false;
	}

	public boolean isNode(PTNode node) {
		for (PTNode k : nodes) {
			if (k.compareTo(node) == 0)
				return true;
		}
		return false;
	}

	public PTNode getNode(PTNode node) throws NodeDoesntExists {
		for (PTNode k : nodes) {
			if (k.compareTo(node) == 0)
				return k;
		}
		throw new NodeDoesntExists((PTNode) node);
	}

	public PTNode getNode(String node) throws NodeDoesntExists {
		return getNode(new PTNode(node));
	}

	@Override
	public String toString() {
		String graph = "";
		for (PTNode k : nodes) {
			graph += k.getName() + " x: " + k.getX() + " y: " + k.getY();
			graph += " Successors: ";
			for (PTNode succNode : k.getSuccessors().keySet()) {
				graph += "\t" + succNode.getName() + " (" + /*
															 * getEuclideanDistance(
															 * k, succNode) +
															 */")";
			}
			graph += "\n";
		}
		return graph;
	}

	@Override
	public Rectangle getBoundingBox() {
		return new Rectangle(margin_left, margin_top, width, height);
	}

	@Override
	public String getType() {
		return TYPE_LABEL;
	}

	@Override
	public String[] handledKeywords() {
		return new String[] { "Graph" };
	}

	@Override
	public void paint(Graphics g) {
	  for (PTNode node : nodes) {
      node.resetEdgesTo();
    }
		for (PTNode node : nodes) {
			node.paint(g,margin_left,margin_top,isDirected());
		}
		if(dfsDraw){
		  PTDFS dfs = new PTDFS(this);
		  dfs.paint(g, dfsDrawX, dfsDrawY);
		}
	}

	@Override
	public void translate(int deltaX, int deltaY) {
		// TODO Auto-generated method stub

	}

	@Override
	public void replaceNodes(List<PTNode> nodes) {
		for(int i=0;i<this.nodes.size();i++){
		  nodes.get(i).setEdgeColor(this.nodes.get(i).getEdgeColor());
		  nodes.get(i).setEdgeTextColor(this.nodes.get(i).getEdgeTextColor());
		  nodes.get(i).setMarkEdgeColor(this.nodes.get(i).getMarkEdgeColor());
		  nodes.get(i).setMarkEdgeTextColor(this.nodes.get(i).getMarkEdgeTextColor());
		  nodes.get(i).setNodeFillColor(this.nodes.get(i).getNodeFillColor());
		  nodes.get(i).setNodeTextColor(this.nodes.get(i).getNodeTextColor());
		  nodes.get(i).setMarkNodeColor(this.nodes.get(i).getMarkNodeColor());
		  nodes.get(i).setMarkNodeTextColor(this.nodes.get(i).getMarkNodeTextColor());
		  this.nodes = (LinkedList<PTNode>) nodes;
		}
	}

	@Override
	public boolean isDirected() {
		return isDirected;
	}

	@Override
	public int getHeight() {
		return width;
	}

	@Override
	public int getWidth() {
		return height;
	}

	@Override
	public int getMarginLeft() {
		return margin_left;
	}

	@Override
	public int getMarginTop() {
		return margin_top;
	}

  @Override
  public void drawDFS(int x, int y) {
    dfsDraw = true;
    dfsDrawX = x;
    dfsDrawY = y;
  }

}
