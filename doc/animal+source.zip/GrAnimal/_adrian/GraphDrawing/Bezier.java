package _adrian.GraphDrawing;

import java.awt.Point;

public class Bezier {
  
  Point p0, p1, p2, p3;
  
  public Bezier(Point p0, Point p1, Point p2, Point p3){
    this.p0 = p0;
    this.p1 = p1;
    this.p2 = p2;
    this.p3 = p3;
  }
  
  private Point bezier(double t){
    //http://www.ullala.at/experiments/movement/bew_bez.html

    int x0 = (int) (p0.getX()*Math.pow((1-t), 3)+p1.getX()*3*t*Math.pow((1-t), 2)+p2.getX()*3*Math.pow(t, 2)*(1-t)+p3.getX()*Math.pow(t, 3));
    int y0 = (int) (p0.getY()*Math.pow((1-t), 3)+p1.getY()*3*t*Math.pow((1-t), 2)+p2.getY()*3*Math.pow(t, 2)*(1-t)+p3.getY()*Math.pow(t, 3));
    return new Point(x0,y0);
    
  }
  
  public int[][] bezier(){
    int diff = ((int) Math.max(Math.abs(p0.getX()-p3.getX()), Math.abs(p0.getY()-p3.getY())))*4; //fuelle der Linie, ohne *2 sehr duenn besetzt
    int[][] t = new int[diff][2];
    for(int i=0;i<diff;i++){
      t[i][0]=(int) bezier((double)i/diff).getX();
      t[i][1]=(int) bezier((double)i/diff).getY();
    }
    return t;
  }
  
}
