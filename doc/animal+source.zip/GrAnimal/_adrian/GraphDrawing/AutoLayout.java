package _adrian.GraphDrawing;

import java.util.List;

import _adrian.GraphInterfaces.IGraph;
import _adrian.GraphInterfaces.INodeOperations;

public class AutoLayout<K extends IGraph<T>, T extends INodeOperations<T>>
    extends IGraphDrawing<K, T> {

  private int k            = 0;  // optimal distance
  private int width        = 500;
  private int height       = 500;
  private int marginLeft   = 0;
  private int marginHeight = 0;
  private int puffer       = 0;
  private int intervals    = 100;

  public AutoLayout(int width, int height, int marginLeft, int marginHeight) {
    this.width = width;
    this.height = height;
    this.marginLeft = marginLeft;
    this.marginHeight = marginHeight;
  }

  @Override
  public List<T> computeNodePosition(List<T> graphnodes) {
    setRandomPosition(graphnodes);
    int k = computeOptimalDistance(graphnodes.size());
    System.out.println("Optimal Distance: " + k);
    for (int i = 0; i < intervals; i++) {
      checkAndFixCrossings(graphnodes);
      for (T node : graphnodes) {
        for (T other : graphnodes) {
          if (node.compareTo(other) != 0) {
            if (node.isSuccessor(other))
              doAttraction(node, other, k);
            if (other.isSuccessor(node))
              doAttraction(other, node, k);
            if (!other.isSuccessor(node) && !node.isSuccessor(other)) {
              doRepulsive(node, other, k);
            }
          }
        }
      }
    }

    return graphnodes;
  }

  private void checkAndFixCrossings(List<T> graphnodes) {
    // check this node if is on the same line between other nodes
    for (T node : graphnodes) {
      for (T other : graphnodes) {
        if (node.compareTo(other) != 0 && !other.isSuccessor(node)) {
          for (T succ : other.getSuccessors().keySet()) {
            if (sameline(node, other, succ, true)
                && isBetween(node, other, succ, true)) {
              // TODO: some other workaround
              node.setX((int) (node.getX() + 50 * Math.random()));
            }
            if (sameline(node, other, succ, false)
                && isBetween(node, other, succ, false)) {
              node.setY((int) (node.getY() + 50 * Math.random()));
            }
          }
        }
      }
    }
  }

  private boolean isBetween(T node, T other, T succ, boolean b) {
    if (!b) {
      if ((node.getX() >= other.getX()) && node.getX() <= succ.getX())
        return true;
      else if ((node.getX() <= other.getX()) && node.getX() >= succ.getX())
        return true;
      return false;
    } else {
      if ((node.getY() >= other.getY()) && node.getY() <= succ.getY())
        return true;
      else if ((node.getY() <= other.getY()) && node.getY() >= succ.getY())
        return true;
      return false;
    }
  }

  private boolean sameline(T n1, T n2, T n3, boolean x) {
    if (x)
      return (n1.getX() == n2.getX()) && (n2.getX() == n3.getX());
    else
      return (n1.getY() == n2.getY()) && (n2.getY() == n3.getY());
  }

  private void doRepulsive(T node, T other, int k2) {
    int i = 0;
    while (getEuclideanDistance(node, other) < k2 - puffer) {
      if (i == 0) {
        int x = (other.getX() - node.getX());
        node.setX(node.getX() - x);
        i = 1;
      } else {
        int y = (other.getY() - node.getY());
        node.setY(node.getY() - y);
        i = 0;
      }
    }
    // if (getEuclideanDistance(node, other) < k2 - puffer) {
    // int x = (other.getX() - node.getX());
    // node.setX(node.getX() - x);
    // }
    // if (getEuclideanDistance(node, other) < k2 - puffer) {
    // int y = (other.getY() - node.getY());
    // node.setY(node.getY() - y);
    // }
    // if (node.getX() < other.getX()) {
    // int x = (other.getX() - node.getX());
    // node.setX(node.getX() - x);
    // // other.setX(other.getX() + x);
    // } else {
    // int x = (node.getX() - other.getX());
    // node.setX(node.getX() + x);
    // // other.setX(other.getX() - x);
    // }
    // if (node.getY() < other.getY()) {
    // int y = (other.getY() - node.getY());
    // node.setY(node.getY() - y);
    // // other.setY(other.getY() + y);
    // } else {
    // int y = (node.getY() - other.getY());
    // node.setY(node.getY() + y);
    // // other.setY(other.getY() - y);
    // }
    handleOutOfBorder(node);
    handleOutOfBorder(other);
    // }
  }

  private void doAttraction(T node, T succ, int k) {
    if (getEuclideanDistance(node, succ) > k + puffer) {
      succ.setX((succ.getX() + node.getX()) / 8);
      succ.setY((succ.getY() + node.getY()) / 8);
    }
  }

  @Override
  public double getEuclideanDistance(T n1, T n2) {
    return Math.sqrt(Math.pow((n1.getX() - n2.getX()), 2)
        + Math.pow((n1.getY() - n2.getY()), 2));
  }

  private int computeOptimalDistance(int numberOfNodes) {
    return (int) (Math.sqrt((width * height)) / numberOfNodes);
  }

  private void setRandomPosition(List<T> graphnodes) {
    // for (T node : graphnodes) {
    // node.setX((int) (((Math.random() * 1000) % width) + marginLeft));
    // node.setY((int) (((Math.random() * 1000) % height) + marginHeight));
    // }
    int i = 0;
    int j = 0;
    int k = computeOptimalDistance(graphnodes.size());
    for (T n : graphnodes) {
      n.setX(i * k);
      n.setY(j * k);
      if ((i + 1) * k <= width)
        i += 1;
      else {
        i = 0;
        j += 1;
      }
    }
  }

  private void handleOutOfBorder(T node) {
    if (node.getX() > width)
      node.setX((width - (node.getX() - width)) + marginLeft);
    else if (node.getX() < 0)
      node.setX((-1 * node.getX()) + marginLeft);

    if (node.getY() > height)
      node.setY((height - (node.getY() - height)) + marginHeight);
    if (node.getY() < 0)
      node.setY((-1 * node.getY()) + marginHeight);
  }

}
