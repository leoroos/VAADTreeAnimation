package _adrian.GraphDrawing;

import java.util.List;
import _adrian.GraphInterfaces.IGraph;
import _adrian.GraphInterfaces.INodeOperations;

/**
 * Calculates the coordinations of the nodes for the given Graph
 * 
 * @author adrian
 * 
 */
public class FruchtermanReingold<K extends IGraph<T>, T extends INodeOperations<T>>
		extends IGraphDrawing<K, T> {

	private final int ITERATIONS = 200;
	private final double EPSILON = 2.0;
	private int DESIRED_DISTANCE = 200; // optimal distance
	private int DRAWING_SIZE_X = 500;
	private int DRAWING_SIZE_Y = 500;
	private int    k            = 0;  

	public FruchtermanReingold(int boardSize_x, int boardSize_y) {
		DRAWING_SIZE_X = boardSize_x;
		DRAWING_SIZE_Y = boardSize_y;
//		System.out.println("DESIRED_DISTANCE: " + DESIRED_DISTANCE);
	}

	private int computeOptimalDistance(int size) {
		return (int) (Math.sqrt((DRAWING_SIZE_X * DRAWING_SIZE_Y)) / size);
	}

	public double getEuclideanDistance(T n1, T n2) {
		return Math.sqrt(Math.pow((n1.getX() - n2.getX()), 2)
				+ Math.pow((n1.getY() - n2.getY()), 2));
	}

	public List<T> computeNodePosition(List<T> graphnodes) {
		DESIRED_DISTANCE = computeOptimalDistance(graphnodes.size());
		setRandomPosition(graphnodes);
//		System.out.println("Desired Distance: " + DESIRED_DISTANCE);
		for (int i = ITERATIONS; i > 0; i--) {
		// for all nodes in the graph: do repulsive
			for (T n1 : graphnodes) {
				n1.setForce(0);
				for (T n2 : graphnodes) {
				  if(n1.compareTo(n2)!=0){
				    int delta_x = n1.getX() - n2.getX();
				    int delta_y = n1.getY() - n2.getY();
				    double vectorLength = getVectorLength(delta_x, delta_y);
				    n1.addForceX(delta_x/vectorLength*computeRepulsiveForce(vectorLength));
				    n1.addForceY(delta_y/vectorLength*computeRepulsiveForce(vectorLength));
				  }
				}
			}
		// for all nodes in the graph: do attractive
			for (T n1 : graphnodes) {
       for(T succ : n1.getSuccessors().keySet()){
         int delta_x = n1.getX() - succ.getX();
         int delta_y = n1.getY() - succ.getY();
         double vectorLength = getVectorLength(delta_x, delta_y);
         n1.addForceX(-1 * (delta_x/vectorLength*computeAttractionForce(vectorLength)));
         n1.addForceY(-1 * (delta_y/vectorLength*computeAttractionForce(vectorLength)));
         succ.addForceX(delta_x/vectorLength*computeAttractionForce(vectorLength));
         succ.addForceY(delta_y/vectorLength*computeAttractionForce(vectorLength));
       }
        for (T n2 : graphnodes) {
          if(n1.compareTo(n2)!=0){
            int delta_x = n1.getX() - n2.getX();
            int delta_y = n1.getY() - n2.getY();
            n1.addForceX(delta_x/getVectorLength(delta_x, delta_y)*computeRepulsiveForce(getVectorLength(delta_x, delta_y)));
          }
        }
      }
			
			for (T n1 : graphnodes) {
			  double vectorLength = getVectorLength(n1.getForceX(), n1.getForceY());
			  n1.setX((int) (n1.getX()+(n1.getForceX()/vectorLength) * Math.min(n1.getForceX(), i)));
			  n1.setY((int) (n1.getY()+(n1.getForceY()/vectorLength) * Math.min(n1.getForceY(), i)));
			  n1.setX(Math.min(DRAWING_SIZE_X/2, Math.max(-1 * DRAWING_SIZE_X/2, n1.getX())));
			  n1.setY(Math.min(DRAWING_SIZE_Y/2, Math.max(-1 * DRAWING_SIZE_Y/2, n1.getY())));
			}

//			// adding margin borders
//			for (T n1 : graphnodes) {
//				n1.setX(n1.getX());
//				n1.setY(n1.getY());
//			}
		}
		return graphnodes;
	}
	
	 private void setRandomPosition(List<T> graphnodes) {
   for (T node : graphnodes) {
     node.setX((int) (((Math.random() * 1000) % DRAWING_SIZE_X)));
     node.setY((int) (((Math.random() * 1000) % DRAWING_SIZE_Y)));
   }
//   int i=0;
//   int j=0;
//   int k = computeOptimalDistance(graphnodes.size());
//   for(T n : graphnodes){
//     n.setX(i*k);
//     n.setY(j*k);
//     if((i+1)*k <= DRAWING_SIZE_X)
//       i+=1;
//     else{
//       i=0;
//       j+=1;
//     }
 }

	private double getVectorLength(int a, int b){
	  return Math.sqrt(a*a + b*b);
	}
	
	private double getVectorLength(double a, double b){
    return Math.sqrt(a*a + b*b);
  }
	
	private double computeRepulsiveForce(double z) {
		return DESIRED_DISTANCE * DESIRED_DISTANCE / z;
	}

	private double computeAttractionForce(double z) {
		return z * z / DESIRED_DISTANCE;
	}

}
