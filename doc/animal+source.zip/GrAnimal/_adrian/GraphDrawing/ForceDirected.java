package _adrian.GraphDrawing;

import java.util.List;

import _adrian.GraphInterfaces.IGraph;
import _adrian.GraphInterfaces.INodeOperations;

public class ForceDirected<K extends IGraph<T>, T extends INodeOperations<T>>
		extends IGraphDrawing<K, T> {

	private double k = 0; // optimal distance
	private int width = 500;
	private int height = 500;
	
	public ForceDirected(int width, int height){
		this.width = width;
		this.height = height;
	}
	
	public ForceDirected(){
	}

	@Override
	public List<T> computeNodePosition(List<T> graphnodes) {
		setOptimalDistance(graphnodes.size());
		prepareNodes(graphnodes);
		for (int i = 0; i < 10; i++)
			for (T node : graphnodes) {
				node.setForce(0);
				for (T other : node.getSuccessors().keySet()) {
					if (!node.equals(other)) {
						double force = getAttractionForce(node, other)
								+ getRepulsiveForce(node, other);
						node.addForce(force);
						double m = 0;
						if (other.getX() != node.getX())
							m = (other.getY() - node.getY())
									/ (other.getX() - node.getX());
						double b = node.getY() - (m * node.getX());
						int move = (int) (force / k);
						if (node.getX() < other.getX()) {
							node.setX(node.getX() + move/2);
							node.setY((int) (node.getX() * m + b));
							other.setX(other.getX() - move/2);
							other.setY((int) (other.getX() * m + b));
						} else {
							node.setX(node.getX() - move);
							node.setY((int) (node.getX() * m + b));
							other.setX(other.getX() + move/2);
							other.setY((int) (other.getX() * m + b));
						}
						handleOutOfBorder(node);
					}
				}
			}
		for (T node : graphnodes) {
			node.setX(node.getX());
			node.setY(node.getY());
		}
		return graphnodes;
	}
	
	private void prepareNodes(List<T> graphnodes) {
		int steps = (int) Math.sqrt(graphnodes.size()) + 1;
		int index = 0;
		for (int x = 0; x < steps; x++) {
			for (int y = 0; y < steps; y++) {
				if(index < graphnodes.size()){
					graphnodes.get(index).setX(x * (width / steps));
					graphnodes.get(index).setY(y * (height / steps));
					index++;
				}
			}
		}
	}


	private void handleOutOfBorder(T node) {
		while (node.getX() > width || node.getX() < 0) {
			if (node.getX() > width)
				node.setX(width - (node.getX() - width));
			if (node.getX() < 0)
				node.setX(-1 * node.getX());
		}
		while (node.getY() > height || node.getY() < 0) {
			if (node.getY() > height)
				node.setY(height - (node.getY() - height));
			if (node.getY() < 0)
				node.setY(-1 * node.getY());
		}
	}

	@Override
	public double getEuclideanDistance(T n1, T n2) {
		return Math.sqrt(Math.pow((n1.getX() - n2.getX()), 2)
				+ Math.pow((n1.getY() - n2.getY()), 2));
	}

	private double getRepulsiveForce(T n1, T n2) {
		return -1 * Math.pow(k, 2) / getEuclideanDistance(n1, n2);
	}

	private double getAttractionForce(T n1, T n2) {
		return Math.pow(getEuclideanDistance(n1, n2), 2) / k;
	}

	private void setOptimalDistance(int nodes) {
		k = Math.sqrt(width * height / nodes);
	}

}
