package _adrian.GraphDrawing;

import java.util.List;
import _adrian.GraphInterfaces.IGraph;
import _adrian.GraphInterfaces.INodeOperations;

public class AutoDraw<K extends IGraph<T>, T extends INodeOperations<T>> extends IGraphDrawing<K, T> {
  
  private double optimalDistance = 0;
  private double attraction_constant;
  private double repulsive_constant;
  private double temperature;
  private double EPSILON = 0.000001D;
  private int marginLeft   = 0;
  private int marginHeight = 0;
  

  public AutoDraw(int boardSize_x, int boardSize_y, int marginLeft, int marginHeight){
    this.marginLeft = marginLeft;
    this.marginHeight = marginHeight;
    setDrawingSizeX(boardSize_x);
    setDrawingSizeY(boardSize_y);
  }
  
  @Override
  public List<T> computeNodePosition(List<T> graphnodes) {
    optimalDistance = getOptimalDistance(graphnodes.size());
    attraction_constant = 0.25 * optimalDistance;
    repulsive_constant = 0.25 * optimalDistance;
    temperature = getDrawingSizeX()/10;
    setRandomPosition(graphnodes);
    for (int i = 0; i < getIterations(); i++) {
        //do repulsive : nodes
        for (T n1 : graphnodes) {
          doRepulsive(n1, graphnodes);
        }
        //do attractive : edges
        for (T n1 : graphnodes){
          for(T n2 : n1.getSuccessors().keySet()){
            if(!(n1.isAddedEdgeTo(n2) || n2.isAddedEdgeTo(n1))){
              n1.addEdgeTo(n2);
              n2.addEdgeTo(n1);
              doAttractive(n1, n2, graphnodes);
            }
          }
        }
        
        // set new positions
        for(T n1 : graphnodes){
          doNewPosition(n1, graphnodes);
        }
        
       coolTemperature(i);
    }
    //setMargin
    for(T n1 : graphnodes){
      n1.setX(n1.getX()+marginLeft);
      n1.setY(n1.getY()+marginHeight);
    }
    return graphnodes;
  }
  
  private void doNewPosition(T updateNode, List<T> graphnodes) {
    
    double delta_Length = Math.max(EPSILON, Math.sqrt(updateNode.getForceX() * updateNode.getForceX() + updateNode.getForceY()*updateNode.getForceY()));
    
    double disp_x = updateNode.getForceX() /delta_Length * Math.min(delta_Length, temperature);
    double disp_y = updateNode.getForceY() /delta_Length * Math.min(delta_Length, temperature);
    
    updateNode.setX((int) (updateNode.getX()+disp_x));
    updateNode.setY((int) (updateNode.getY()+disp_y));
    
    double borderWidth = getDrawingSizeX()/50.0;
    double newXPos = updateNode.getX();
    if(newXPos < borderWidth)
      newXPos = borderWidth + Math.random() * borderWidth *2.0;
    else if(newXPos > (getDrawingSizeX() - borderWidth))
      newXPos = getDrawingSizeX() - borderWidth -Math.random() * borderWidth * 2.0;
    
    double newYPos = updateNode.getY();
    if(newYPos < borderWidth)
      newYPos = borderWidth + Math.random() * borderWidth * 2.0;
    else if(newYPos > (getDrawingSizeY() - borderWidth))
      newYPos = getDrawingSizeY() - borderWidth - Math.random() * borderWidth * 2.0;
    
    updateNode.setX((int) newXPos);
    updateNode.setY((int) newYPos);
  }

  private void doAttractive(T source, T dest, List<T> graphnodes) {
    int delta_x = source.getX() - dest.getX();
    int delta_y = source.getY() - dest.getY();
    
    double delta_Length = Math.max(EPSILON, Math.sqrt((delta_x * delta_x) + (delta_y * delta_y)));
    
    double force = computeAttractionForce(delta_Length);
    
    source.addForceX(-((delta_x/delta_Length)*force));
    source.addForceY(-((delta_y/delta_Length)*force));
    
    dest.addForceX((delta_x/delta_Length)*force);
    dest.addForceY((delta_y/delta_Length)*force);
  }

  private void doRepulsive(T repulsiveNode, List<T> graphnodes) {
    repulsiveNode.setForceX(0);
    repulsiveNode.setForceY(0);
    for(T others : graphnodes){
      if(repulsiveNode.compareTo(others) != 0){
        int delta_x = repulsiveNode.getX() - others.getX();
        int delta_y = repulsiveNode.getY() - others.getY();
        
        double delta_Length = Math.max(EPSILON, Math.sqrt((delta_x * delta_x) + (delta_y * delta_y)));
        
        double force = computeRepulsiveForce(delta_Length);
        
        repulsiveNode.addForceX((delta_x/delta_Length)*force);
        repulsiveNode.addForceY((delta_y/delta_Length)*force);
        
      }
    }
  }

  private double getOptimalDistance(int numberOfNodes){
    return Math.sqrt(getDrawingSizeX() * getDrawingSizeY() / numberOfNodes);
  }
  
  private void setRandomPosition(List<T> graphnodes) {
    int i = 0;
    int j = 0;
    int k = (int) optimalDistance;
    for (T n : graphnodes) {
      n.setX(i * k);
      n.setY(j * k);
      if ((i + 1) * k <= getDrawingSizeX())
        i += 1;
      else {
        i = 0;
        j += 1;
      }
    }
  }
  
  private double computeRepulsiveForce(double z) {
    return repulsive_constant * repulsive_constant / z;
  }

  private double computeAttractionForce(double z) {
    return z * z / attraction_constant;
  }
  
  private void coolTemperature(int iteration){
    temperature *= (1.0 - iteration / (double) getIterations());
  }
}
