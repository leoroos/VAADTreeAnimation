package _adrian.GraphDrawing;

import java.util.List;

import _adrian.GraphInterfaces.IGraph;
import _adrian.GraphInterfaces.INodeOperations;


public abstract class IGraphDrawing<K extends IGraph<T>, T extends INodeOperations<T>> {
  
  private int ITERATIONS = 100;
  private int DRAWING_SIZE_X;
  private int DRAWING_SIZE_Y;
	
	/**
	 * Calculates the Euclidean Distance between Node 'n1' and Node 'n2'.
	 * @param n1
	 * @param n2
	 * @return
	 */
	public double getEuclideanDistance(T n1, T n2){
	  return Math.sqrt(Math.pow((n1.getX() - n2.getX()), 2)
        + Math.pow((n1.getY() - n2.getY()), 2));
	}
	
	/**
	 * Calculates the new x- and y-coordinates for a given List 'graphnodes' with Nodes of
	 * Type 'T'. After setting the new coordinates, the List with nodes will be returned.
	 * 
	 * @param graphnodes
	 * @param margin_x
	 * @param margin_y
	 * @return
	 */
	public abstract List<T> computeNodePosition(List<T> graphnodes);
	
	public void setDrawingSizeX(int x){
	  DRAWING_SIZE_X = x;
	}
	
	public void setDrawingSizeY(int y){
	  DRAWING_SIZE_Y = y;
	}
	
	public int getDrawingSizeX(){
	  return DRAWING_SIZE_X;
	}
	
	public int getDrawingSizeY(){
	  return DRAWING_SIZE_Y;
	}
	
	public void setIterations(int iter){
    ITERATIONS = iter;
  }
  
  public int getIterations(){
    return ITERATIONS;
  }

	
}
