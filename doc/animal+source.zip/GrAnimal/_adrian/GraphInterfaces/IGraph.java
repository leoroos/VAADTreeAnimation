package _adrian.GraphInterfaces;

import java.util.List;

import _adrian.exceptions.NodeDoesntExists;

/**
 * This interface defines the basic operations, which should be available in every graph structure.
 * @author Adrian Grochla
 *
 * @param <K>
 */
public interface IGraph<K extends INodeOperations<K>> extends IGraphDrawing {
	
	/**
	 * Adds the given node to the graph.
	 * @param nodeToAdd
	 * @return true, if the given node was successfully added to the graph nodes,
	 * 	false otherwise.
	 */
	public boolean addNode(K nodeToAdd);
	
	/**
	 * Removes the node from the graph structure and also itself as successor of every node.
	 * @param nodeToRemove
	 * @return true, if the given node was successfully removed from the graph nodes,
	 * 	false otherwise.
	 */
	public boolean removeNode(K nodeToRemove);
	
	/**
	 * @return a list with all graph nodes.
	 */
	public List<K> getGraphNodes();
	
	/**
	 * Checks the graph, if the given node exists.
	 * @param node
	 * @return true, if the given node exists,
	 * 	false otherwise
	 */
	public boolean isNode(K node);
	
	/**
	 * Returns the given node from the graph if this node exists.
	 * @param node
	 * @return the node of the graph with the same name and orginal reference
	 *     throws a NodeDoesntExists exception otherwise
	 */
	public K getNode(K node) throws NodeDoesntExists;
	
	/**
	 * Replaces the current Node List with the list in the given parameter
	 * @param List<K> nodes
	 */
	public void replaceNodes(List<K> nodes);
	
	/**
	 * @return true, if the graph is directed,
	 *   false otherwise
	 */
	public boolean isDirected();
	
	/**
	 * Graph-Drawing
	 * @return the area width size, in which the graph will be drawn
	 */
	public int getWidth();
	
	/**
	 * Graph-Drawing
	 * @return the area height size, in which the graph will be drawn
	 */
	public int getHeight();
	
	/**
	 * Graph-Drawing
	 * @return the distance from the top border to the beginning of the first y coordinate.
	 * To all y-coordinates this value is added.
	 */
	public int getMarginTop();
	
	/**
	 * Graph-Drawing
	 * @return the distance from the left border to the beginning of the first x coordinate.
	 * To all x-coordinates this value is added.
	 */
	public int getMarginLeft();

}
