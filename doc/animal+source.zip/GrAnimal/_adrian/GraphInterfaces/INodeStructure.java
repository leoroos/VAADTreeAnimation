package _adrian.GraphInterfaces;

/**
 * This Interface defines the base methods to access structure informations of the node.
 * @author Adrian Grochla
 *
 * @param <K>
 */

public interface INodeStructure<K> extends Comparable<K>{
	
	/**
	 * Returns the x coordinate of the node.
	 * @return
	 */
	public int getX();
	
	/**
	 * Sets the x coordinate of this node to the given value.
	 * @param x
	 */
	public void setX(int x);
	
	/**
	 * Returns the y coordinate of the node.
	 * @param y
	 */
	public int getY();
	
	/**
	 * Sets the y coordinate of this node to the given value.
	 * @param y
	 */
	public void setY(int y);
	
	/**
	 * Returns the name of this Node.
	 * @return
	 */
	public String getName();
	
	/**
	 * Sets the name of this node to the given value.
	 * @param name
	 */
	public void setName(String name);

}
