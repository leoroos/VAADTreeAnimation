package _adrian.GraphInterfaces;

import java.awt.Color;

import _adrian.graphics.PTNode;

public interface INodeDrawing{
	
	public void markNode();
	
	public boolean isMarkedNode();
	
	public void unmarkNode();
	
	public boolean isMarkedEdgeToNode(PTNode node);
	
	public void markEdgeToNode(PTNode node);
	
	public void unmarkEdgeToNode(PTNode node);
	
	/**
	 * Sets the color settings.
	 * Expects an array with size 8, where
	 * 	1. NodeTextcolor
	 * 	2. EdgeTextColor
	 * 	3. NodeFillColor
	 * 	4. EdgeColor
	 * 	5. MarkNodeTextColor
	 * 	6. MarkEdgeTextColor
	 * 	7. MarkNodeColor
	 * 	8. MarkEdgeColor
	 * @param definitions
	 */
//	public void setColorDefinitions(Color[] definitions);
	
	public void setNodeTextColor(Color col);
	
	public Color getNodeTextColor();
	
	public void setEdgeTextColor(Color col);
	
	public Color getEdgeTextColor();
	
	public void setNodeFillColor(Color col);
	
	public Color getNodeFillColor();
	
	public void setEdgeColor(Color col);
	
	public Color getEdgeColor();
	
	public void setMarkNodeTextColor(Color col);
	
	public Color getMarkNodeTextColor();
	
	public void setMarkEdgeTextColor(Color col);
	
	public Color getMarkEdgeTextColor();
	
	public void setMarkNodeColor(Color col);
	
	public Color getMarkNodeColor();
	
	public void setMarkEdgeColor(Color col);
	
	public Color getMarkEdgeColor();

}
