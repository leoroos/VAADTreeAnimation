package _adrian.GraphInterfaces;

import java.util.Map;

import _adrian.exceptions.SuccessorDoesntExists;

/**
 * This Interface defines the base node operations like adding and removing successors and some other methods.
 * @author Adrian Grochla
 *
 * @param <K>
 */

public interface INodeOperations<K> extends INodeStructure<K>, IGraphDrawingForce, INodeDrawing {
	
	/**
	 * Adds the given node as successor of this node with the default weigth of 0.
	 * By adding the successor, the compare method is called, if the node already exists as successor.
	 * @param succ
	 * @return true, if node could be added or false, if node already exists.
	 */
	public boolean addSuccessor(K succ);
	
	/**
	 * Adds the given node as successor of the current node and sets weigth to the weigth parameter.
	 * By adding the successor, the compare method is called, if the node already exists as successor.
	 * @param succ
	 * @param weigth
	 * @return
	 */
	public boolean addSuccessor(K succ, int weigth);
	
	/**
	 * Compares the successor list, if this node already exists as successor by using the compare function of the node.
	 * @param node
	 * @return
	 */
	public boolean isSuccessor(K node);
	
	/**
	 * Removes the given node from the successor list.
	 * @param succ
	 * @return true, if the successor could be removed, otherwise false.
	 */
	public boolean removeSuccessor(K succ);
	
	/**
	 * Returns the weigth to the given successor.
	 * If the successor doesnt exists, then SuccessorDoesntExists Exception is thrown.
	 * @param succ
	 * @return
	 */
	public int getWeigth(K succ) throws SuccessorDoesntExists;
	
	/**
   * Sets the weigth to the given successor.
   * If the successor doesnt exists, then SuccessorDoesntExists Exception is thrown.
   * @param succ the successor with the new weigth
   * @param weigth the new weigth as integer
   */
  public void setWeigth(K succ, int weigth) throws SuccessorDoesntExists;
	
  /**
   * @return a map with all successors as keys and the weigth as values.
   */
	public Map<K, Integer> getSuccessors();	
	
	 
  /**
   * Addes the Edge for attractive force calculation, we just take a look on one direction
   * @param succ
   */
  public void addEdgeTo(K succ);
  
  /**
   * Checks, if the edge was already done
   * @param succ
   * @return
   */
  public boolean isAddedEdgeTo(K n2);
  
  /**
   * deletes all calculated edges
   */
  public void resetEdgesTo();

}
