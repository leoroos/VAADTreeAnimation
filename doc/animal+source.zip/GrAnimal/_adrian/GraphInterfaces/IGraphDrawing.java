package _adrian.GraphInterfaces;

public interface IGraphDrawing {
  
  public void drawDFS(int x, int y);

}
