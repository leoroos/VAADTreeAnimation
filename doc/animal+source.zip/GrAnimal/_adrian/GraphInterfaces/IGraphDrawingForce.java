package _adrian.GraphInterfaces;

public interface IGraphDrawingForce {
	
	public void setForce(double force);
	
	public void addForce(double force);
	
	public double getForce();
	
	public void setForceX(double force);
	
	public void setForceY(double force);
	
	public void addForceX(double force);
	
	public void addForceY(double force);
	
	public double getForceX();
	
	public double getForceY();

}
