package _adrian;

import java.io.IOException;
import java.util.Hashtable;

import animal.misc.ParseSupport;
import animalscript.core.AnimalScriptInterface;
import animalscript.core.BasicParser;

public class PrimitiveParser extends BasicParser implements AnimalScriptInterface {
	
	public PrimitiveParser(){
		handledKeywords = new Hashtable<String, Object>();
		handledKeywords.put("syso", "parseSyso");
	}
	
	public void parseSyso(){
		System.out.println("HELLO WORLD!");
//		public static boolean parseOptionalWord(StreamTokenizer stok,
//				String description, String expectedWord)
		try {
			stok.nextToken();
			if(ParseSupport.parseOptionalWord(stok, "FEHLERMESSAGE", "parameter")){
				stok.nextToken();
				System.out.println("The parametwer was:"+stok.sval);
			}
			else
				System.out.println("The token was "+stok.sval);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
