package _adrian.properties;

import algoanim.properties.AnimationProperties;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.items.ColorPropertyItem;

public class GraphProperties extends AnimationProperties {
  
  public GraphProperties(){
    super();
    fillHashMap();
  }

  @Override
  protected void fillHashMap() {
    data.put(AnimationPropertiesKeys.NODETEXTCOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.EDGETEXTCOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.NODEFILLCOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.EDGECOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.MARKNODETEXTCOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.MARKEDGETEXTCOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.MARKNODECOLOR_PROPERTY, new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.MARKEDGECOLOR_PROPERTY, new ColorPropertyItem());
  }

}
