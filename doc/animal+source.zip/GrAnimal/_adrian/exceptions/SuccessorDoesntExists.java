package _adrian.exceptions;
import _adrian.graphics.PTNode;

public class SuccessorDoesntExists extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SuccessorDoesntExists(PTNode base,PTNode succ){
		super("The node "+succ.getName()+" doesnt exists as Successor of node "+base.getName());
	}

}
