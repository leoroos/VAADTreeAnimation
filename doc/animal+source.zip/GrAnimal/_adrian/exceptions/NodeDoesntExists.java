package _adrian.exceptions;

import _adrian.graphics.PTNode;

public class NodeDoesntExists extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NodeDoesntExists(PTNode base){
		super("The node "+base.getName()+" doesnt exists in the given graph");
	}

}
