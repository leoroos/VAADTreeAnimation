package _adrian.exceptions;

public class DivideByZero extends Exception {
	
	public DivideByZero(){
		super("Divide by Zero!");
	}

}
