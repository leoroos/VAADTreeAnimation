package _adrian.exceptions;

public class ColorDefinitionDoesntExists extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -3475345094816752137L;
  
  public ColorDefinitionDoesntExists(String colorName){
    super("The color name "+colorName+" is not a valid option!");
  }

}
