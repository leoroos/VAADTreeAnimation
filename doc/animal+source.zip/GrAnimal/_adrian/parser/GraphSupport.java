package _adrian.parser;

import java.awt.Color;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.Hashtable;

import _adrian.GraphDrawing.AutoDraw;
import _adrian.GraphDrawing.IGraphDrawing;
import _adrian.exceptions.NodeDoesntExists;
import _adrian.exceptions.SuccessorDoesntExists;
import _adrian.graphics.PTGraph;
import _adrian.graphics.PTNode;
import animal.graphics.PTGraphicObject;
import animal.misc.ParseSupport;
import animalscript.core.AnimalParseSupport;
import animalscript.core.AnimalScriptInterface;
import animalscript.core.BasicParser;

public class GraphSupport extends BasicParser implements AnimalScriptInterface {

  private Color nodeTextColor, edgeTextColor, nodeFillColor, edgeColor,
      markNodeTextColor, markEdgeTextColor, markNodeColor, markEdgeColor;

  public GraphSupport() {
    handledKeywords = new Hashtable<String, Object>();
    handledKeywords.put("graph", "parseGraph");
  }

  public void parseGraph() {
    try {
      ParseSupport.parseWord(stok, "graph type");
      // reading now the nodes
      String todo = ParseSupport.parseWord(stok, "setup, modify or print");
      PTGraph graph = null;
      String graphName = AnimalParseSupport.parseText(stok, "graph name");
      if (todo.equals("setup")) {
        graph = parseSetup(graphName);
      } else if (todo.equals("print")) {
        graph = getCurrentGraph(graphName);
        parsePrint(graph);
      }
      else if (todo.equals("modify")) {
        graph = getCurrentGraph(graphName);
        parseModify(graph);
      }

      boolean isHidden = false;
      if (ParseSupport.parseOptionalWord(stok, "hide the graphic object?",
          "hidden"))
        isHidden = true;
      graph.setObjectName(graphName + currentStep);
      BasicParser.addGraphicObject(graph, anim); // adds the graph as object to
                                                 // the animation
      StringBuilder oids = new StringBuilder();
      oids.append(graph.getNum(false)); // adds to display number to the
      getObjectIDs().put(graph.getObjectName(), oids.toString());
      for (PTGraphicObject o : anim.getGraphicObjects()) {
        for (int i = 0; i < currentStep; i++) {
          if (o.getObjectName().equals(graphName + i))
            AnimalParseSupport.showComponents(stok, (String) getObjectIDs()
                .get(o.getObjectName()), "graph", false);
        }
      }
      if (!isHidden)
        AnimalParseSupport.showComponents(stok, oids.toString(), "graph", true); // displays
                                                                                 // the
                                                                                 // components
    } catch (IOException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void parsePrint(PTGraph graph) {
    try {
      if(ParseSupport.parseOptionalWord(stok, "dfs", "dfs")){
        String coordinates = ParseSupport.parseText(stok, "dfs coordinates");
        graph.drawDFS(parseCoordinates(coordinates)[0], parseCoordinates(coordinates)[1]);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private PTGraph parseSetup(String graphName) {
    PTGraph graph = null;
    try {
      String direction = ParseSupport.parseWord(stok,
          "the direction of the graph");
      boolean isDirected = direction.equals("directed");
      if (ParseSupport.parseOptionalWord(stok, "the drawing size of the graph",
          "areaSize")) {
        String coordinate = ParseSupport.parseText(stok,
            "the coordinates for the area size");
        int[] size = parseCoordinates(coordinate);
        graph = new PTGraph(isDirected, size[0], size[1], size[2], size[3]);
      } else
        graph = new PTGraph(isDirected);

      parseColorDefinitions(graphName);

      parseNodes(graph);

      // adding now the successors
      while (!ParseSupport.parseOptionalWord(stok,
          "end of successor definitions", "end")) {
        stok.pushBack(); // pushing back to read stok again as node name
        String successors = ParseSupport.parseText(stok, "source node");
        String source = (String) successors.subSequence(0, successors
            .indexOf(":"));
        successors = (String) successors.substring(successors.indexOf(":") + 1);
        String[] succs = successors.split(",");
        for (int i = 0; i < succs.length; i++) {
          try {
            if (succs[i].indexOf("(") > -1) {
              String succName = (String) succs[i].subSequence(0, succs[i]
                  .indexOf("("));
              String weigthString = (String) succs[i].subSequence(succs[i]
                  .indexOf("(") + 1, succs[i].indexOf(")"));
              try{
              graph.getNode(source).addSuccessor(graph.getNode(succName),
                  Integer.valueOf(weigthString));
              }
              catch(NumberFormatException e){
                graph.getNode(source).addSuccessor(graph.getNode(succName),
                    Integer.MAX_VALUE);
              }
              if (!graph.isDirected()) {
                graph.getNode(succName).addSuccessor(graph.getNode(source),
                    Integer.valueOf(weigthString));
              }
            } else {
              graph.getNode(source).addSuccessor(graph.getNode(succs[i]));
              if (!graph.isDirected()) {
                graph.getNode(succs[i]).addSuccessor(graph.getNode(source));
              }
            }
          } catch (NodeDoesntExists e) {
            e.printStackTrace();
          }
        }
      }
      if (ParseSupport.parseOptionalWord(stok, "calculate the node positions?",
          "autolayout")) {
        IGraphDrawing<PTGraph, PTNode> gd = new AutoDraw<PTGraph, PTNode>(
            graph.getWidth(), graph.getHeight(), graph.getMarginLeft(), graph.getMarginTop());
        graph.replaceNodes(gd.computeNodePosition(graph.getGraphNodes()));
      }
    } catch (IOException e1) {
      e1.printStackTrace();
    }
    return graph;
  }

  private void parseNodes(PTGraph graph) {
    // read nodes and coordinates
    try {
      while (!ParseSupport.parseOptionalWord(stok, "end of node definitions",
          "successor")) {
        stok.pushBack(); // pushing back to read stok again as node name
        String nodeName = ParseSupport.parseWord(stok, "node");
        String coordinates = "";
        try {
          coordinates = ParseSupport.parseText(stok, "coordinates");
        } catch (StreamCorruptedException e) {
        } // if not a coordinate
        if (coordinates.contains("(")) {
          graph.addNode(new PTNode(nodeName, parseCoordinates(coordinates)[0],
              parseCoordinates(coordinates)[1]));
        } else {
          stok.pushBack();
          graph.addNode(new PTNode(nodeName));
        }

        graph.getNode(nodeName).setNodeTextColor(nodeTextColor);
        graph.getNode(nodeName).setEdgeTextColor(edgeTextColor);
        graph.getNode(nodeName).setNodeFillColor(nodeFillColor);
        graph.getNode(nodeName).setEdgeColor(edgeColor);
        graph.getNode(nodeName).setMarkNodeTextColor(markNodeTextColor);
        graph.getNode(nodeName).setMarkEdgeTextColor(markEdgeTextColor);
        graph.getNode(nodeName).setMarkNodeColor(markNodeColor);
        graph.getNode(nodeName).setMarkEdgeColor(markEdgeColor);
      }
    } catch (IOException e) {
      e.printStackTrace();
    } catch (NodeDoesntExists e) {
      e.printStackTrace();
    }

  }

  private void parseColorDefinitions(String graphName) {
    try {
      nodeTextColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "nodeTextColor", "black");
      edgeTextColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "edgeTextColor", "black");
      nodeFillColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "nodeFillColor", "yellow");
      edgeColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "edgeColor", "blue");
      markNodeTextColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "markNodeTextColor", "white");
      markEdgeTextColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "markEdgeTextColor", "red");
      markNodeColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "markNodeColor", "red");
      markEdgeColor = AnimalParseSupport.parseAndSetColor(stok, graphName,
          "markEdgeColor", "red");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private PTGraph parseModify(PTGraph graph) {
    try {
      while (ParseSupport.parseOptionalWord(stok,
          "calculate the node positions?", "markNode")) {
        String node = ParseSupport.parseWord(stok, "node");
        graph.getNode(node).markNode();
      }
      while (ParseSupport.parseOptionalWord(stok,
          "calculate the node positions?", "unmarkNode")) {
        String node = ParseSupport.parseWord(stok, "node");
        graph.getNode(node).unmarkNode();
      }
      while (ParseSupport.parseOptionalWord(stok,
          "calculate the node positions?", "markEdge")) {
        String string = ParseSupport.parseText(stok, "node");
        String source = (String) string.subSequence(0, string.indexOf("-"));
        String dest = (String) string.substring(string.indexOf(">") + 1);
        graph.getNode(source).markEdgeToNode(graph.getNode(dest));
      }
      while (ParseSupport.parseOptionalWord(stok,
          "calculate the node positions?", "unmarkEdge")) {
        String string = ParseSupport.parseText(stok, "node");
        String source = (String) string.subSequence(0, string.indexOf("-"));
        String dest = (String) string.substring(string.indexOf(">") + 1);
        graph.getNode(source).unmarkEdgeToNode(graph.getNode(dest));
      }
      while (ParseSupport.parseOptionalWord(stok, "optional command addEdge",
          "addEdge")) {
        String string = ParseSupport.parseText(stok, "node");
        String source = (String) string.subSequence(0, string.indexOf("-"));
        String dest = (String) string.substring(string.indexOf(">") + 1);
        graph.getNode(source).addSuccessor(graph.getNode(dest));
        if (!graph.isDirected()) {
          graph.getNode(dest).addSuccessor(graph.getNode(source));
        }
      }
      while (ParseSupport.parseOptionalWord(stok,
          "optional command removeEdge", "removeEdge")) {
        String string = ParseSupport.parseText(stok, "node");
        String source = (String) string.subSequence(0, string.indexOf("-"));
        String dest = (String) string.substring(string.indexOf(">") + 1);
        graph.getNode(source).removeSuccessor(graph.getNode(dest));
        if (!graph.isDirected()) {
          graph.getNode(dest).removeSuccessor(graph.getNode(source));
        }
      }
      while (ParseSupport.parseOptionalWord(stok, "optional command setWeigth",
          "setWeigth")) {
        String string = ParseSupport.parseText(stok, "node");
        String source = (String) string.subSequence(0, string.indexOf("-"));
        String dest = (String) string.substring(string.indexOf(">") + 1);
        int weigth;
        try{
          ParseSupport.parseWord(stok, "weigth");
          weigth = Integer.MAX_VALUE;
        }
        catch(StreamCorruptedException e){
          stok.pushBack();
          weigth = ParseSupport.parseInt(stok, "weigth");
        }
        graph.getNode(source).setWeigth(graph.getNode(dest), weigth);
        if (!graph.isDirected()) {
          graph.getNode(dest).setWeigth(graph.getNode(source), weigth);
        }
      }
      // PTDFS dfs = new PTDFS(graph);
      // dfs.setObjectName(graph.getObjectName() + "scc");
      // BasicParser.addGraphicObject(dfs, anim); // adds the graph as object to
      // the animation
      // StringBuilder oids = new StringBuilder();
      // oids.append(dfs.getNum(false)); // adds to display number to the
      // getObjectIDs().put(dfs.getObjectName(), oids.toString());
      // AnimalParseSupport.showComponents(stok, oids.toString(), "scc", true);
    } catch (IOException e) {
      e.printStackTrace();
    } catch (NodeDoesntExists e) {
      e.printStackTrace();
    } catch (SuccessorDoesntExists e) {
      e.printStackTrace();
    }
    return graph;
  }

  private int[] parseCoordinates(String stringCoordinates) {
    String coordinate = (String) stringCoordinates.subSequence(
        stringCoordinates.indexOf("(") + 1, stringCoordinates.indexOf(")"));
    String[] tmp = coordinate.split("\\,");
    int[] coordinates = new int[tmp.length];
    for (int i = 0; i < tmp.length; i++)
      coordinates[i] = Integer.parseInt(tmp[i]);
    return coordinates;
  }

  private PTGraph getCurrentGraph(String graphName) {
    PTGraph graph = null;
    for (int i = currentStep; i >= 0; i--) {
      if (getObjectIDs().get(graphName + i) != null) {
        graph = (PTGraph) animState.getCloneByNum(getObjectIDs()
            .getIntProperty(graphName + i));
        break;
      }
    }
    PTGraph clone = new PTGraph(graph.isDirected(), graph.getWidth(), graph
        .getHeight(), graph.getMarginLeft(), graph.getMarginTop());
    for (PTNode n : graph.getGraphNodes()) {
      PTNode tmp = new PTNode(n.getName(), n.getX(), n.getY());
      if (n.isMarkedNode())
        tmp.markNode();
      tmp.setEdgeColor(n.getEdgeColor());
      tmp.setEdgeTextColor(n.getEdgeTextColor());
      tmp.setMarkEdgeColor(n.getMarkEdgeColor());
      tmp.setMarkEdgeTextColor(n.getMarkEdgeTextColor());
      tmp.setNodeFillColor(n.getNodeFillColor());
      tmp.setNodeTextColor(n.getNodeTextColor());
      tmp.setMarkNodeColor(n.getMarkNodeColor());
      tmp.setMarkNodeTextColor(n.getMarkNodeTextColor());
      clone.addNode(tmp);
    }
    for (PTNode n : graph.getGraphNodes()) {
      for (PTNode succ : n.getSuccessors().keySet()) {
        try {
          clone.getNode(n.getName()).addSuccessor(
              clone.getNode(succ.getName()), n.getWeigth(succ));
          if (n.isMarkedEdgeToNode(succ))
            clone.getNode(n.getName()).markEdgeToNode(
                clone.getNode(succ.getName()));
        } catch (NodeDoesntExists e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } catch (SuccessorDoesntExists e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }
    return clone;
  }

}
