package _adrian.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import _adrian.graphics.PTNode;
import _adrian.exceptions.SuccessorDoesntExists;

public class TestNodeOperations {
	
	PTNode a, b;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		a = new PTNode("a");
		b = new PTNode("b");
	}

	@Test
	public void testNodeString() {
		PTNode x = new PTNode("a");
		assertTrue("Name doesnt match", x.getName().equals("a"));
	}

	@Test
	public void testNodeStringIntInt() {
		PTNode x = new PTNode("x", 6, 7);
		assertTrue("Name doesnt match", x.getName().equals("x"));
		assertEquals("x coordinate doesnt match", x.getX(), 6);
		assertEquals("y coordinate doesnt match", x.getY(), 7);
	}

	@Test
	public void testAddSuccessorNode() {
		assertFalse("Node should not be avaible", a.isSuccessor(b));
		a.addSuccessor(b);
		assertTrue("Node should be avaible", a.isSuccessor(b));
	}

	@Test
	public void testAddSuccessorNodeInt() {
		assertFalse("Node should not be avaible", a.isSuccessor(b));
		a.addSuccessor(b, 9);
		assertTrue("Node should be avaible", a.isSuccessor(b));
		try {
			assertEquals("Weigth should be 9", 9, a.getWeigth(b));
		} catch (SuccessorDoesntExists e) {
			assertFalse("SuccessorDoesntExists Exception was thrown", true);
		}
	}

	@Test
	public void testRemoveSuccessor() {
		a.addSuccessor(b);
		assertTrue("Node should be avaible", a.isSuccessor(b));
		a.removeSuccessor(b);
		assertFalse("Node should not be avaible", a.isSuccessor(b));
	}

	@Test
	public void testSetName() {
		assertEquals("Node names doesnt match", "a", a.getName());
		a.setName("baafc");
		assertEquals("Node names doesnt match", "baafc", a.getName());
	}

	@Test
	public void testSetXandY() {
//		assertEquals("x coordinate should be 0", 0, a.getX());
//		assertEquals("y coordinate should be 0", 0, a.getY());
		a.setX(4);
		a.setY(6);
		assertEquals("x coordinate should be 4", 4, a.getX());
		assertEquals("y coordinate should be 6", 6, a.getY());
	}

	@Test
	public void testCompareTo() {
		assertEquals("Compare result should be 0", 0, a.compareTo(new PTNode("a")));
		PTNode aaabc = new PTNode("aaabc");
		PTNode aaa = new PTNode("aaa");
		PTNode bb = new PTNode("bb");
		assertEquals("Compare result should be 2", 2, aaabc.compareTo(aaa));
		assertEquals("Compare result should be -11", -1, aaabc.compareTo(bb));
	}

}
