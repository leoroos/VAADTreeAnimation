//package _adrian.tests;
//
//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;
//
//import org.junit.Test;
//
//import _adrian.exceptions.DivideByZero;
//import _adrian.graphics.PTGraph;
//
//
//public class TestCoordinationComputing {
//	
//	PTGraph graph = new PTGraph();
//	
//	@Test
//	public void testComputeGradient(){
//		double expected = 1.0;
//		double actual;
//		boolean isEqual;
//		try {
//			actual = graph.computeGradient(1, 1, 3, 3);
//			isEqual = (expected == actual);
//			assertTrue("the gradient should be 1.0 but was "+actual, isEqual);
//		} catch (DivideByZero e) {
//			assertTrue(false);
//		}
//		try {
//			expected = -0.5;
//			actual = graph.computeGradient(1, 1, 3, 0);
//			isEqual = (expected == actual);
//			assertTrue("the gradient should be -0.5 but was "+actual, isEqual);
//		} catch (DivideByZero e) {
//			assertTrue(false);
//		}
//		try {
//			expected = Double.MAX_VALUE;
//			actual = graph.computeGradient(1, 3, 1, 0);
//			assertFalse(true);
//			
//		} catch (DivideByZero e) {
//			assertTrue(true);;
//		}
//		
//	}
//	
//	@Test
//	public void testComputeAxisIntercept(){
//		double actual = graph.computeAxisIntercept(1, 1, 1.0);
//		double exptected = 0;
//		boolean isEqual = (actual == exptected);
//		assertTrue("The Axis Intercept should be 0 but was "+actual, isEqual);
//		actual = graph.computeAxisIntercept(1, 1, 0.5);
//		exptected = 0.5;
//		isEqual = (actual == exptected);
//		assertTrue("The Axis Intercept should be 0.5 but was "+actual, isEqual);
//		
//	}
//	
//	@Test
//	public void testComputeGradientEquation(){
//		int actual = graph.computeGradientEquation(3, 0.5, 0.5, false);
//		int exptected = 2;
//		boolean isEqual = (actual == exptected);
//		assertTrue("The Y-Coordinate should be 2 but was "+actual, isEqual);
//		actual = graph.computeGradientEquation(2, 0.5, 0.5, true);
//		exptected = 3;
//		isEqual = (actual == exptected);
//		assertTrue("The X-Coordinate should be 3 but was "+actual, isEqual);
//		
//	}
//	
//	
//
//}
