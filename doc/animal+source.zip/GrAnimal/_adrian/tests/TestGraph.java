package _adrian.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import _adrian.graphics.PTGraph;
import _adrian.graphics.PTNode;
import _adrian.GraphInterfaces.IGraph;
import _adrian.exceptions.NodeDoesntExists;

public class TestGraph {
	
	PTGraph graph;
	PTNode a,b,c,d,e;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		graph = new PTGraph(true);
		a = new PTNode("a");
		b = new PTNode("b");
		c = new PTNode("c");
		d = new PTNode("d");
		e = new PTNode("e");
	}
	
	@Test
	public void testAddNode(){
		assertFalse("Node should not be available", graph.isNode(a));
		assertFalse("Node should not be available", graph.isNode(b));
		graph.addNode(a);
		graph.addNode(b);
		assertTrue("Node should be available", graph.isNode(a));
		assertTrue("Node should be available", graph.isNode(b));
		assertFalse("Node should not be available", graph.isNode(c));
	}
	
	@Test
	public void testRemoveNode(){
		assertFalse("Node should not be available", graph.isNode(a));
		assertFalse("Node should not be available", graph.isNode(b));
		graph.addNode(a);
		graph.addNode(b);
		assertTrue("Node should be available", graph.isNode(a));
		assertTrue("Node should be available", graph.isNode(b));
		assertFalse("Node should not be available", graph.isNode(c));
		graph.removeNode(a);
		assertTrue("Node should be available", graph.isNode(b));
		assertFalse("Node should not be available", graph.isNode(a));
	}
	
	@Test
	public void testAddandRemoveSuccessorOverGraph(){
		assertFalse("Node should not be available", graph.isNode(a));
		assertFalse("Node should not be available", graph.isNode(b));
		graph.addNode(a);
		graph.addNode(b);
		graph.addNode(c);
		graph.addNode(d);
		graph.addNode(e);
		try {
			graph.getNode(c).addSuccessor(e);
			graph.getNode(a).addSuccessor(b);
			graph.getNode(b).addSuccessor(a);
		} catch (NodeDoesntExists e1) {
			assertFalse("Node operations couldnt be done", true);
		}
		assertTrue("Node should be available", graph.isNode(a));
		assertTrue("Node should be available", graph.isNode(b));
		assertEquals("5 Nodes should be in the graph", 5, graph.getGraphNodes().size());
		try {
			assertTrue("b should be successor of a", graph.getNode(a).isSuccessor(b));
			graph.removeNode(b);
			assertTrue("Node should be available", graph.isNode(a));
			assertFalse("Node b should not be available", graph.isNode(b));
			assertEquals("4 Nodes should be in the graph", 4, graph.getGraphNodes().size());
			assertFalse("b should not be successor of a anymore", graph.getNode(a).isSuccessor(b));
		} catch (NodeDoesntExists e1) {
			assertFalse("Node operations couldnt be done", true);
		}
	}

}
