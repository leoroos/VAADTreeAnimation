/*
 * Created on 23.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import algoanim.primitives.generators.Language;

public class FillInBlanksQuestion extends InteractiveQuestion {
  public final static String INVALID_OPTION = "INVALID";
  protected String answer = "";
 
  public FillInBlanksQuestion(Language lang, String id) {
    super(lang, id);
  }
  
  public void addAnswer(String answer, 
		  String FeedbackString, int points) {
    
	this.answer = answer;
    setFeedback(FeedbackString);
    pointsPossible = points;
  }
  
  public String getAnswer() {
    return answer;
  }
  
  public String getFeedback() {
	return feedback.get("feedback");
  }

  private void setFeedback(String feedbackString) {
	feedback.put("feedback", feedbackString);
  }
}
