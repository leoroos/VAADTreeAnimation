/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import java.util.HashMap;

import algoanim.primitives.generators.Language;

public class InteractiveQuestion extends InteractiveElement {
  protected String questionPrompt;
  protected String questionGroupID;
  protected int pointsPossible;
  
  protected HashMap<String, String> feedback = 
    new HashMap<String, String>(53);
  
  public InteractiveQuestion(Language lang, String id) {
    super(lang, id);    
  }
  
  /**
   * returns the number of points possible for this question
   * 
   * @return the number of points possible for a "perfect" answer
   */
  public int getPointsPossible() {
    return pointsPossible;
  }
  
  
  /**
   * returns the question prompt, i.e., the introductory text
   * that describes the question statement.
   * 
   * @return the question prompt
   */
  public String getPrompt() {
    return questionPrompt;
  }
  
  /**
   * returns the ID of the question group. This can be used to 
   * prevent multiple questions of the "same" type to be asked
   * once the user has answered a "sufficient" number of them
   * correctly.
   * 
   * @return the ID of the group of the question, if any. Returns
   * <em>null</em> if there is no associated ID.
   */
  public String getQuestionGroup() {
    return questionGroupID;
  }
  
  /**
   * assigns the number of points possible for a "perfect" answer 
   * to this question
   * 
   * @param nrPoints the maximum number of points possible for
   * this question
   */
  public void setPointsPossible(int nrPoints) {
    pointsPossible = nrPoints;
  }
  
  /**
   * assigns the question prompt which describes the problem
   * statement for this question
   * 
   * @param questionText the text to be used as the question
   * prompt.
   */
  public void setPrompt(String questionText) {
    questionPrompt = questionText;
  }
  
  /**
   * assigns the question group ID for this question. This can 
   * be used to prevent multiple questions of the "same" type 
   * to be asked once the user has answered a "sufficient" 
   * number of them correctly.
   * 
   * @param groupID the question group ID for this question.
   */
  public void setQuestionGroup(String groupID) {
    questionGroupID = groupID;
  }
}
