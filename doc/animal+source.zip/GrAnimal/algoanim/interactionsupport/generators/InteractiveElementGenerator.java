/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport.generators;

import algoanim.interactionsupport.DocumentationLink;
import algoanim.interactionsupport.FillInBlanksQuestion;
import algoanim.interactionsupport.InteractiveElement;
import algoanim.interactionsupport.MultipleChoiceQuestion;
import algoanim.interactionsupport.MultipleSelectionQuestion;
import algoanim.interactionsupport.TrueFalseQuestion;
import algoanim.primitives.generators.GeneratorInterface;

/**
 * <code>InteractiveElementGenerator</code> offers methods to request the included
 * Language object to append interactive elements to the output. 
 * 
 * @author Guido R&ouml;&szlig;ling <roessling@acm.org>
 * @version 1.0 2008-08-25
 */
public interface InteractiveElementGenerator extends GeneratorInterface {
  /**
   * creates the actual code for representing an interactive element
   * @param element the element to be generated
   */
  public void createInteractiveElementCode(InteractiveElement element);

  /**
   * Creates the script code for a given <code>TrueFalseQuestion</code>
   * 
   * @param tfQuestion the <em>TrueFalseQuestion</em> for which 
   * the code is to be generated
   */
  public void createTFQuestion(TrueFalseQuestion tfQuestion);
  
  /**
   * Creates the script code for a given <code>FillInBlanksQuestion</code>
   * 
   * @param fibQuestion the <em>FillInBlanksQuestion</em> for which 
   * the code is to be generated
   */
  public void createFIBQuestion(FillInBlanksQuestion fibQuestion);
  
  /**
   * Creates the script code for a given <code>TrueFalseQuestion</code>
   * 
   * @param docuLink the <em>TrueFalseQuestion</em> for which the code is to
   * be generated
   */
  public void createDocumentationLink(DocumentationLink docuLink);

  
  /**
   * Creates the script code for a given <code>MultipleChoiceQuestion</code>
   * 
   * @param mcQuestion the <em>TrueFalseQuestion</em> for which 
   * the code is to be generated
   */
  public void createMCQuestion(MultipleChoiceQuestion mcQuestion);

  
  /**
   * Creates the script code for a given 
   * <code>MultipleSelectionQuestion</code>
   * 
   * @param msQuestion the <em>TrueFalseQuestion</em> for which 
   * the code is to be generated
   */
  public void createMSQuestion(MultipleSelectionQuestion msQuestion);
  
  /**
   * finalize the writing of the interaction components
   */
  public void finalizeInteractiveElements();
}
