/*
 * Created on 23.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import java.net.URI;
import java.net.URISyntaxException;

import algoanim.primitives.generators.Language;

public class DocumentationLink extends InteractiveElement {
  private URI targetURI = null;
  
  public DocumentationLink(Language lang, String elementID) {
    super(lang, elementID);
  }
  
  /**
   * return the documentation link URI for this element
   * @return the target URI
   */
  public URI getTargetURI() {
    return targetURI;
  }
  
  /**
   * assign the target URI for the documentation link
   * @param targetString the targetURI as a String
   */
  public void setLinkAddress(String targetString) {
    try {
      targetURI = new URI(targetString);
    }
    catch (URISyntaxException uriSyntaxExc) {
      // nothing to be done here
    }
  }
  
  /**
   * assign the target URI for the documentation link
   * @param newTargetURI the target URI
   */
  public void setLinkAddress(URI newTargetURI) {
    targetURI = newTargetURI;
  }
}