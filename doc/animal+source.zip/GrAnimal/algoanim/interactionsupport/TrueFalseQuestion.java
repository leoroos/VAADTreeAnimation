/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import algoanim.primitives.generators.Language;

public class TrueFalseQuestion extends InteractiveQuestion {
  protected boolean answerIsCorrect = false;
  
  public TrueFalseQuestion(Language lang, String id) {
    super(lang, id);
    setFeedbackForCorrectAnswer("OK");
    setFeedbackForIncorrectAnswer("Wrong");
  }
  
  /**
   * returns the answer status, determining whether the question
   * statement was correct (=true) or not (=false)
   * @return the answer status; <em>true</em> for a correct and 
   * <em>false</em> for an incorrect statement
   */
  public boolean getAnswerStatus() {
    return answerIsCorrect;
  }
  
  /**
   * return the didactical feedback for the user answer
   * 
   * @param userChoice if true, the returned String will
   * be the feedback for the user's choice of the "true" button; else,
   * it will the feedback for a chosen "false" button.
   * @return the didactical feedback associated with the given
   * user answer.
   */
  public String getFeedbackForOption(boolean userChoice) {
    return feedback.get(String.valueOf(userChoice));
  }
  
  /**
   * sets the answer status to the value passed in
   * 
   * @param answerStatus if <em>true</em>, the question statement
   * was correct, else it was incorrect
   */
  public void setAnswerStatus(boolean answerStatus) {
    answerIsCorrect = answerStatus;
  }
  
  /**
   * assigns a text to be shown if the user answered "true"
   * 
   * @param text the text to be shown if the user selected the
   * answer option "true"
   */
  public void setFeedbackForCorrectAnswer(String text) {
    setFeedbackForAnswer(true, text); 
  }

  /**
   * assigns a text to be shown if the user answered "true"
   * 
   * @param text the text to be shown if the user selected the
   * answer option "false"
   */
  public void setFeedbackForIncorrectAnswer(String text) {
    setFeedbackForAnswer(false, text); 
  }
  
  /**
   * assigns a text to be shown if the question was answered
   * in a certain way, i.e., the feedback to be given for the
   * answer "true" if the <em>answerOption</em> parameter is
   * <em>true</em>, and the feedback for "false" if the parameter
   * is <em>false</em>.
   * 
   * @param answerOption determines if the feedback is for the
   * chosen answer type "true" or "false". Note that this is
   * <em>not</em> the same as for "correct" or "incorrect" -- the
   * answer option "true" will often be the <em>incorrect</em> choice.
   * The parameter thus describes the <em>user's chosen answer</em>,
   * not the <em>correctness</em> of that answer.
   * @param text the text to be shown if the user's answer was
   * incorrect
   */
  public void setFeedbackForAnswer(boolean answerOption, String text) {
    feedback.put(String.valueOf(answerOption), text);
  }
}
