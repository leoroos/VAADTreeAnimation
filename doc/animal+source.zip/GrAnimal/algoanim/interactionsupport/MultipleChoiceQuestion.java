/*
 * Created on 23.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Set;

import algoanim.primitives.generators.Language;

public class MultipleChoiceQuestion extends InteractiveQuestion {
  public final static String INVALID_OPTION = "INVALID";
  protected int numberOfAnswerOptions = 0;
  protected String idOfCorrectAnswer = INVALID_OPTION;
  protected HashMap<String, String> answerOptions = 
    new HashMap<String, String>(11);
  protected HashMap<String, Integer> pointsForAnswer = 
    new HashMap<String, Integer>(11);
 
  public MultipleChoiceQuestion(Language lang, String id) {
    super(lang, id);
  }

  /**
   * adds a new answer option to the list of options
   * 
   * @param option the text describing this answer option
   */
  public String addAnswerOption(String option) {
    if (option != null && option.length() > 0) {
      String id = String.valueOf(++numberOfAnswerOptions);
      answerOptions.put(id, option);
      return id;
    }
    return INVALID_OPTION;
  }
  
  /**
   * adds a new answer option to the list of options. This is a
   * convenience method for wrapping all required elements together
   * 
   * @param option the text describing this answer option
   * @param isCorrect if <em>true</em>, this is the correct answer
   * @param feedbackString the feedback to be shown for this answer
   * @param points the number of points (if any) given if
   * this answer is chosen
   */
  public String addAnswerOption(String option, boolean isCorrect,
      String feedbackString, int points) {
    String id = addAnswerOption(option);
    if (isCorrect)
      setCorrectAnswerID(id);
    setFeedbackForAnswerOption(id, feedbackString);
    setPointsForAnswer(id, points);
    return id;
  }
  
  /**
   * returns the set of answer keys
   */
  public Set<String> getAnswerSet() {
    return answerOptions.keySet();
  }
  
  /**
   * returns the set of answer keys in an array
   */
  public Object[] getAnswerArray() {
    return answerOptions.keySet().toArray();
  }
  
  /**
   * returns the answer text for a given question ID
   * 
   * @param questionID the ID of the question
   */
  public String getAnswerString(String questionID) {
    return answerOptions.get(questionID);
  }

  /**
   * returns the ID of the correct answer
   * 
   * @return the ID of the correct answer - may also be null.
   */
  public String getCorrectAnswerID() {
    return idOfCorrectAnswer;
  }
  
  /**
   * return the didactical feedback for the user answer
   * 
   * @param id the ID of the chosen answer.
   * @return the didactical feedback associated with the given
   * user answer.
   */
  public String getFeedbackForOption(String id) {
    return feedback.get(id);
  }

  /**
   * return the number of points given for the user's answer
   * 
   * @param id the ID of the chosen answer.
   * @return the didactical feedback associated with the given
   * user answer.
   */
  public int getPointsForOption(String id) {
    Integer nrPoints = pointsForAnswer.get(id);
    if (nrPoints != null)
      return nrPoints.intValue();
    return 0;
  }

  /**
   * sets the ID of the correct answer
   * 
   * @param id the ID of the correct answer
   */
  public void setCorrectAnswerID(String id) {
    if (answerOptions.containsKey(id)) {
      idOfCorrectAnswer = id;
      int pp = getPointsPossible();
      if (pp == 0)
        pp = 1;
      if (!(pointsForAnswer.containsKey(id)))
        pointsForAnswer.put(id, pp);
    }
    else
      throw new NoSuchElementException("There is no answer with ID " +id);
  }
  
  /**
   * assigns a didactical feedback for the answer option with the
   * given id 
   * 
   * @param id the ID of the question to which this feedback belongs
   * @param feedbackString the feedback to be shown for this answer
   */
  public void setFeedbackForAnswerOption(String id, 
      String feedbackString) {
    feedback.put(id, feedbackString);
  }
  
  /**
   * assigns the number of points possible for chosing this answer.
   * 
   * @param id the ID of the answer option
   * @param points the points given if this answer is chosen
   */
  public void setPointsForAnswer(String id, int points) {
    pointsForAnswer.put(id, points);
    if (points > pointsPossible)
      pointsPossible = points; // only one answer possible here!
  }
}
