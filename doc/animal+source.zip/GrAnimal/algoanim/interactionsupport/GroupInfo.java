/*
 * Created on 19.09.2008 by Bjoern Dasbach <dasbach@rbg.informatik.tu-darmstadt.de>
 */
package algoanim.interactionsupport;

import algoanim.primitives.generators.Language;

public class GroupInfo extends InteractiveElement {
  private int nrRepeats;
  
  public GroupInfo(Language lang, String elementID) {
    super(lang, elementID);
    nrRepeats = 0;
  }
  
  public GroupInfo(Language lang, String elementID, int nrRepeats) {
    super(lang, elementID);
    this.nrRepeats = nrRepeats;
  }
  
  /**
   * return the number repeats needed for this questiongroup
   * @return the number repeats
   */
  public int getNrRepeats() {
    return nrRepeats;
  }
  
  public void setNrRepeats(int r) {
	  nrRepeats = r;
  }
}