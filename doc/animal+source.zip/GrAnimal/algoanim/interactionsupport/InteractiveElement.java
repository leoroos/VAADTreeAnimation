/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.interactionsupport;

import algoanim.primitives.generators.Language;

public class InteractiveElement {
  protected String id = null;
  protected Language language = null;

  public InteractiveElement(Language lang, String elementID) {
    language = lang;
    setID(elementID);
  }
  
  public String getID() {
    return id;
  }
  
  protected void setID(String newID) {
    id = newID;
  }
}
