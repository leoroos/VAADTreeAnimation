/**
 * 
 */
package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.FontPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;

/**
 * @see	algoanim.properties.AnimationProperties
 * @author Dima Vronskyi
 */
public class QueueProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>StackProperties</code> object.
	 */
	public QueueProperties() {
		super();
		fillHashMap();
	}
	
	/**
	 * Generates a named <code>StackProperties</code> object.
	 * @param name the name for this <code>StackProperties</code>.
	 */
	public QueueProperties(String name) {
		super(name);
		fillHashMap();
	}
	
	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ALTERNATE_FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ALTERNATE_FILLED_PROPERTY, new BooleanPropertyItem());		
		data.put(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FONT_PROPERTY, new FontPropertyItem()); //?
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());
		fillAdditional();
	}

}
