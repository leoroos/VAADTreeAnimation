package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;

/**
 * This class encapsulates the properties that can be set for a graph.
 * 
 * @author Dr. Guido Roessling (roessling@acm.org>
 * @version 0.7 2007-04-04
 */
public class GraphProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>PolygonProperties</code> object.
	 */
	public GraphProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>PolygonProperties</code> object.
	 * @param name The name
	 */
	public GraphProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY, 
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY,
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY,
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.EDGECOLOR_PROPERTY,
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.NODECOLOR_PROPERTY,
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.DIRECTED_PROPERTY,
				new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.WEIGHTED_PROPERTY,
				new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());
		fillAdditional();
	}	
}
