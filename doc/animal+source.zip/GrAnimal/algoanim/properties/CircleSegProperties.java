package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;



/**
 * @author Stephan Mehlhase, Jens Pfau 
 * @see	algoanim.properties.AnimationProperties
 */

public class CircleSegProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>CircleSegProperties</code> object.<
	 */
	public CircleSegProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>CircleSegProperties</code> object.
	 * @param name 		the name of this <code>CircleSegProperties</code>.
	 */
	public CircleSegProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		/* Fill in appropriate default values if you want to */
		data.put(AnimationPropertiesKeys.ANGLE_PROPERTY, new IntegerPropertyItem(0, 0, 360));
		data.put(AnimationPropertiesKeys.STARTANGLE_PROPERTY, new IntegerPropertyItem(0, 0, 360));
		data.put(AnimationPropertiesKeys.CLOCKWISE_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.COUNTERCLOCKWISE_PROPERTY, new IntegerPropertyItem(0, 0, 360));
		data.put(AnimationPropertiesKeys.CLOSED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILLED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.FWARROW_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.BWARROW_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		fillAdditional();
	}	

}
