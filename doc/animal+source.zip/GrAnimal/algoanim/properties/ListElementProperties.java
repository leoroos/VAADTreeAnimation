package algoanim.properties;


import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;
import algoanim.properties.items.StringPropertyItem;



/**
 * @author jens
 * @see	algoanim.properties.AnimationProperties
 */

public class ListElementProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>ListElementProperties</code> object.
	 */
	public ListElementProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>ListElementProperties</code> object.
	 * @param name 		the name of this <code>ListElementProperties</code>.
	 */
	public ListElementProperties(String name) {
		super(name);
		fillHashMap();
	}
	
	
	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.TEXT_PROPERTY, new StringPropertyItem());
		data.put(AnimationPropertiesKeys.POSITION_PROPERTY, new IntegerPropertyItem());
		/* ist nun teil des Primitives
		data.put(AnimationPropertiesKeys.PREV_PROPERTY, new StringPropertyItem());
		*/
		data.put(AnimationPropertiesKeys.BOXFILLCOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.POINTERAREACOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.POINTERAREAFILLCOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.TEXTCOLOR_PROPERTY, new ColorPropertyItem());		
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		fillAdditional();
	}	
	
}
