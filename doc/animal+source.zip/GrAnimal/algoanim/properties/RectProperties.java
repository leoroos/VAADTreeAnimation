package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;


/**
 * @author Jens Pfau, Stephan Mehlhase, Tobias Ackermann
 */
public class RectProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>RectProperties</code> object.
	 */
	public RectProperties() {
		super();
		fillHashMap();
	}
	
	/**
	 * Generates a named <code>RectProperties</code> object.
	 * @param name 	the name for this object.
	 */
	public RectProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		/* Create the Hashmap with new PropertyItems */
		this.data.put(AnimationPropertiesKeys.COLOR_PROPERTY,
				new ColorPropertyItem());
		this.data.put(AnimationPropertiesKeys.DEPTH_PROPERTY,
				new IntegerPropertyItem());
		this.data.put(AnimationPropertiesKeys.FILLED_PROPERTY,
				new BooleanPropertyItem());
		this.data.put(AnimationPropertiesKeys.FILL_PROPERTY, 
				new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		
		fillAdditional();
	}	

}
