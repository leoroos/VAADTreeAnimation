package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;

public class PolylineProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>PolygonProperties</code> object.
	 */
	public PolylineProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>PolygonProperties</code> object.
	 * @param name 		the name.
	 */
	public PolylineProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.FWARROW_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.BWARROW_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		fillAdditional();
	}

	
}
