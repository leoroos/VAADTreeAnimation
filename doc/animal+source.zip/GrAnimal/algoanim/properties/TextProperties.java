package algoanim.properties;


import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.FontPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;



/**
 * @author Stephan Mehlhase, Jens Pfau
 */

public class TextProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>CircleSegProperties</code> object.
	 */
	public TextProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>CircleSegProperties</code> object.
	 * @param name 		the name.
	 */
	public TextProperties(String name) {
		super(name);
		fillHashMap();
	}
	
	
	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		/* Fill in appropriate default values if you want to */
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.CENTERED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.FONT_PROPERTY, new FontPropertyItem());
		/* ueberfluessig, da schon in FontPropertyItem zu speichern 
		data.put(AnimationPropertiesKeys.FONTSIZE_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.FONTBOLD_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.FONTITALIC_PROPERTY, new BooleanPropertyItem());
		 */
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());
		
		fillAdditional();
	}	

}
