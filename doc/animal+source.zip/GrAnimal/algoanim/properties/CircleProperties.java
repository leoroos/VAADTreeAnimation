package algoanim.properties;


import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;



/**
 * @author Stephan Mehlhase, Jens Pfau
 * @see	algoanim.properties.AnimationProperties
 * 
 */

public class CircleProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>CircleProperties</code> object.
	 */
	public CircleProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>CircleProperties</code> object.
	 * @param name 		the name of this <code>CircleProperties</code>.
	 */
	public CircleProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILLED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		fillAdditional();
	}	

}
