package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;


/**
 * @author stephan
 */
public class TriangleProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>TriangleProperties</code> object.
	 */
	public TriangleProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>TriangleProperties</code> object.
	 * @param name The name
	 */
	public TriangleProperties(String name) {
		super(name);
		fillHashMap();
	}


	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILLED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());

		fillAdditional();
	}	

}
