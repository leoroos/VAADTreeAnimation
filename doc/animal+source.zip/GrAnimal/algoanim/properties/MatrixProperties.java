package algoanim.properties;

import java.util.Vector;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.EnumerationPropertyItem;
import algoanim.properties.items.FontPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;

/**
 * @author Jens Pfau, Stephan Mehlhase
 * @see algoanim.properties.AnimationProperties
 */

public class MatrixProperties extends AnimationProperties {
  public static Vector<String> alignOptions = new Vector<String>();
  public static Vector<String> styleOptions = new Vector<String>();

  static {
    alignOptions.add("left");
    alignOptions.add("center");
    alignOptions.add("right");
    styleOptions.add("plain");
    styleOptions.add("matrix");
    styleOptions.add("table");
  }
  
  /**
   * Generates an unnamed <code>ArrayProperties</code> object.
   */
  public MatrixProperties() {
    super();
    fillHashMap();
  }

  /**
   * Generates a named <code>ArrayProperties</code> object.
   * 
   * @param name
   *          the name for this <code>ArrayProperties</code>.
   */
  public MatrixProperties(String name) {
    super(name);
    fillHashMap();
  }

  /**
   * @see algoanim.properties.AnimationProperties#fillHashMap()
   */
  protected void fillHashMap() {
    // data.put(AnimationPropertiesKeys.NAME, "name");
    data.put(AnimationPropertiesKeys.COLOR_PROPERTY,
        new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.FILL_PROPERTY,
        new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.FILLED_PROPERTY,
        new BooleanPropertyItem());
    data.put(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY,
        new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY,
        new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY,
        new ColorPropertyItem());
    data.put(AnimationPropertiesKeys.FONT_PROPERTY,
        new FontPropertyItem());
    data.put(AnimationPropertiesKeys.DEPTH_PROPERTY,
        new IntegerPropertyItem());
    data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY,
        new BooleanPropertyItem());
    data.put(AnimationPropertiesKeys.GRID_ALIGN_PROPERTY,
        new EnumerationPropertyItem(alignOptions));
//        new EnumerationPropertyItem("left", new String[] {"left", "center", "right"}));
    data.put(AnimationPropertiesKeys.GRID_STYLE_PROPERTY,
        new EnumerationPropertyItem(styleOptions));
//        new EnumerationPropertyItem("plain", new String[] {"plain", "matrix", "table"}));
    // missing:
    // * ENUM style (plain | matrix | table)
    // * boolean fixedcellsize
    // * Color borderColor
    // * Color highlightBorderColor
    // * ENUM align (left | center | right)
    fillAdditional();
  }
}
