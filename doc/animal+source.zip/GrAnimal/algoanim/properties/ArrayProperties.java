package algoanim.properties;

import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;


/**
 * @author Jens Pfau, Stephan Mehlhase
 * @see	algoanim.properties.AnimationProperties
 */

public class ArrayProperties extends AnimationProperties {

	/**
	 * Generates an unnamed <code>ArrayProperties</code> object.
	 */
	public ArrayProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>ArrayProperties</code> object.
	 * @param name 		the name for this <code>ArrayProperties</code>.
	 */
	public ArrayProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {
//		data.put(AnimationPropertiesKeys.NAME, "name");
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILL_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.FILLED_PROPERTY, new BooleanPropertyItem());		
		data.put(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY, new ColorPropertyItem());
		/*
		 *	DIRECTION_PROPERTY == false means: direction == horizontal (standard) 
		 *  				   == true means: direction == vertical 
		 */
		data.put(AnimationPropertiesKeys.DIRECTION_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.CASCADED_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());
		fillAdditional();
	}	

}
