package algoanim.properties;


import algoanim.properties.items.BooleanPropertyItem;
import algoanim.properties.items.ColorPropertyItem;
import algoanim.properties.items.FontPropertyItem;
import algoanim.properties.items.IntegerPropertyItem;



/**
 * @author jens
 * 
 */

public class SourceCodeProperties extends AnimationProperties  {

	/**
	 * Generates an unnamed <code>SourceCodeProperties</code> object.
	 */
	public SourceCodeProperties() {
		super();
		fillHashMap();
	}

	/**
	 * Generates a named <code>SourceCodeProperties</code> object.
	 * @param name 		the name
	 */
	public SourceCodeProperties(String name) {
		super(name);
		fillHashMap();
	}
	

	/**
	 * @see algoanim.properties.AnimationProperties#fillHashMap()
	 */
	protected void fillHashMap() {	
		data.put(AnimationPropertiesKeys.CONTEXTCOLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.INDENTATION_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.ROW_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.FONT_PROPERTY, new FontPropertyItem());
		data.put(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY, new ColorPropertyItem());		
		data.put(AnimationPropertiesKeys.COLOR_PROPERTY, new ColorPropertyItem());
		data.put(AnimationPropertiesKeys.DEPTH_PROPERTY, new IntegerPropertyItem());
		data.put(AnimationPropertiesKeys.HIDDEN_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.SIZE_PROPERTY, new IntegerPropertyItem(10,6,100));
		data.put(AnimationPropertiesKeys.BOLD_PROPERTY, new BooleanPropertyItem());
		data.put(AnimationPropertiesKeys.ITALIC_PROPERTY, new BooleanPropertyItem());
		fillAdditional();
	}	
	

}
