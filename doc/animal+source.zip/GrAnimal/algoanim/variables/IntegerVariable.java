package algoanim.variables;

public class IntegerVariable extends Variable {

	private static final Integer defaultValue = 0;
	private Integer value;

	public IntegerVariable() {
		this(defaultValue);
	}

	public IntegerVariable(Integer value) {
		super(VariableTypes.INTEGER);
		this.value = value;
	}

	public <T> T getValue(Class<T> type) {
		T result = null;

		if (type == Boolean.class) {
			Boolean b = value != 0;
			result = type.cast(b);
		} else if (type == Byte.class) {
			Byte b = value.byteValue();
			result = type.cast(b);
		} else if (type == Double.class) {
			Double d = value.doubleValue();
			result = type.cast(d);
		} else if (type == Float.class) {
			Float f = value.floatValue();
			result = type.cast(f);
		} else if (type == Integer.class) {
			result = type.cast(value);
		} else if (type == Long.class) {
			Long l = value.longValue();
			result = type.cast(l);
		} else if (type == Short.class) {
			Short s = value.shortValue();
			result = type.cast(s);
		} else if (type == String.class) {
			String s = value.toString();
			result = type.cast(s);
		} else {
			System.err.println("cannot cast variable to: " + type);
		}

		return result;
	}

	public void setValue(Boolean value) {
		if (value)
			setValue(1);
		else
			setValue(0);
	}

	public void setValue(Byte value) {
		setValue(value.intValue());
	}

	public void setValue(Double value) {
		setValue(value.intValue());
	}

	public void setValue(Float value) {
		setValue(value.intValue());
	}

	public void setValue(Integer value) {
		this.value = value;
		this.update();
	}

	public void setValue(Long value) {
		setValue(value.intValue());
	}

	public void setValue(Short value) {
		setValue(value.intValue());
	}

	public void setValue(String value) {
		try {
			setValue(Integer.parseInt(value));
		} catch (NumberFormatException eInt) {
			try {
				setValue(Float.parseFloat(value));
			} catch (NumberFormatException eFloat) {
				try {
					setValue(Double.parseDouble(value));
				} catch (NumberFormatException eDouble) {
					if ("TRUE".equalsIgnoreCase(value)
							|| "FALSE".equalsIgnoreCase(value))
						try {
							setValue(Boolean.parseBoolean(value));
						} catch (NumberFormatException eBool) {
							setError(value);
						}
					else
						setError(value);
				}

			}
		}
	}

	public void setValue(Variable var) {
		setValue(var.getValue(Integer.class));
	}

//	public static void main(String[] args) {
//		/*IntegerVariable var = new IntegerVariable("blubb");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue(1);
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue(2.1);
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("3");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("4.1");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("abc");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("true");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("FALSE");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));
//
//		var.setValue("tRue");
//		System.out.println(var.getName() + ":" + var.getValue(String.class));*/
//		Double d1 = 0.3;
//		Double d2 = 0.8;
//		Integer i1 = (new Double(d1 + d2)).intValue();
//		Integer i2 = d1.intValue() + d2.intValue();
//		Integer i3 = 7/2;
//		System.out.println("i1=" +i1 +", i2=" +i2 +", i3=" +i3);
////		System.out.println((new Float(Integer.MAX_VALUE)).intValue() +"/"+ Integer.MAX_VALUE);
//	}

	@Override
	public String toString() {
		return value.toString();
	}
}
