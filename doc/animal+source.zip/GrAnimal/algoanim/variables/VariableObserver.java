package algoanim.variables;

public interface VariableObserver {
	public void update();
}
