/**
 * 
 */
package algoanim.exceptions;

/**
 * @author Stephan Mehlhase, Jens Pfau
 *
 */
public class NotEnoughNodesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3590583928013446522L;

	public NotEnoughNodesException(String string) {
		super(string);
	}

}
