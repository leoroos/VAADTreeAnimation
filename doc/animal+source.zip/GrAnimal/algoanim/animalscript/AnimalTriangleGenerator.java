package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Triangle;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.TriangleGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.TriangleProperties;
import algoanim.util.Node;

/**
 * @see algoanim.primitives.generators.TriangleGenerator
 * @author Stephan Mehlhase
 */
public class AnimalTriangleGenerator extends AnimalGenerator implements
		TriangleGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalTriangleGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.TriangleGenerator
	 *      #create(algoanim.primitives.Triangle)
	 */
	public void create(Triangle t) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(t.getName()) || t.getName() == "") {
			t.setName("Triangle" + AnimalTriangleGenerator.count);
			AnimalTriangleGenerator.count++;
		}
		lang.addItem(t);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("triangle \"" + t.getName() + "\" ");
		Node[] p = t.getNodes();
		str.append(AnimalGenerator.makeNodeDef(p[0]));
		str.append(" " + AnimalGenerator.makeNodeDef(p[1]));
		str.append(" " + AnimalGenerator.makeNodeDef(p[2]));

		TriangleProperties props = t.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
						.booleanValue()) {
			str.append(" filled");
			if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
				str.append(" fillColor ");
				str.append(AnimalGenerator.makeColorDef(((Color) props
						.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
						((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
								.getGreen(), ((Color) props
								.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			}
		}
		str.append(AnimalGenerator.makeDisplayOptionsDef(t.getDisplayOptions(),
            props));

		lang.addLine(str);
	}
}
