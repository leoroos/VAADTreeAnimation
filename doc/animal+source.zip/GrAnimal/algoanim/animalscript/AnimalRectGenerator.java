package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Rect;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.RectGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.RectProperties;

/**
 * @see algoanim.primitives.generators.RectGenerator
 * @author Stephan Mehlhase
 */
public class AnimalRectGenerator extends AnimalGenerator implements
		RectGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalRectGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.RectGenerator
	 *      #create(algoanim.primitives.Rect)
	 */
	public void create(Rect arect) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(arect.getName()) || arect.getName() == "") {
			arect.setName("Rect" + AnimalRectGenerator.count);
			AnimalRectGenerator.count++;
		}
		lang.addItem(arect);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);

		str.append("rectangle \"").append(arect.getName()).append("\" ");
		str.append(AnimalGenerator.makeNodeDef(arect.getUpperLeft()));
		str.append(" ").append(AnimalGenerator.makeNodeDef(arect.getLowerRight()));

		RectProperties props = arect.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
						.booleanValue()) {
			str.append(" filled");
			if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
				str.append(" fillColor ");
				str.append(AnimalGenerator.makeColorDef(((Color) props
						.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
						((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
								.getGreen(), ((Color) props
								.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			}
		}
        str.append(AnimalGenerator.makeDisplayOptionsDef(arect.getDisplayOptions(), props));
//		str.append(AnimalGenerator
//						.makeDisplayOptionsDef(arect.getDisplayOptions()));
//        if (!(arect.getDisplayOptions() instanceof Hidden))
//          str.append(AnimalGenerator.makeHiddenDef(props));
		lang.addLine(str);
	}

}
