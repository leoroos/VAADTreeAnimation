package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Square;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.SquareGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.SquareProperties;

/**
 * @see algoanim.primitives.generators.SquareGenerator
 * @author Stephan Mehlhase
 */
public class AnimalSquareGenerator extends AnimalGenerator implements
		SquareGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalSquareGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.SquareGenerator
	 *      #create(algoanim.primitives.Square)
	 */
	public void create(Square s) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(s.getName()) || s.getName() == "") {
			s.setName("Square" + AnimalSquareGenerator.count);
			AnimalSquareGenerator.count++;
		}
		lang.addItem(s);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("square \"" + s.getName() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(s.getUpperLeft()));
		str.append(" " + s.getWidth());

		SquareProperties props = s.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
						.booleanValue()) {
			str.append(" filled");
			if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
				str.append(" fillColor ");
				str.append(AnimalGenerator.makeColorDef(((Color) props
						.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
						((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
								.getGreen(), ((Color) props
								.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			}
		}
		str.append(AnimalGenerator.makeDisplayOptionsDef(s.getDisplayOptions(),
            props));
		lang.addLine(str);
	}
}
