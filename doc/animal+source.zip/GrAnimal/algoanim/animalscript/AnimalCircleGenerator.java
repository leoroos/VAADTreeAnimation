/*
 * Erstellung: 06.12.2004
 *
 */
package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Circle;
import algoanim.primitives.generators.CircleGenerator;
import algoanim.primitives.generators.Language;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.CircleProperties;

/**
 * @see algoanim.primitives.generators.CircleGenerator
 * @author Stephan Mehlhase
 */
public class AnimalCircleGenerator extends AnimalGenerator implements
		CircleGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalCircleGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.CircleGenerator
	 *      #create(algoanim.primitives.Circle)
	 */
	public void create(Circle acircle) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(acircle.getName()) || acircle.getName() == "") {
			acircle.setName("Circle" + AnimalCircleGenerator.count);
			AnimalCircleGenerator.count++;
		}
		lang.addItem(acircle);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("circle \"" + acircle.getName() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(acircle.getCenter()));
		str.append(" radius " + acircle.getRadius());

		CircleProperties props = acircle.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
						.booleanValue()) {
			str.append(" filled");
			if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
				str.append(" fillColor ");
				str.append(AnimalGenerator.makeColorDef(((Color) props
						.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
						((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
								.getGreen(), ((Color) props
								.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			}
		}
		str.append(AnimalGenerator.makeDisplayOptionsDef(
            acircle.getDisplayOptions(), props));
		lang.addLine(str);

	}
}
