package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.StringArray;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.StringArrayGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.ArrayProperties;
import algoanim.util.ArrayDisplayOptions;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.StringArrayGenerator
 * @author Stephan Mehlhase
 */
public class AnimalStringArrayGenerator extends AnimalGenerator implements
		StringArrayGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalStringArrayGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #create(algoanim.primitives.StringArray)
	 */
	public void create(StringArray anArray) {
		if (this.isNameUsed(anArray.getName()) || anArray.getName() == "") {
			anArray.setName("StringArray" + AnimalStringArrayGenerator.count);
			AnimalStringArrayGenerator.count++;
		}
		lang.addItem(anArray);

		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("array \"" + anArray.getName() + "\" "
				+ AnimalGenerator.makeNodeDef(anArray.getUpperLeft()) + " ");

		/* Properties */
		ArrayProperties ap = anArray.getProperties();

		if (ap.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append("color "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.COLOR_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue())
					+ " ");
		}
		if (ap.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
			def
					.append("fillColor "
							+ AnimalGenerator.makeColorDef(((Color) ap
									.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
									((Color) ap.get(AnimationPropertiesKeys.FILL_PROPERTY))
											.getGreen(), ((Color) ap
											.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue())
							+ " ");
		}
		if (ap.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY) != null) {
			def.append("elementColor "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY) != null) {
			def.append("elemHighlight "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY) != null) {
			def.append("cellHighlight "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.DIRECTION_PROPERTY) != null
				&& ((Boolean) ap.get(AnimationPropertiesKeys.DIRECTION_PROPERTY))
						.booleanValue()) {
			def.append("vertical ");
		} else {
			def.append("horizontal ");
		}

		def.append("length " + anArray.getLength()).append(' ');

		for (int i = 0; i < anArray.getLength(); i++) {
			def.append("\"" + anArray.getData(i) + "\" ");
		}

		/* Properties */

		if (ap.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append("depth " + ap.get(AnimationPropertiesKeys.DEPTH_PROPERTY)
					+ " ");
		}

		ArrayDisplayOptions ado = (ArrayDisplayOptions) anArray.getDisplayOptions();

		if (ado != null) {
			Timing o = ado.getOffset();
			if (o != null) {
				def.append(" " + AnimalGenerator.makeOffsetTimingDef(o));
			}
			if (ado.getCascaded() == true) {
				def.append(" cascaded");
				Timing d = ado.getDuration();
				if (d != null) {
					def.append(AnimalGenerator.makeDurationTimingDef(d));
				}
			}

		}
        Boolean bpi = (Boolean)ap.get(AnimationPropertiesKeys.HIDDEN_PROPERTY);
		if (bpi != null && bpi.booleanValue())
          def.append("hidden ");
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator #put(
	 *      algoanim.primitives.StringArray, int, java.lang.String,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void put(StringArray sap, int where, String what, Timing delay,
			Timing duration) {
		String def = "arrayPut \"" + what + "\" on \"" + sap.getName()
				+ "\" position " + where;
		def += " " + AnimalGenerator.makeOffsetTimingDef(delay);
		def += " " + AnimalGenerator.makeDurationTimingDef(duration);
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator #swap(
	 *      algoanim.primitives.StringArray, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void swap(StringArray sap, int what, int with, Timing delay,
			Timing duration) {
		String def = "arraySwap on \"" + sap.getName() + "\" position " + what
				+ " with " + with;
		def += " " + AnimalGenerator.makeOffsetTimingDef(delay);
		def += " " + AnimalGenerator.makeDurationTimingDef(duration);
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #highlightCell( StringArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCell(StringArray sa, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayCell on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #highlightCell( StringArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCell(StringArray sa, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayCell on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #highlightElem( StringArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(StringArray sa, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayElem on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #highlightElem( StringArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(StringArray sa, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayElem on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #unhighlightCell( StringArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(StringArray sa, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayCell on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #unhighlightCell( StringArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(StringArray sa, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayCell on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #unhighlightElem( StringArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(StringArray sa, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayElem on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.StringArrayGenerator
	 *      #unhighlightElem( StringArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(StringArray sa, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayElem on \"");
		def.append(sa.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}
}
