package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Ellipse;
import algoanim.primitives.generators.EllipseGenerator;
import algoanim.primitives.generators.Language;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.EllipseProperties;

/**
 * @see algoanim.primitives.generators.EllipseGenerator
 * @author Stephan Mehlhase
 */
public class AnimalEllipseGenerator extends AnimalGenerator implements
		EllipseGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalEllipseGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.EllipseGenerator
	 *      #create(algoanim.primitives.Ellipse)
	 */
	public void create(Ellipse aellipse) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(aellipse.getName()) || aellipse.getName() == "") {
			aellipse.setName("Ellipse" + AnimalEllipseGenerator.count);
			AnimalEllipseGenerator.count++;
		}
		lang.addItem(aellipse);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("ellipse \"" + aellipse.getName() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(aellipse.getCenter()));
		str.append(" radius " + AnimalGenerator.makeNodeDef(aellipse.getRadius()));

		EllipseProperties props = aellipse.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
						.booleanValue()) {
			str.append(" filled");
			if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
				str.append(" fillColor ");
				str.append(AnimalGenerator.makeColorDef(((Color) props
						.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
						((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
								.getGreen(), ((Color) props
								.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			}
		}
		str.append(AnimalGenerator.makeDisplayOptionsDef(aellipse
				.getDisplayOptions(), props));
		lang.addLine(str);
	}
}
