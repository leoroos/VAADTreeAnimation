package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.Arc;
import algoanim.primitives.generators.ArcGenerator;
import algoanim.primitives.generators.Language;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.ArcProperties;

/**
 * @see algoanim.primitives.generators.ArcGenerator
 * @author Stephan Mehlhase
 */
public class AnimalArcGenerator extends AnimalGenerator implements ArcGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalArcGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.ArcGenerator
	 *      #create(algoanim.primitives.Arc)
	 */
	public void create(Arc ag) {
		// Check name, if used already, create a new one silently
		if (this.isNameUsed(ag.getName()) || ag.getName() == "") {
			ag.setName("Arc" + AnimalArcGenerator.count);
			AnimalArcGenerator.count++;
		}
		lang.addItem(ag);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("circleSeg \"" + ag.getName() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(ag.getCenter()));
		str.append(" radius " + AnimalGenerator.makeNodeDef(ag.getRadius()));

		ArcProperties props = ag.getProperties();
		if (props.get(AnimationPropertiesKeys.ANGLE_PROPERTY) != null) {
			str.append(" angle "
					+ props.get(AnimationPropertiesKeys.ANGLE_PROPERTY).toString());
		}
		if (props.get(AnimationPropertiesKeys.STARTANGLE_PROPERTY) != null) {
			str.append(" startAngle "
					+ props.get(AnimationPropertiesKeys.STARTANGLE_PROPERTY).toString());
		}
		if (props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY))
						.booleanValue()) {
			str.append(" clockwise ");
		} else if (props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY) != null
				&& ((Boolean) props
						.get(AnimationPropertiesKeys.COUNTERCLOCKWISE_PROPERTY))
						.booleanValue()) {
			str.append(" counterclockwise ");
		}
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.CLOSED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.CLOSED_PROPERTY))
						.booleanValue()) {
			str.append(" closed ");
			if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
							.booleanValue()) {
				str.append(" filled");
				if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
					str.append(" fillColor ");
					str.append(AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
							((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
				}
			}
		} else {
			if (props.get(AnimationPropertiesKeys.FWARROW_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.FWARROW_PROPERTY))
							.booleanValue()) {
				str.append(" fwarrow ");
			}
			if (props.get(AnimationPropertiesKeys.BWARROW_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.BWARROW_PROPERTY))
							.booleanValue()) {
				str.append(" bwarrow ");
			}
		}

		str.append(AnimalGenerator.makeDisplayOptionsDef(ag.getDisplayOptions(), props));

		lang.addLine(str);
	}
}
