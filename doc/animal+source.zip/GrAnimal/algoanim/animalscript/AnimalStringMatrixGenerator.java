package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.StringMatrix;
import algoanim.primitives.generators.StringMatrixGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.MatrixProperties;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.StringMatrixGenerator
 * @author Dr. Guido Roessling (roessling@acm.org>
 * @version 0.4 2007-04-04
 */
public class AnimalStringMatrixGenerator extends AnimalGenerator implements
		StringMatrixGenerator {
	private static int count = 1;

	/**
	 * @param as
	 *          the associated <code>Language</code> object.
	 */
	public AnimalStringMatrixGenerator(AnimalScript as) {
		super(as);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #create(algoanim.primitives.StringMatrix)
	 */
	public void create(StringMatrix aMatrix) {
		if (isNameUsed(aMatrix.getName()) || aMatrix.getName().equals("")) {
			aMatrix.setName("StringMatrix" + AnimalStringMatrixGenerator.count);
			AnimalStringMatrixGenerator.count++;
		}
		lang.addItem(aMatrix);
		// TODO really OK like this?
		lang.nextStep(); 

		//grid <id> <nodeDefinition> [lines <n>] [colums <n>]
		//							 [style = (plain|matrix|table|junctions)]
		//                           [cellwidth <n>] [maxcellwidth <n>]
		//                           [fixedcellsize]
		//                           [color <color>] [textcolor <color>] 
		//                           [fillcolor <color>] [highlighttextcolor <color>] 
		//                           [highlightbackcolor <color>]
		//                           [matrixstyle|tablestyle|junctions]
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("grid \"").append(aMatrix.getName()).append("\" ");
		def.append(AnimalGenerator.makeNodeDef(aMatrix.getUpperLeft()));
		int nrRows = aMatrix.getNrRows(), nrCols = aMatrix.getNrCols();
		def.append(" lines ").append(nrRows).append(" columns ");
		def.append(nrCols).append(' ');

		/* Properties */
		MatrixProperties matrixProps = aMatrix.getProperties();

		if (matrixProps.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append("color ");
			def.append(AnimalGenerator.makeColorDef(((Color) matrixProps.get(
							AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
							((Color)matrixProps.get(
									AnimationPropertiesKeys.COLOR_PROPERTY)).getGreen(), 
							((Color) matrixProps.get(
									AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY) != null) {
			def.append("textColor ").append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getGreen(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getBlue()));
			def.append(" ");
		}

		if (matrixProps.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
			def.append("fillColor ").append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getGreen(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY) != null) {
			def.append("highlightTextColor ");
			def.append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getGreen(), 
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY) != null) {
			def.append("highlightBackColor ");
			def.append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getGreen(), 
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getBlue()));
			def.append(" ");
		}
		/* Properties */
		if (matrixProps.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append("depth ");
			def.append(matrixProps.get(AnimationPropertiesKeys.DEPTH_PROPERTY));
		  def.append(" ");
		}
		//TODO Display Options!
//		DisplayOptions ado = aMatrix.getDisplayOptions();
//
//		if (ado != null) {
//			Timing o = ado.getOffset();
//			if (o != null) {
//				def.append(" " + AnimalGenerator.makeOffsetTimingDef(o));
//			}
//			if (ado.getCascaded() == true) {
//				def.append(" cascaded");
//				Timing d = ado.getDuration();
//				if (d != null) {
//					def.append(AnimalGenerator.makeDurationTimingDef(d));
//				}
//			}
//		}
		lang.addLine(def);
		// generate the elements...
		for (int row = 0; row < nrRows; row++) {
			for (int col = 0; col < nrCols; col++) {
				StringBuilder sb = new StringBuilder(128);
				sb.append("setGridValue \"").append(aMatrix.getName());
				sb.append("[").append(row).append("][").append(col);
				sb.append("]\" \"").append(aMatrix.getElement(row, col));
				sb.append("\"");
				if (row == nrRows - 1 && col == nrCols - 1)
					sb.append(" refresh");
				lang.addLine(sb.toString());
			}
		}
	}

	private void finishDefinition(StringBuilder sb, Timing delay, 
			Timing duration) {
		sb.append(AnimalGenerator.makeDurationTimingDef(duration));
		sb.append(AnimalGenerator.makeOffsetTimingDef(delay));
		lang.addLine(sb.toString());
	}
	
	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator #put(
	 *      algoanim.primitives.StringMatrix, int, int, String,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void put(StringMatrix intMatrix, int row, int col, 
			String what, Timing delay,
			Timing duration) {
		// setgridvalue "<id>[<line>][<column>]" "<value>" [refresh] 
		// [within...] [after...]
		StringBuilder sb = new StringBuilder(128);
		sb.append("setGridValue \"").append(intMatrix.getName()).append("[");
		sb.append(row).append("][").append(col).append("]\" \"");
		sb.append(what).append("\" refresh ");
		finishDefinition(sb, delay, duration);
	}
	
	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator#swap(
	 *      algoanim.primitives.StringMatrix, int, int, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void swap(StringMatrix intMatrix, int sourceRow, int sourceCol, 
			int targetRow, int targetCol, Timing delay, Timing duration) {
		// swapgridvalues "<id1>[<line1>][<column1>]" and "<id2>[<line2>][<column2>]"
		// [refresh] [within...] [after...]
		StringBuilder sb = new StringBuilder(128);
		sb.append("swapGridValues \"").append(intMatrix.getName()).append("[");
		sb.append(sourceRow).append("][").append(sourceCol);
		sb.append("]\" and \"").append(intMatrix.getName()).append("[");
		sb.append(targetRow).append("][").append(targetCol).append("]\" refresh ");
		finishDefinition(sb, delay, duration);
	}
	
	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightCell(StringMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCell(StringMatrix intMatrix, int row, int col,
			Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]

		StringBuilder sb = new StringBuilder(128);
		sb.append("highlightGridCell \"").append(intMatrix.getName());
		sb.append("[").append(row).append("][").append(col).append("]\" ");
		finishDefinition(sb, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightCellColumnRange( StringMatrix, int, int, int,
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCellColumnRange(StringMatrix intMatrix, int row, int startCol,
			int endCol, Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startCol == 0 && endCol == intMatrix.getNrCols() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("highlightGridCell \"").append(intMatrix.getName());
			sb.append("[").append(row).append("][]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int col = startCol; col <= endCol; col++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("highlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightCellRowRange( StringMatrix, int, int, int,
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCellRowRange(StringMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startRow == 0 && endRow == intMatrix.getNrRows() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("highlightGridCell \"").append(intMatrix.getName());
			sb.append("[][").append(col).append("]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int row = startRow; row <= endRow; row++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("highlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightElem( StringMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(StringMatrix intMatrix, int row, int col, Timing offset,
			Timing duration) {
		highlightCell(intMatrix, row, col, offset, duration);
	}
	
	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightElemColumnRange( StringMatrix, int, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElemColumnRange(StringMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		highlightCellColumnRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #highlightElemRowRange( StringMatrix, int, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElemRowRange(StringMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		highlightCellColumnRange(intMatrix, startRow, endRow, col, 
				offset, duration);
	}


	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightCell( StringMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(StringMatrix intMatrix, int row, int col,
			Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		StringBuilder sb = new StringBuilder(128);
		sb.append("unhighlightGridCell \"").append(intMatrix.getName());
		sb.append("[").append(row).append("][").append(col).append("]\" ");
		finishDefinition(sb, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightCell( StringMatrix, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCellColumnRange(StringMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startCol == 0 && endCol == intMatrix.getNrCols() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("unhighlightGridCell \"").append(intMatrix.getName());
			sb.append("[").append(row).append("][]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int col = startCol; col <= endCol; col++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("unhighlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightCell( StringMatrix, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCellRowRange(StringMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startRow == 0 && endRow == intMatrix.getNrRows() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("unhighlightGridCell \"").append(intMatrix.getName());
			sb.append("[][").append(col).append("]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int row = startRow; row <= endRow; row++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("unhighlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]");
				finishDefinition(sb, offset, duration);
			}
		}
	}
	
	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightElem( StringMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(StringMatrix intMatrix, int row, int col, 
			Timing offset, Timing duration) {
		unhighlightCell(intMatrix, row, col, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightElemColumnRange( StringMatrix, int, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElemColumnRange(StringMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		unhighlightCellColumnRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.StringMatrixGenerator
	 *      #unhighlightElemRowRange( StringMatrix, int, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElemRowRange(StringMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		unhighlightCellRowRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}
}
