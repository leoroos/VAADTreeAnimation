package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.IntMatrix;
import algoanim.primitives.generators.IntMatrixGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.MatrixProperties;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.IntMatrixGenerator
 * @author Dr. Guido Roessling (roessling@acm.org>
 * @version 0.4 2007-04-04
 */
public class AnimalIntMatrixGenerator extends AnimalGenerator implements
		IntMatrixGenerator {
	private static int count = 1;

	/**
	 * @param as
	 *          the associated <code>Language</code> object.
	 */
	public AnimalIntMatrixGenerator(AnimalScript as) {
		super(as);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #create(algoanim.primitives.IntMatrix)
	 */
	public void create(IntMatrix aMatrix) {
		if (isNameUsed(aMatrix.getName()) || aMatrix.getName().equals("")) {
			aMatrix.setName("IntMatrix" + AnimalIntMatrixGenerator.count);
			AnimalIntMatrixGenerator.count++;
		}
		lang.addItem(aMatrix);
		// TODO really OK like this?
//		lang.nextStep(); 

		//grid <id> <nodeDefinition> [lines <n>] [colums <n>]
		//							 [style = (plain|matrix|table|junctions)]
		//                           [cellwidth <n>] [maxcellwidth <n>]
		//                           [fixedcellsize]
		//                           [color <color>] [textcolor <color>] 
		//                           [fillcolor <color>] [highlighttextcolor <color>] 
		//                           [highlightbackcolor <color>]
		//                           [matrixstyle|tablestyle|junctions]
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("grid \"").append(aMatrix.getName()).append("\" ");
		def.append(AnimalGenerator.makeNodeDef(aMatrix.getUpperLeft()));
		int nrRows = aMatrix.getNrRows(), nrCols = aMatrix.getNrCols();
		def.append(" lines ").append(nrRows).append(" columns ");
		def.append(nrCols).append(' ');

		/* Properties */
		MatrixProperties matrixProps = aMatrix.getProperties();

		if (matrixProps.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append("color ");
			def.append(AnimalGenerator.makeColorDef(((Color) matrixProps.get(
							AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
							((Color)matrixProps.get(
									AnimationPropertiesKeys.COLOR_PROPERTY)).getGreen(), 
							((Color) matrixProps.get(
									AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY) != null) {
			def.append("textColor ").append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getGreen(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getBlue()));
			def.append(" ");
		}

		if (matrixProps.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
			def.append("fillColor ").append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getGreen(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY) != null) {
			def.append("highlightTextColor ");
			def.append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getGreen(), 
					((Color) matrixProps.get(
							AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getBlue()));
			def.append(" ");
		}
		if (matrixProps.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY) != null) {
			def.append("highlightBackColor ");
			def.append(AnimalGenerator.makeColorDef(
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getRed(),
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getGreen(), 
					((Color) matrixProps.get(
							AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getBlue()));
			def.append(" ");
		}
		/* Properties */
		if (matrixProps.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append("depth ");
			def.append(matrixProps.get(AnimationPropertiesKeys.DEPTH_PROPERTY));
		  def.append(" ");
		}
		//TODO Display Options!
//		DisplayOptions ado = aMatrix.getDisplayOptions();
//
//		if (ado != null) {
//			Timing o = ado.getOffset();
//			if (o != null) {
//				def.append(" " + AnimalGenerator.makeOffsetTimingDef(o));
//			}
//			if (ado.getCascaded() == true) {
//				def.append(" cascaded");
//				Timing d = ado.getDuration();
//				if (d != null) {
//					def.append(AnimalGenerator.makeDurationTimingDef(d));
//				}
//			}
//		}
		lang.addLine(def);
		// generate the elements...
		for (int row = 0; row < nrRows; row++) {
			for (int col = 0; col < nrCols; col++) {
				StringBuilder sb = new StringBuilder(128);
				sb.append("setGridValue \"").append(aMatrix.getName());
				sb.append("[").append(row).append("][").append(col);
				sb.append("]\" \"").append(aMatrix.getElement(row, col));
				sb.append("\"");
				if (row == nrRows - 1 && col == nrCols - 1)
					sb.append(" refresh");
				lang.addLine(sb.toString());
			}
		}
	}

	private void finishDefinition(StringBuilder sb, Timing delay, 
			Timing duration) {
		sb.append(AnimalGenerator.makeDurationTimingDef(duration));
		sb.append(AnimalGenerator.makeOffsetTimingDef(delay));
		lang.addLine(sb.toString());
	}
	
	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator #put(
	 *      algoanim.primitives.IntMatrix, int, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void put(IntMatrix intMatrix, int row, int col, int what, Timing delay,
			Timing duration) {
		// setgridvalue "<id>[<line>][<column>]" "<value>" [refresh] 
		// [within...] [after...]
		StringBuilder sb = new StringBuilder(128);
		sb.append("setGridValue \"").append(intMatrix.getName()).append("[");
		sb.append(row).append("][").append(col).append("]\" \"");
		sb.append(what).append("\" refresh ");
		finishDefinition(sb, delay, duration);
	}
	
	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator#swap(
	 *      algoanim.primitives.IntMatrix, int, int, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void swap(IntMatrix intMatrix, int sourceRow, int sourceCol, 
			int targetRow, int targetCol, Timing delay, Timing duration) {
		// swapgridvalues "<id1>[<line1>][<column1>]" and "<id2>[<line2>][<column2>]"
		// [refresh] [within...] [after...]
		StringBuilder sb = new StringBuilder(128);
		sb.append("swapGridValues \"").append(intMatrix.getName()).append("[");
		sb.append(sourceRow).append("][").append(sourceCol);
		sb.append("]\" and \"").append(intMatrix.getName()).append("[");
		sb.append(targetRow).append("][").append(targetCol).append("]\" refresh ");
		finishDefinition(sb, delay, duration);
	}
	
	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightCell( IntMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCell(IntMatrix intMatrix, int row, int col,
			Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]

		StringBuilder sb = new StringBuilder(128);
		sb.append("highlightGridCell \"").append(intMatrix.getName());
		sb.append("[").append(row).append("][").append(col).append("]\" ");
		finishDefinition(sb, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightCellColumnRange( IntMatrix, int, int, int,
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCellColumnRange(IntMatrix intMatrix, int row, int startCol,
			int endCol, Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startCol == 0 && endCol == intMatrix.getNrCols() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("highlightGridCell \"").append(intMatrix.getName());
			sb.append("[").append(row).append("][]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int col = startCol; col <= endCol; col++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("highlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightCellRowRange( IntMatrix, int, int, int,
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCellRowRange(IntMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		// highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startRow == 0 && endRow == intMatrix.getNrRows() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("highlightGridCell \"").append(intMatrix.getName());
			sb.append("[][").append(col).append("]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int row = startRow; row <= endRow; row++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("highlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @inheritDoc
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightElem( IntMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(IntMatrix intMatrix, int row, int col, Timing offset,
	    Timing duration) {
	  // highlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
	  StringBuilder sb = new StringBuilder(512);
	  sb.append("highlightGridElem \"").append(intMatrix.getName());
	  sb.append("[").append(row).append("][").append(col).append("]\" ");
	  finishDefinition(sb, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightElemColumnRange( IntMatrix, int, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElemColumnRange(IntMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		highlightCellRowRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #highlightElemRowRange( IntMatrix, int, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElemRowRange(IntMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		highlightCellRowRange(intMatrix, startRow, endRow, col, 
				offset, duration);
	}


	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightCell( IntMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(IntMatrix intMatrix, int row, int col,
			Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		StringBuilder sb = new StringBuilder(128);
		sb.append("unhighlightGridCell \"").append(intMatrix.getName());
		sb.append("[").append(row).append("][").append(col).append("]\" ");
		finishDefinition(sb, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightCell( IntMatrix, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCellColumnRange(IntMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startCol == 0 && endCol == intMatrix.getNrCols() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("unhighlightGridCell \"").append(intMatrix.getName());
			sb.append("[").append(row).append("][]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int col = startCol; col <= endCol; col++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("unhighlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]\" ");
				finishDefinition(sb, offset, duration);
			}
		}
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightCell( IntMatrix, int, int, 
	 *      algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCellRowRange(IntMatrix intMatrix, int startRow, 
			int endRow, int col, Timing offset, Timing duration) {
		// unhighlightgridcell "<id>[<line>][<column>]" <boolean> [timing]
		if (startRow == 0 && endRow == intMatrix.getNrRows() - 1) {
			StringBuilder sb = new StringBuilder(512);
			sb.append("unhighlightGridCell \"").append(intMatrix.getName());
			sb.append("[][").append(col).append("]\" ");
			finishDefinition(sb, offset, duration);
		} else {
			for (int row = startRow; row <= endRow; row++) {
				StringBuilder sb = new StringBuilder(512);
				sb.append("unhighlightGridCell \"").append(intMatrix.getName());
				sb.append("[").append(row).append("][").append(col).append("]");
				finishDefinition(sb, offset, duration);
			}
		}
	}
	
	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightElem( IntMatrix, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(IntMatrix intMatrix, int row, int col, 
			Timing offset, Timing duration) {
		unhighlightCell(intMatrix, row, col, offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightElemColumnRange( IntMatrix, int, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElemColumnRange(IntMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		unhighlightCellColumnRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}

	/**
	 * @see algoanim.primitives.generators.IntMatrixGenerator
	 *      #unhighlightElemRowRange( IntMatrix, int, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElemRowRange(IntMatrix intMatrix, int row, 
			int startCol, int endCol, Timing offset, Timing duration) {
		unhighlightCellRowRange(intMatrix, row, startCol, endCol, 
				offset, duration);
	}
}
