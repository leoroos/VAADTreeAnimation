package algoanim.animalscript;

import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;

import algoanim.primitives.SourceCode;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.SourceCodeGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.SourceCodeProperties;
import algoanim.util.Timing;

/**
 * @author Stephan Mehlhase
 * 
 */
public class AnimalSourceCodeGenerator extends AnimalGenerator implements
		SourceCodeGenerator {
	private static int count = 1;
	private HashMap<String, Integer> labelsToLineNumbers;
	
	public AnimalSourceCodeGenerator(Language aLang) {
		super(aLang);
		labelsToLineNumbers = new HashMap<String, Integer>(47);
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator
	 *      #create(algoanim.primitives.SourceCode)
	 */
	public void create(SourceCode sc) {
		if (this.isNameUsed(sc.getName()) || sc.getName() == "") {
			sc.setName("SourceCode" + AnimalSourceCodeGenerator.count);
			AnimalSourceCodeGenerator.count++;
		}
		lang.addItem(sc);

		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("codegroup \"" + sc.getName() + "\"");
		def.append(" at " + AnimalGenerator.makeNodeDef(sc.getUpperLeft()));

		SourceCodeProperties props = sc.getProperties();
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append(" color ");
			def.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY) != null) {
			def.append(" highlightColor ");
			def
					.append(AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY)).getRed(),
							((Color) props
									.get(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.HIGHLIGHTCOLOR_PROPERTY))
									.getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.CONTEXTCOLOR_PROPERTY) != null) {
			def.append(" contextColor ");
			def.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.CONTEXTCOLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.CONTEXTCOLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.CONTEXTCOLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null) {
			def.append(" font "
					+ ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY))
							.getFamily()); // was: getFontName()
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null) {
			def
					.append(" size "
							+ ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY))
									.getSize());
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null
				&& ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY)).isBold()) {
			def.append(" bold");
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null
				&& ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY)).isItalic()) {
			def.append(" italic");
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}

		def.append(AnimalGenerator.makeDisplayOptionsDef(sc.getDisplayOptions(), props));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator #highlight(
	 *      algoanim.primitives.SourceCode, int, int, boolean,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void highlight(SourceCode code, int line, int row, boolean context,
			Timing delay, Timing duration) {
		String def = "highlightCode on \"" + code.getName() + "\" line " + line;
		if (row >= 0) {
			def += " row " + row;
		}
		if (context) {
			def += " context";
		}
		def += AnimalGenerator.makeOffsetTimingDef(delay);
		def += AnimalGenerator.makeDurationTimingDef(duration);
		lang.addLine(def);
	}
	
	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator#highlight(
	 *      algoanim.primitives.SourceCode, int, int, boolean,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void highlight(SourceCode code, String lineName, int row, boolean context,
			Timing delay, Timing duration) {
		Integer lineNo = labelsToLineNumbers.get(lineName);
		if (lineNo != null) {
			highlight(code, lineNo.intValue(), row, context, delay, duration);
		} else
			System.err.println("@highlight(SC,S,i,b,T,T): argh! lineno is null for " + lineName);
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator
	 *      #unhighlight( algoanim.primitives.SourceCode, int, int,
	 *      boolean, algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void unhighlight(SourceCode code, String lineName, int row, boolean context,
			Timing delay, Timing duration) {
		Integer lineNo = labelsToLineNumbers.get(lineName);
		if (lineNo != null) {
			unhighlight(code, lineNo.intValue(), row, context, delay, duration);
		} else
			System.err.println("@unhighlight(SC,S,i,b,T,T): argh -- lineno is null for " + lineName);
	}
	
	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator
	 *      #unhighlight( algoanim.primitives.SourceCode, int, int,
	 *      boolean, algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void unhighlight(SourceCode code, int line, int row, boolean context,
			Timing delay, Timing duration) {
		String def = "unhighlightCode on \"" + code.getName() + "\" line " + line;
		if (row >= 0) {
			def += " row " + row;
		}
		if (context) {
			def += " context";
		}
		def += AnimalGenerator.makeOffsetTimingDef(delay);
		def += AnimalGenerator.makeDurationTimingDef(duration);
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator #hide(
	 *      algoanim.primitives.SourceCode, algoanim.util.Timing)
	 */
	public void hide(SourceCode code, Timing delay) {
		lang.addLine("hideCode \"" + code.getName() + "\" "
				+ AnimalGenerator.makeOffsetTimingDef(delay));
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator
	 *      #addCodeElement( algoanim.primitives.SourceCode,
	 *      java.lang.String, java.lang.String, int, int,
	 *      algoanim.util.Timing)
	 */
	public void addCodeElement(SourceCode code, String codeline, String name,
			int indentation, int row, Timing t) {
		// achte hier mal darauf, dass name und t null sein k�nnen.
		// dann entsprechend behandeln
		String str = "addCodeElem \"" + codeline + "\" ";
//		if (name != null && name != "") {
//			str += "name \"" + name + "\" ";
////			labelsToLineNumbers.put(name, new Integer(codeline));
//		}
		str += "to \"" + code.getName() +"\"";
		if (row > 0) {
			str += " row " + row;
		}
		if (indentation > 0) {
			str += " indentation " + indentation;
		}
		// AnimalGenerator.makeTimingDef checks if t == null.
		str += AnimalGenerator.makeOffsetTimingDef(t);
		lang.addLine(str);
	}

	/**
	 * @see algoanim.primitives.generators.SourceCodeGenerator
	 *      #addCodeLine( algoanim.primitives.SourceCode, java.lang.String,
	 *      java.lang.String, int, algoanim.util.Timing)
	 */
	public void addCodeLine(SourceCode code, String codeline, String name,
			int indentation, Timing t) {
		// achte hier mal darauf, dass name und t null sein k�nnen.
		// dann entsprechend behandeln
		String str = "addCodeLine \"" + codeline + "\" ";
//		if (name != null && name != "") {
//			str += "name \"" + name + "\" ";
////			labelsToLineNumbers.put(name, new Integer(codeline));
//		}
		str += "to \"" + code.getName() +"\"";
		if (indentation > 0) {
			str += " indentation " + indentation;
		}
		// AnimalGenerator.makeTimingDef checks if t == null.
		str += AnimalGenerator.makeOffsetTimingDef(t);
		lang.addLine(str);
	}
}
