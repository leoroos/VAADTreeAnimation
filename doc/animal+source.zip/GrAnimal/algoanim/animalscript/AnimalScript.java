package algoanim.animalscript;



import java.io.FileWriter;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import algoanim.exceptions.NotEnoughNodesException;
import algoanim.interactionsupport.DocumentationLink;
import algoanim.interactionsupport.FillInBlanksQuestion;
import algoanim.interactionsupport.GroupInfo;
import algoanim.interactionsupport.InteractiveElement;
import algoanim.interactionsupport.MultipleChoiceQuestion;
import algoanim.interactionsupport.MultipleSelectionQuestion;
import algoanim.interactionsupport.TrueFalseQuestion;
import algoanim.interactionsupport.generators.InteractiveElementGenerator;
import algoanim.primitives.Arc;
import algoanim.primitives.ArrayBasedQueue;
import algoanim.primitives.ArrayBasedStack;
import algoanim.primitives.ArrayMarker;
import algoanim.primitives.ArrayPrimitive;
import algoanim.primitives.Circle;
import algoanim.primitives.CircleSeg;
import algoanim.primitives.ConceptualQueue;
import algoanim.primitives.ConceptualStack;
import algoanim.primitives.DoubleArray;
import algoanim.primitives.Ellipse;
import algoanim.primitives.EllipseSeg;
import algoanim.primitives.Graph;
import algoanim.primitives.Group;
import algoanim.primitives.IntArray;
import algoanim.primitives.IntMatrix;
import algoanim.primitives.ListBasedQueue;
import algoanim.primitives.ListBasedStack;
import algoanim.primitives.ListElement;
import algoanim.primitives.Point;
import algoanim.primitives.Polygon;
import algoanim.primitives.Polyline;
import algoanim.primitives.Primitive;
import algoanim.primitives.Rect;
import algoanim.primitives.SourceCode;
import algoanim.primitives.Square;
import algoanim.primitives.StringArray;
import algoanim.primitives.StringMatrix;
import algoanim.primitives.Text;
import algoanim.primitives.Triangle;
import algoanim.primitives.Variables;
import algoanim.primitives.generators.AnimalVariablesGenerator;
import algoanim.primitives.generators.ArcGenerator;
import algoanim.primitives.generators.ArrayBasedQueueGenerator;
import algoanim.primitives.generators.ArrayBasedStackGenerator;
import algoanim.primitives.generators.ArrayMarkerGenerator;
import algoanim.primitives.generators.CircleGenerator;
import algoanim.primitives.generators.CircleSegGenerator;
import algoanim.primitives.generators.ConceptualQueueGenerator;
import algoanim.primitives.generators.ConceptualStackGenerator;
import algoanim.primitives.generators.DoubleArrayGenerator;
import algoanim.primitives.generators.EllipseGenerator;
import algoanim.primitives.generators.EllipseSegGenerator;
import algoanim.primitives.generators.GraphGenerator;
import algoanim.primitives.generators.GroupGenerator;
import algoanim.primitives.generators.IntArrayGenerator;
import algoanim.primitives.generators.IntMatrixGenerator;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.ListBasedQueueGenerator;
import algoanim.primitives.generators.ListBasedStackGenerator;
import algoanim.primitives.generators.ListElementGenerator;
import algoanim.primitives.generators.PointGenerator;
import algoanim.primitives.generators.PolygonGenerator;
import algoanim.primitives.generators.PolylineGenerator;
import algoanim.primitives.generators.RectGenerator;
import algoanim.primitives.generators.SourceCodeGenerator;
import algoanim.primitives.generators.SquareGenerator;
import algoanim.primitives.generators.StringArrayGenerator;
import algoanim.primitives.generators.StringMatrixGenerator;
import algoanim.primitives.generators.TextGenerator;
import algoanim.primitives.generators.TriangleGenerator;
import algoanim.primitives.generators.VariablesGenerator;
import algoanim.properties.ArcProperties;
import algoanim.properties.ArrayMarkerProperties;
import algoanim.properties.ArrayProperties;
import algoanim.properties.CircleProperties;
import algoanim.properties.CircleSegProperties;
import algoanim.properties.EllipseProperties;
import algoanim.properties.EllipseSegProperties;
import algoanim.properties.GraphProperties;
import algoanim.properties.ListElementProperties;
import algoanim.properties.MatrixProperties;
import algoanim.properties.PointProperties;
import algoanim.properties.PolygonProperties;
import algoanim.properties.PolylineProperties;
import algoanim.properties.QueueProperties;
import algoanim.properties.RectProperties;
import algoanim.properties.SourceCodeProperties;
import algoanim.properties.SquareProperties;
import algoanim.properties.StackProperties;
import algoanim.properties.TextProperties;
import algoanim.properties.TriangleProperties;
import algoanim.util.ArrayDisplayOptions;
import algoanim.util.DisplayOptions;
import algoanim.util.Node;

/**
 * @see algoanim.primitives.generators.Language
 * @author Jens Pfau, Stephan Mehlhase, Dima Vronskyi
 */
public class AnimalScript extends Language {
  /**
   * The initial size in kilobytes of the buffer used by the step mode.
   */
  public static int INITIAL_STEPBUFFER_SIZE = 4 * 1024;

  /**
   * The initial size in kilobytes of the output buffer.
   */
  public static int INITIAL_OUTPUTBUFFER_SIZE = 32 * 1024;

  /**
   * The initial size in kilobytes of the buffers used by generators.
   */
  public static int INITIAL_GENBUFFER_SIZE = 1 * 1024;

  /**
   * The initial size in kilobytes of the error buffer.
   */
  public static int INITIAL_ERRORBUFFER_SIZE = 4 * 1024;

  /**
   * The north west direction constant.
   */
  public static final String DIRECTION_NW = "NW";

  /**
   * The north direction constant.
   */
  public static final String DIRECTION_N = "N";

  /**
   * The north east direction constant.
   */
  public static final String DIRECTION_NE = "NE";

  /**
   * The west direction constant.
   */
  public static final String DIRECTION_W = "W";

  /**
   * The central direction constant.
   */
  public static final String DIRECTION_C = "C";

  /**
   * The east direction constant.
   */
  public static final String DIRECTION_E = "E";

  /**
   * The south west direction constant.
   */
  public static final String DIRECTION_SW = "SW";

  /**
   * The south direction constant.
   */
  public static final String DIRECTION_S = "S";

  /**
   * The south east direction constant.
   */
  public static final String DIRECTION_SE = "SE";

  /**
   * The direction constant for alignment from the (text) baseline's start.
   */
  public static final String DIRECTION_BASELINE_START = "baseline start";

  /**
   * The direction constant for alignment from the (text) baseline's end.
   */
  public static final String DIRECTION_BASELINE_END = "baseline end";
  
  /**
   * The color colortype constant.
   */
  public static final String COLORCHANGE_COLOR = "color";

  /**
   * The fillcolor colortype constant.
   */
  public static final String COLORCHANGE_FILLCOLOR = "fillColor";

  /**
   * The textcolor colortype constant.
   */
  public static final String COLORCHANGE_TEXTCOLOR = "textColor";

  /**
   * The colorsetting colortype constant.
   */
  public static final String COLORCHANGE_COLORSETTING = "colorSetting";

  /**
   * Controlls if the class is in Stepmode or not
   */
  private boolean stepMode = false;

  /**
   * Contains the complete output which is written to a file in the end during
   * the program. 32k ought by enough
   */
  private StringBuilder output = new StringBuilder(
      AnimalScript.INITIAL_OUTPUTBUFFER_SIZE);

  /**
   * Contains the complete output which is written to the output when the
   * StepMode is disabled. 4k per step ought be enough
   */
  private StringBuilder stepBuffer = new StringBuilder(
      AnimalScript.INITIAL_STEPBUFFER_SIZE);

  private StringBuilder errorBuffer = new StringBuilder(
      AnimalScript.INITIAL_ERRORBUFFER_SIZE);

  /**
   * Contains a list of names, used by primitives, used to check that every name
   * is unique.
   */
  private Vector<String> names = new Vector<String>();

  private ArcGenerator arcGen = null;

  /**
   * Generator for <code>Circle</code>s.
   */
  private CircleGenerator circleGen = null;

  /**
   * Generator for <code>CircleSeg</code>s.
   */
  private CircleSegGenerator circleSegGen = null;

  /**
   * Generator for <code>DoubleArray</code>s.
   */
  private DoubleArrayGenerator doubleArrayGen = null;

  /**
   * Generator for <code>Ellipse</code>s.
   */
  private EllipseGenerator ellipseGen = null;

  /**
   * Generator for <code>Ellipse</code>s.
   */
  private EllipseSegGenerator ellipseSegGen = null;
  
  /**
   * Generator for <code>Graph</code>s.
   */
  private GraphGenerator graphGen = null;
  
  /**
   * Generator for <code>IntArray</code>s.
   */
  private IntArrayGenerator intArrayGen = null;

  /**
   * Generator for <code>IntMatrix</code> elements.
   */
  private IntMatrixGenerator intMatrixGen = null;

  /**
   * Generator for <code>ListElement</code>s.
   */
  private ListElementGenerator listElemGen = null;

  /**
   * Generator for <code>Rect</code>s.
   */
  private RectGenerator rectGen = null;

  /**
   * Generator for <code>SourceCode</code>s.
   */
  private SourceCodeGenerator sourceGen = null;

  /**
   * Generator for <code>Square</code>s.
   */
  private SquareGenerator squareGen = null;

  /**
   * Generator for <code>StringArray</code>s.
   */
  private StringArrayGenerator stringArrayGen = null;
  
  /**
   * Generator for <code>StringMatrix</code> elements.
   */
  private StringMatrixGenerator stringMatrixGen = null;


  /**
   * Generator for <code>Text</code>s.
   */
  private TextGenerator textGen = null;

  /**
   * Generator for <code>Triangle</code>s.
   */
  private TriangleGenerator triangleGen = null;

  /**
   * Generator for <code>Polygon</code>s.
   */
  private PolygonGenerator polygonGen = null;

  /**
   * Generator for <code>Point</code>s.
   */
  private PointGenerator pointGen = null;

  /**
   * Generator for <code>ArrayMarker</code>s.
   */
  private ArrayMarkerGenerator amGen = null;

  /**
   * Generator for <code>Group</code>s.
   */
  private GroupGenerator groupGen = null;

  /**
   * Generator for <code>Polyline</code>s.
   */
  private PolylineGenerator polyGen = null;
  
  /**
   * Generator for <em>True/False Questions</em>.
   */
  private InteractiveElementGenerator internalQuestionSupportGen = null;

  /**
   * Generator for <em>Variables</em>.
   */
  private VariablesGenerator varGen = null;

  /**
   * All valid directions for AnimalScript move methods.
   */
  private Vector<String> directions;

  /**
   * Creates the headline of the AnimalScript File and the AnimalScript Object.
   * 
   * @param title
   *          the title of this AnimalScript. may be null.
   * @param author
   *          the autor of this AnimalScript. may be null.
   * @param x
   *          the width of the animation window.
   * @param y
   *          the height of the animation window.
   */
  public AnimalScript(String title, String author, int x, int y) {
    super(title, author, x, y);
    
    directions = new Vector<String>();
    directions.add(AnimalScript.DIRECTION_NW);
    directions.add(AnimalScript.DIRECTION_N);
    directions.add(AnimalScript.DIRECTION_NE);
    directions.add(AnimalScript.DIRECTION_W);
    directions.add(AnimalScript.DIRECTION_C);
    directions.add(AnimalScript.DIRECTION_E);
    directions.add(AnimalScript.DIRECTION_SW);
    directions.add(AnimalScript.DIRECTION_S);
    directions.add(AnimalScript.DIRECTION_SE);

    StringBuilder buf = new StringBuilder();
    buf.append("%Animal 2");
    if (x == Language.UNDEFINED_SIZE || y == Language.UNDEFINED_SIZE) {
      buf.append(" " + x + "*" + y);
    }

    if (title != null) {
      buf.append("\ntitle \"" + title + "\"");
    }

    if (author != null) {
      buf.append("\nauthor \"" + author + "\"");
    }

    addLine(buf);
    generateGenerators();
  }

  /**
   * Generates all generators needed.
   */
  private void generateGenerators() {
    arcGen = new AnimalArcGenerator(this);
    circleGen = new AnimalCircleGenerator(this);
    circleSegGen = new AnimalCircleSegGenerator(this);
    doubleArrayGen = new AnimalDoubleArrayGenerator(this);
    ellipseGen = new AnimalEllipseGenerator(this);
    ellipseSegGen = new AnimalEllipseSegGenerator(this);
    graphGen = new AnimalGraphGenerator(this);
    intArrayGen = new AnimalIntArrayGenerator(this);
    intMatrixGen = new AnimalIntMatrixGenerator(this);
    listElemGen = new AnimalListElementGenerator(this);
    rectGen = new AnimalRectGenerator(this);
    sourceGen = new AnimalSourceCodeGenerator(this);
    squareGen = new AnimalSquareGenerator(this);
    stringArrayGen = new AnimalStringArrayGenerator(this);
    stringMatrixGen = new AnimalStringMatrixGenerator(this);
    textGen = new AnimalTextGenerator(this);
    triangleGen = new AnimalTriangleGenerator(this);
    polygonGen = new AnimalPolygonGenerator(this);
    pointGen = new AnimalPointGenerator(this);
    amGen = new AnimalArrayMarkerGenerator(this);
    groupGen = new AnimalGroupGenerator(this);
    polyGen = new AnimalPolylineGenerator(this);
    varGen = new AnimalVariablesGenerator(this);
    
    internalQuestionSupportGen = 
      new AnimalJHAVETextInteractionGenerator(this);
  }

  /**
   * Adds a line to the concurrent buffer and determines if in stepmode or not.
   * The given string must not end with a newline character, which is
   * automatically appended.
   * 
   * @param line
   *          the line of AnimalScript code added, must NOT end with a newline.
   */
  public void addLine(StringBuilder line) {
    line.append("\r\n");
    if (stepMode) {
      stepBuffer.append(line);
    } else {
      output.append(line);
    }
  }

  /**
   * Adds a label to the current AnimalScript which can be used for navigation.
   * If the given label is null, no label is inserted.
   * 
   * @param label
   *          The label
   */
  public void addLabel(String label) {
    if (label != null) {
      addLine("label \"" + label + "\"");
    }
  }

  /**
   * @see algoanim.primitives.generators.Language
   *      #addError(java.lang.StringBuilder)
   */
  public void addError(StringBuilder error) {
    error.append("\r\n");
    errorBuffer.append(error);
  }

  /**
   * Returns the current error buffer.
   * 
   * @return the current error buffer.
   */
  public String getErrorOutput() {
    return errorBuffer.toString();
  }

  /**
   * Adds the given <code>Primitive</code> to the internal database, which is
   * used to control that dupes are produced.
   * 
   * @param p
   *          the <code>Primitive</code> to add.
   */
  public void addItem(Primitive p) {
    names.add(p.getName());
  }

  /**
   * Writes all AnimalScript commands to the file given to that function. If in
   * stepmode, Stepmode is diasabled and added to output.
   * 
   * @param fileName
   *          the name of the file to write to.
   */
  public void writeFile(String fileName) {
    finalizeGeneration();
    try {
      FileWriter fw = new FileWriter(fileName);
      fw.write(toString());
      // Now have to write interactive elements!
//      if (interactiveElements.size() > 0) {
//        fw.write("\nSTARTQUESTIONS\n");
//        Set<String> interactionKeys = interactiveElements.keySet();
//        Iterator<String> interactionIterator = interactionKeys.iterator();
//        while (interactionIterator.hasNext()) {
//          String key = interactionIterator.next();
//          InteractiveElement element = interactiveElements.get(key);
//          if (element instanceof InteractiveQuestion)
//            fw.write(element.toString());
//        }
//      }
      fw.close();
    } catch (Exception ex) {
      System.err.println("Error while writing file:");
      System.err.println("Filename: " + fileName);
      System.err.println(ex.getMessage());
    }

  }

  /**
   * Returns a String with the generated AnimalScript.
   */
  public String toString() {
    setStepMode(false);
    return output.toString();
  }

  /**
   * Enables or disables Step mode. All lines added after that statement is
   * cached in a buffer and flushed when the step mode is disabled. All lines in
   * one step are executed concurrently.
   * 
   * @param mode
   *          whether to enable step mode or not.
   */
  public void setStepMode(boolean mode) {
    if (!stepBuffer.toString().equalsIgnoreCase("")) {
      nextStep();
    }
    stepMode = mode;
  }

  /**
   * Flushes the stepbuffer to the output variable.
   */
  public void nextStep(int delay, String label) {
    output.append("{\n").append(stepBuffer.toString()).append("}\n");
    if (label != null)
      output.append("label \"").append(label).append("\"\n");
    if (delay >= 0) // we don't do negative delays!
      output.append("delay ").append(delay).append(" ms\n");
    stepBuffer = new StringBuilder(AnimalScript.INITIAL_STEPBUFFER_SIZE);
  }

  /**
   * Clears all animation data.
   */
  public void resetAnimation() {
//	nothing to be done here
  }

  /**
   * @see algoanim.primitives.generators.Language
   *      #isNameUsed(java.lang.String)
   */
  public boolean isNameUsed(String name) {
    return names.contains(name);
  }

  /**
   * @see algoanim.primitives.generators.Language#validDirections()
   */
  public Vector<String> validDirections() {
    return directions;
  }

  /**
   * @see algoanim.primitives.generators.Language
   *      #isValidDirection(java.lang.String)
   */
  public boolean isValidDirection(String direction) {
    return direction == null || directions.contains(direction)
        || direction == null;
  }

  /**
   * @see algoanim.primitives.generators.Language #newArc(
   *      algoanim.util.Node, algoanim.util.Node,
   *      java.lang.String, algoanim.util.DisplayOptions,
   *      algoanim.properties.ArcProperties)
   */
  public Arc newArc(Node center, Node radius, String name,
      DisplayOptions display, ArcProperties ep) {
    return new Arc(arcGen, center, radius, name, display, ep);
  }

  /**
   * @see algoanim.primitives.generators.Language #newCircle(
   *      algoanim.util.Node, int, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.CircleProperties)
   */
  public Circle newCircle(Node center, int radius, String name,
      DisplayOptions display, CircleProperties cp) {
    return new Circle(circleGen, center, radius, name, display, cp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newCircleSeg(
   *      algoanim.util.Node, int, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.CircleSegProperties)
   */
  public CircleSeg newCircleSeg(Node center, int radius, String name,
      DisplayOptions display, CircleSegProperties cp) {
    return new CircleSeg(circleSegGen, center, radius, name, display, cp);
  }

  /**
   * @see algoanim.primitives.generators.Language
   *      #newEllipse(algoanim.util.Node, algoanim.util.Node,
   *      java.lang.String, algoanim.util.DisplayOptions,
   *      algoanim.properties.EllipseProperties)
   */
  public Ellipse newEllipse(Node center, Node radius, String name,
      DisplayOptions display, EllipseProperties ep) {
    return new Ellipse(ellipseGen, center, radius, name, display, ep);
  }


  @Override
  public EllipseSeg newEllipseSeg(Node center, Node radius, String name,
      DisplayOptions display, EllipseSegProperties cp) {
    return new EllipseSeg(ellipseSegGen, center, radius, name, display, cp);
  }

  /**
   * @see algoanim.primitives.generators.Language#newIntArray(
   *      algoanim.util.Node, int[], java.lang.String,
   *      algoanim.util.ArrayDisplayOptions)
   */
  public IntArray newIntArray(Node upperLeft, int[] data, String name,
      ArrayDisplayOptions display, ArrayProperties iap) {
    return new IntArray(intArrayGen, upperLeft, data, name, display, iap);
  }
  
  /**
   * @see algoanim.primitives.generators.Language#newIntMatrix(
   *      algoanim.util.Node, int[][], java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.MatrixProperties)
   */
  public IntMatrix newIntMatrix(Node upperLeft, int[][] data, String name,
      DisplayOptions display, MatrixProperties iap) {
    return new IntMatrix(intMatrixGen, upperLeft, data, name, display, iap);
  }


  /**
   * @see algoanim.primitives.generators.Language #newListElement(
   *      algoanim.util.Node, int, java.util.LinkedList,
   *      algoanim.primitives.ListElement, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.ListElementProperties)
   */
  public ListElement newListElement(Node upperLeft, int pointers,
      LinkedList<Object> pointerLocations, ListElement prev, ListElement next, String name,
      DisplayOptions display, ListElementProperties lp) {
    return new ListElement(listElemGen, upperLeft, pointers,
    		pointerLocations, prev, next, name, display, lp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newPoint(
   *      algoanim.util.Node, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.PointProperties)
   */
  public Point newPoint(Node coords, String name, DisplayOptions display,
      PointProperties pp) {
    return new Point(pointGen, coords, name, display, pp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newPolygon(
   *      algoanim.util.Node[], java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.PolygonProperties)
   */
  public Polygon newPolygon(Node[] vertices, String name,
      DisplayOptions display, PolygonProperties pp)
      throws NotEnoughNodesException {
    return new Polygon(polygonGen, vertices, name, display, pp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newRect(
   *      algoanim.util.Node, algoanim.util.Node,
   *      java.lang.String, algoanim.util.DisplayOptions,
   *      algoanim.properties.RectProperties)
   */
  public Rect newRect(Node upperLeft, Node lowerRight, String name,
      DisplayOptions display, RectProperties rp) {
    return new Rect(rectGen, upperLeft, lowerRight, name, display, rp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newSourceCode(
   *      algoanim.util.Node, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.SourceCodeProperties)
   */
  public SourceCode newSourceCode(Node upperLeft, String name,
      DisplayOptions display, SourceCodeProperties sp) {
    return new SourceCode(sourceGen, upperLeft, name, display, sp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newSquare(
   *      algoanim.util.Node, int, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.SquareProperties)
   */
  public Square newSquare(Node upperLeft, int width, String name,
      DisplayOptions display, SquareProperties sp) {
    return new Square(squareGen, upperLeft, width, name, display, sp);
  }

  /**
   * @see algoanim.primitives.generators.Language#newStringArray(
   *      algoanim.util.Node, java.lang.String[], java.lang.String,
   *      algoanim.util.ArrayDisplayOptions)
   */
  public StringArray newStringArray(Node upperLeft, String[] data, String name,
      ArrayDisplayOptions display, ArrayProperties sap) {
    return new StringArray(stringArrayGen, upperLeft, data, name, display,
        sap);
  }

  
  /**
   * @see algoanim.primitives.generators.Language#newStringMatrix(
   *      algoanim.util.Node, String[][], java.lang.String,
   *      algoanim.util.DisplayOptions)
   */
  public StringMatrix newStringMatrix(Node upperLeft, String[][] data, String name,
      DisplayOptions display, MatrixProperties iap) {
    return new StringMatrix(stringMatrixGen, upperLeft, data, name, 
    		display, iap);
  }

  /**
   * @see algoanim.primitives.generators.Language #newText(
   *      algoanim.util.Node, java.lang.String, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.TextProperties)
   */
  public Text newText(Node upperLeft, String text, String name,
      DisplayOptions display, TextProperties tp) {
    return new Text(textGen, upperLeft, text, name, display, tp);
  }

  /**
   * @see algoanim.primitives.generators.Language #newTriangle(
   *      algoanim.util.Node, algoanim.util.Node,
   *      algoanim.util.Node, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.TriangleProperties)
   */
  public Triangle newTriangle(Node x, Node y, Node z, String name,
      DisplayOptions display, TriangleProperties tp) {
    return new Triangle(triangleGen, x, y, z, name, display, tp);
  }
  
  /**
   * @see algoanim.primitives.generators.Language #newVariables()
   */
  public Variables newVariables() {
	  return new Variables(varGen, null);
  }

  /**
   * @see algoanim.primitives.generators.Language #newArrayMarker(
   *      algoanim.primitives.ArrayPrimitive, int, java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.ArrayMarkerProperties)
   */
  public ArrayMarker newArrayMarker(ArrayPrimitive a, int index, String name,
      DisplayOptions display, ArrayMarkerProperties ap) {
    return new ArrayMarker(amGen, a, index, name, display, ap);
  }

  /**
   * @see algoanim.primitives.generators.Language
   *      #newGroup(java.util.LinkedList, java.lang.String)
   */
  public Group newGroup(LinkedList<Primitive> primitives, String name) {
    return new Group(groupGen, primitives, name);
  }

  /**
   * @see algoanim.primitives.generators.Language #newPolyline(
   *      algoanim.util.Node[], java.lang.String,
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.PolylineProperties)
   */
  public Polyline newPolyline(Node[] vertices, String name,
      DisplayOptions display, PolylineProperties pp) {
    return new Polyline(polyGen, vertices, name, display, pp);
  }
 
  /**
   * @see algoanim.primitives.generators.Language #newGraph(
   *      java.lang.String, int[][], algoanim.util.Node[],
   *      java.lang.String[],
   *      algoanim.util.DisplayOptions,
   *      algoanim.properties.GraphProperties)
   */
	public Graph newGraph(String name, int[][] graphAdjacencyMatrix, 
			Node[] graphNodes, String[] labels, DisplayOptions display, 
			GraphProperties graphProps) {
    return new Graph(graphGen, name, graphAdjacencyMatrix,
    		graphNodes, labels, display, graphProps);
	}
	
	/** 
	 * @see algoanim.primitives.generators.Language#newConceptualStack(
	 * 		algoanim.util.Node, java.util.List, java.lang.String, 
	 * 		algoanim.util.DisplayOptions, algoanim.properties.StackProperties)
	 */
	public <T> ConceptualStack<T> newConceptualStack(Node upperLeft, List<T> content,
			String name, DisplayOptions display, StackProperties sp) {
		ConceptualStackGenerator<T> csGen = new AnimalConceptualStackGenerator<T>(this);
		return new ConceptualStack<T>(csGen, upperLeft, content, name, display, sp);
	}
	
	/** 
	 * @see algoanim.primitives.generators.Language#newArrayBasedStack(
	 * 		algoanim.util.Node, java.util.List, java.lang.String, 
	 * 		algoanim.util.DisplayOptions, algoanim.properties.StackProperties,
	 * 		int)
	 */
	public <T> ArrayBasedStack<T> newArrayBasedStack(Node upperLeft, List<T> content,
			String name, DisplayOptions display, StackProperties sp, int capacity) {
		ArrayBasedStackGenerator<T> absGen = new AnimalArrayBasedStackGenerator<T>(this);
		return new ArrayBasedStack<T>(absGen, upperLeft, content, name, display, sp, capacity);
	}
	
	/** 
	 * @see algoanim.primitives.generators.Language#newListBasedStack(
	 * 		algoanim.util.Node, java.util.List, java.lang.String, 
	 * 		algoanim.util.DisplayOptions, algoanim.properties.StackProperties)
	 */
	public <T> ListBasedStack<T> newListBasedStack(Node upperLeft, List<T> content,
			String name, DisplayOptions display, StackProperties sp) {
		ListBasedStackGenerator<T> lbsGen = new AnimalListBasedStackGenerator<T>(this);
		return new ListBasedStack<T>(lbsGen, upperLeft, content, name, display, sp);
	}

	/**
	 * @see algoanim.primitives.generators.Language#newConceptualQueue(
	 * 		algoanim.util.Node, java.util.List, java.lang.String, 
	 * 		algoanim.util.DisplayOptions, algoanim.properties.QueueProperties)
	 */
	public <T> ConceptualQueue<T> newConceptualQueue(Node upperLeft, List<T> content, 
			String name, DisplayOptions display, QueueProperties qp) {
		ConceptualQueueGenerator<T> cqGen = new AnimalConceptualQueueGenerator<T>(this);
		return new ConceptualQueue<T>(cqGen, upperLeft, content, name, display, qp);
	}
	
	/** 
	 * @see algoanim.primitives.generators.Language#newArrayBasedQueue(
	 * 		algoanim.util.Node, java.util.List, java.lang.String,
	 * 		algoanim.util.DisplayOptions, algoanim.properties.QueueProperties, 
	 * 		int)
	 */
	public <T> ArrayBasedQueue<T> newArrayBasedQueue(Node upperLeft, List<T> content,
			String name, DisplayOptions display, QueueProperties qp, int capacity) {
		ArrayBasedQueueGenerator<T> abqGen = new AnimalArrayBasedQueueGenerator<T>(this);
		return new ArrayBasedQueue<T>(abqGen, upperLeft, content, name, display, qp, capacity);
	}

	/**
	 * @see algoanim.primitives.generators.Language#newListBasedQueue(
	 * 		algoanim.util.Node, java.util.List, java.lang.String, 
	 * 		algoanim.util.DisplayOptions, algoanim.properties.QueueProperties)
	 */
	public <T> ListBasedQueue<T> newListBasedQueue(Node upperLeft, List<T> content, 
			String name, DisplayOptions display, QueueProperties qp) {
		ListBasedQueueGenerator<T> lbqGen = new AnimalListBasedQueueGenerator<T>(this);
		return new ListBasedQueue<T>(lbqGen, upperLeft, content, name, display, qp);
	}

  public void addDocumentationLink(DocumentationLink docuLink) {
    internalQuestionSupportGen.createDocumentationLink(docuLink);
    interactiveElements.put(docuLink.getID(), docuLink);
  }
  
  public void addTFQuestion(TrueFalseQuestion tfQuestion) {
    internalQuestionSupportGen.createTFQuestion(tfQuestion);
    interactiveElements.put(tfQuestion.getID(), tfQuestion);
  }
  
  public void addFIBQuestion(FillInBlanksQuestion fibQuestion) {
	internalQuestionSupportGen.createFIBQuestion(fibQuestion);
	interactiveElements.put(fibQuestion.getID(), fibQuestion);
  }
  
  public void addMCQuestion(MultipleChoiceQuestion mcQuestion) {
    internalQuestionSupportGen.createMCQuestion(mcQuestion);
    interactiveElements.put(mcQuestion.getID(), mcQuestion);
  }

  public void addMSQuestion(MultipleSelectionQuestion msQuestion) {
    internalQuestionSupportGen.createMSQuestion(msQuestion);
    interactiveElements.put(msQuestion.getID(), msQuestion);
  }

  public void addQuestionGroup(GroupInfo group) {
	interactiveElements.put(group.getID(), group);
  }

  
  public void finalizeGeneration() {
    setStepMode(false);
    if (!interactiveElements.isEmpty()) {
      Set<String> interactionKeys = interactiveElements.keySet();
      Iterator<String> interactionIterator = interactionKeys.iterator();
      while (interactionIterator.hasNext()) {
        String key = interactionIterator.next();
        InteractiveElement element = interactiveElements.get(key);
        internalQuestionSupportGen.createInteractiveElementCode(element);
      }
      // dump data
      internalQuestionSupportGen.finalizeInteractiveElements();
    }
  }

  public String getAnimationCode() {
    return output.toString();
  }
  private String generateInteractionKey() {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
    StringBuffer sb = new StringBuffer(80);
    sb.append("intDef");
    sb = sdf.format(new Date(), sb, new FieldPosition(DateFormat.YEAR_FIELD));
    sb.append(".txt");
//    Calendar cal = GregorianCalendar.getInstance();
//    DateFormat df = DateFormat.getDateTimeInstance(dateStyle, timeStyle, aLocale)
//    StringBuilder sb = new StringBuilder(30);
//    sb.append("intDef");
//    formatTwoCharKey(sb, cal.get(Calendar.YEAR));
//    formatTwoCharKey(sb, cal.get(Calendar.MONTH));
//    formatTwoCharKey(sb, cal.get(Calendar.DAY_OF_MONTH));
//    formatTwoCharKey(sb, cal.get(Calendar.HOUR_OF_DAY));
//    formatTwoCharKey(sb, cal.get(Calendar.MINUTE));
//    formatTwoCharKey(sb, cal.get(Calendar.SECOND));
//    formatTwoCharKey(sb, cal.get(Calendar.MILLISECOND));
//    sb.append(".txt");
    return sb.toString();
  }
  
//  private void formatTwoCharKey(StringBuilder sb, int value) {
//    if (value < 10)
//      sb.append("0");
//    sb.append(value);
//  }

  public void setInteractionType(int interactionTypeCode) {
    setInteractionType(interactionTypeCode, generateInteractionKey()); //, "intDefFile.txt");
  }
  
  public void setInteractionType(int interactionTypeCode, String key) {
    if (!interactiveElements.isEmpty())
      throw new IllegalStateException("You cannot change the interaction type if elements have been generated before!");
    if (interactionTypeCode == Language.INTERACTION_TYPE_AVINTERACTION)
      internalQuestionSupportGen = new AVInteractionTextGenerator(this,
          key);
    else
      internalQuestionSupportGen = 
        new AnimalJHAVETextInteractionGenerator(this); 
  }

  @Override
  public DoubleArray newDoubleArray(Node upperLeft, double[] data, String name,
      ArrayDisplayOptions display, ArrayProperties iap) {
    return new DoubleArray(doubleArrayGen, upperLeft, data, name, display, iap);
  }
}