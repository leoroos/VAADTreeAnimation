/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.animalscript;

import java.util.Set;

import algoanim.interactionsupport.DocumentationLink;
import algoanim.interactionsupport.FillInBlanksQuestion;
import algoanim.interactionsupport.InteractiveElement;
import algoanim.interactionsupport.MultipleChoiceQuestion;
import algoanim.interactionsupport.MultipleSelectionQuestion;
import algoanim.interactionsupport.TrueFalseQuestion;
import algoanim.interactionsupport.generators.InteractiveElementGenerator;

public class AnimalJHAVETextInteractionGenerator 
extends AnimalGenerator implements InteractiveElementGenerator {
  
  private boolean startQuestionsPlaced = false;
  
  public AnimalJHAVETextInteractionGenerator(AnimalScript as) {
    super(as);
  }
//
//  public void create(InteractiveElement element) {
//    if (element instanceof TrueFalseQuestion)
//  }
  
  public void createTFQuestion(TrueFalseQuestion q) {
    StringBuilder sb = new StringBuilder(127);
    sb.append("TFQUESTION \"").append(q.getID()).append("\"");
    lang.addLine(sb.toString());    
  }
  
  public void createFIBQuestion(FillInBlanksQuestion q) {
	    StringBuilder sb = new StringBuilder(127);
	    sb.append("FIBQUESTION \"").append(q.getID()).append("\"");
	    lang.addLine(sb.toString());    
  }
  
  public void createInteractiveElementCode(InteractiveElement element) {
    if (!startQuestionsPlaced) {
      lang.addLine("STARTQUESTIONS");
      startQuestionsPlaced = true;
    }
    if (element instanceof TrueFalseQuestion)
      createTFQuestionCode((TrueFalseQuestion) element);
    else if (element instanceof MultipleChoiceQuestion)
      createMCQuestionCode((MultipleChoiceQuestion) element);
    else if (element instanceof MultipleSelectionQuestion)
      createMSQuestionCode((MultipleSelectionQuestion) element);
    else if (element instanceof FillInBlanksQuestion)
        createFIBQuestionCode((FillInBlanksQuestion) element);
    // no need to do something for DocuLink!
  }
  
  public void createTFQuestionCode(TrueFalseQuestion tfQuestion) {
    StringBuilder sb = new StringBuilder(255);
    sb.append("TFQUESTION \"").append(tfQuestion.getID());
    sb.append("\"\n\"").append(tfQuestion.getPrompt());
    sb.append("\"\nENDTEXT\nANSWER\n");
    sb.append((tfQuestion.getAnswerStatus()) ? "T" : "F");
    sb.append("\nENDANSWER");
    lang.addLine(sb);
  }
  
  public void createFIBQuestionCode(FillInBlanksQuestion tfQuestion) {
    StringBuilder sb = new StringBuilder(255);
    sb.append("FIBQUESTION \"").append(tfQuestion.getID());
    sb.append("\"\n\"").append(tfQuestion.getPrompt());
    sb.append("\"\nENDTEXT\nANSWER\n");
    sb.append(tfQuestion.getAnswer());
    sb.append("\nENDANSWER");
    lang.addLine(sb);
  }
  
  public void createMCQuestionCode(MultipleChoiceQuestion mcQuestion) {
    StringBuilder sb = new StringBuilder(255);
    sb.append("MCQUESTION \"").append(mcQuestion.getID());
    sb.append("\"\n\"").append(mcQuestion.getPrompt());
    sb.append("\"\nENDTEXT\n");
    Set<String> answerKeys = mcQuestion.getAnswerSet();
    for (String key : answerKeys) {
      String prompt = mcQuestion.getAnswerString(key);
      if (prompt != null)
        sb.append("\"").append(prompt).append("\"\nENDCHOICE\n");
    }
    sb.append("ANSWER\n").append(mcQuestion.getCorrectAnswerID());
    sb.append("\nENDANSWER");
    lang.addLine(sb);
  }
  
  public void createMSQuestionCode(MultipleSelectionQuestion msQuestion) {
    StringBuilder sb = new StringBuilder(255);
    sb.append("MSQUESTION \"").append(msQuestion.getID());
    sb.append("\"\n\"").append(msQuestion.getPrompt());
    sb.append("\"\nENDTEXT\n");
    Set<String> answerKeys = msQuestion.getAnswerSet();
    for (String key : answerKeys) {
      String prompt = msQuestion.getAnswerString(key);
      if (prompt != null) {
        sb.append("\"").append(prompt).append("\"\nENDCHOICE\n");
        sb.append("ANSWER\n").append(
            msQuestion.getCorrectnessStatus(key)).append("\n");
      }
    }
    sb.append("ENDANSWER");
    lang.addLine(sb);
  }

  public void createDocumentationLink(DocumentationLink docuLink) {
    StringBuilder sb = new StringBuilder(127);
    sb.append("DOCUMENTATION \"").append(docuLink.getID()).append("\"");
    lang.addLine(sb.toString());    
  }

  public void createMCQuestion(MultipleChoiceQuestion mcQuestion) {
    StringBuilder sb = new StringBuilder(127);
    sb.append("MCQUESTION \"").append(mcQuestion.getID()).append("\"");
    lang.addLine(sb.toString());    
  }

  public void createMSQuestion(MultipleSelectionQuestion msQuestion) {
    StringBuilder sb = new StringBuilder(127);
    sb.append("MSQUESTION \"").append(msQuestion.getID()).append("\"");
    lang.addLine(sb.toString());    
  }

  public void finalizeInteractiveElements() {
    // nothing to be done here :-)
  }
}