/*
 * Created on 16.11.2007 by Guido Roessling <roessling@acm.org>
 */
package algoanim.animalscript;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.util.Calendar;

import algoanim.interactionsupport.DocumentationLink;
import algoanim.interactionsupport.FillInBlanksQuestion;
import algoanim.interactionsupport.GroupInfo;
import algoanim.interactionsupport.InteractiveElement;
import algoanim.interactionsupport.InteractiveQuestion;
import algoanim.interactionsupport.MultipleChoiceQuestion;
import algoanim.interactionsupport.MultipleSelectionQuestion;
import algoanim.interactionsupport.TrueFalseQuestion;
import algoanim.interactionsupport.generators.InteractiveElementGenerator;

public class AVInteractionTextGenerator 
extends AnimalGenerator implements InteractiveElementGenerator {
  private StringBuilder idc = new StringBuilder(24096);
  private String fileName; // = "intDefFile.txt";
  
  public AVInteractionTextGenerator(AnimalScript as) {
    this(as, null);
  }
  
//  public AVInteractionTextGenerator(AnimalScript as, String filename) {
//    this(as, filename);
//  }
  
  public AVInteractionTextGenerator(AnimalScript as, String key) {
    super(as);
    if (key == null) {
      Calendar cal = Calendar.getInstance();
      StringBuilder sb = new StringBuilder(30);
      sb.append("intDef");
      formatTwoCharKey(sb, cal.get(Calendar.YEAR));
      formatTwoCharKey(sb, cal.get(Calendar.MONTH));
      formatTwoCharKey(sb, cal.get(Calendar.DAY_OF_MONTH));
      formatTwoCharKey(sb, cal.get(Calendar.HOUR_OF_DAY));
      formatTwoCharKey(sb, cal.get(Calendar.MINUTE));
      formatTwoCharKey(sb, cal.get(Calendar.SECOND));
      formatTwoCharKey(sb, cal.get(Calendar.MILLISECOND));
      sb.append(".txt");
      fileName = sb.toString();
    } else
      fileName = key;
    as.addLine("interactionDefinition \"" + fileName +"\"");
  }
  
  private void formatTwoCharKey(StringBuilder sb, int value) {
    if (value < 10)
      sb.append("0");
    sb.append(value);
  }
  
  public void createInteractiveElementCode(InteractiveElement element) {
    if (element instanceof TrueFalseQuestion)
      createTFQuestionCode((TrueFalseQuestion) element);
    else if (element instanceof MultipleChoiceQuestion)
      createMCQuestionCode((MultipleChoiceQuestion) element);
    else if (element instanceof MultipleSelectionQuestion)
      createMSQuestionCode((MultipleSelectionQuestion) element);
    else if (element instanceof DocumentationLink)
      createDocumentationLinkCode((DocumentationLink) element);
    else if (element instanceof FillInBlanksQuestion)
    	createFIBQuestionCode((FillInBlanksQuestion) element);
    else if (element instanceof GroupInfo)
    	createGroupInfoCode((GroupInfo) element);
  }
  

public void createDocumentationLink(DocumentationLink docuLink) {
    StringBuilder sb = new StringBuilder(127);
//    sb.append("documentation \"").append(docuLink.getID()).append("\"");
    sb.append("interaction \"").append(docuLink.getID()).append("\"");
    lang.addLine(sb.toString());    
  }

  public void createDocumentationLinkCode(DocumentationLink docuLink) {
    idc.append("documentation \"").append(docuLink.getID());
    idc.append("\"\n\"").append(docuLink.getTargetURI().toString());
    idc.append("\"\nendtext");
    
 // add a line feed for better readability
    idc.append("\n\n");
  }
  
  public void createGroupInfoCode(GroupInfo group) {
    idc.append("groupInfo \"").append(group.getID());
    idc.append("\"\n  ").append("nrRepeats ").append(group.getNrRepeats());
    idc.append("\nendtext");
    
 // add a line feed for better readability
    idc.append("\n\n");
  }

  public void createTFQuestion(TrueFalseQuestion q) {
    StringBuilder sb = new StringBuilder(127);
//    sb.append("tfQuestion \"").append(q.getID()).append("\"");
    sb.append("interaction \"").append(q.getID()).append("\"");
    lang.addLine(sb.toString());    
  }
  
  private void createStandardCode(String tag, 
      InteractiveQuestion question) {
    idc.append(tag).append(" \"").append(question.getID()).append("\"");    
    // add # of possible points, if defined
    if (question.getPointsPossible() > 0)
      idc.append("\n  points ").append(question.getPointsPossible());
    
    // add question group, if any
    if (question.getQuestionGroup() != null) {
      idc.append("\n  questionGroup \"");
      idc.append(question.getQuestionGroup()).append("\"");
    }
     
    // add question prompt
    idc.append("\n\"").append(question.getPrompt());
    idc.append("\"\nendtext");
  }
  
  public void createTFQuestionCode(TrueFalseQuestion tfQuestion) {
    createStandardCode("tfQuestion", tfQuestion);
    
    // add the answer
    idc.append("\n  answer\n");
    idc.append((tfQuestion.getAnswerStatus()) ? "t" : "f");
    idc.append("\nendAnswer");
    
    // check for a comment for the incorrect (!) answer
    String comment = 
      tfQuestion.getFeedbackForOption(!tfQuestion.getAnswerStatus());
    if (comment != null) {
      idc.append("\n  comment\n\"").append(comment);
      idc.append("\"\n  endComment");
    }
    
    // add a line feed for better readability
    idc.append("\n\n");
  }

  public void createFIBQuestion(FillInBlanksQuestion q) {
    StringBuilder sb = new StringBuilder(127);
//    sb.append("tfQuestion \"").append(q.getID()).append("\"");
    sb.append("interaction \"").append(q.getID()).append("\"");
    lang.addLine(sb.toString());    
  }
  
  public void createFIBQuestionCode(FillInBlanksQuestion fibQuestion) {
	createStandardCode("fibQuestion", fibQuestion);
	
	// add the answer
	idc.append("\n  answer\n\"");
	idc.append(fibQuestion.getAnswer());
	idc.append("\"\nendAnswer");
	
	idc.append("\n  comment\n\"");
	idc.append(fibQuestion.getFeedback());
	idc.append("\"\n  endComment");

	// add a line feed for better readability
	idc.append("\n\n"); 
  }
  
  public void createMCQuestion(MultipleChoiceQuestion mcQuestion) {
    StringBuilder sb = new StringBuilder(127);
//    sb.append("mcQuestion \"").append(mcQuestion.getID()).append("\"");
    sb.append("interaction \"").append(mcQuestion.getID()).append("\"");
    lang.addLine(sb.toString());    
  }

  public void createMCQuestionCode(MultipleChoiceQuestion mcQuestion) {
    String comment = null, prompt = null;
    createStandardCode("mcQuestion", mcQuestion); 
    Object[] answerKeys = mcQuestion.getAnswerArray();  
    
    for (int i = 1; i <= answerKeys.length; i++) {
      prompt = mcQuestion.getAnswerString("" + i);
      if (prompt != null)
        idc.append("\n\"").append(prompt).append("\"\nendChoice");

      // adds points for this answer, if appropriate
      int points = mcQuestion.getPointsForOption("" + i);
      if (points != 0) {
        idc.append("\n  points ").append(points);
      }
      
      // add the comment for this answer, if appropriate
      comment = mcQuestion.getFeedbackForOption("" + i);
      if (comment != null) {
        idc.append("\n  comment\n\"").append(comment).append("\"");
        idc.append("\n  endComment");
      }
    }
    
    // add the answer
    idc.append("\n  answer\n").append(mcQuestion.getCorrectAnswerID());
    idc.append("\nendAnswer\n\n");
  }

  public void createMSQuestion(MultipleSelectionQuestion msQuestion) {
    StringBuilder sb = new StringBuilder(127);
//    sb.append("mcQuestion \"").append(msQuestion.getID()).append("\"");
    sb.append("interaction \"").append(msQuestion.getID()).append("\"");
    lang.addLine(sb.toString());    
  }
  
  public void createMSQuestionCode(MultipleSelectionQuestion msQuestion) {
    String comment = null, prompt = null;
    createStandardCode("mcQuestion", msQuestion); 
    StringBuilder fakeID = new StringBuilder(32); //singleFakeCorrectID = null;
    Object[] answerKeys = msQuestion.getAnswerArray();  
    
    for (int i = 1; i <= answerKeys.length; i++) {
      prompt = msQuestion.getAnswerString("" + i);
      if (prompt != null)
        idc.append("\n\"").append(prompt).append("\"\nendChoice");

      // adds points for this answer, if appropriate
      int points = msQuestion.getPointsForOption("" + i);
      if (points != 0) {
        idc.append("\n  points ").append(points);
      }
      
      // add the comment for this answer, if appropriate
      comment = msQuestion.getFeedbackForOption("" + i);
      if (comment != null) {
        idc.append("\n  comment\n\"").append(comment).append("\"");
        idc.append("\n  endComment");
      }
      if (msQuestion.getCorrectnessStatus("" + i).booleanValue() || points > 0)
        fakeID.append("\n").append("" + i);
//        singleFakeCorrectID = key;
    }
    
    // add the answer
    idc.append("\n  answer").append(fakeID.toString());//singleFakeCorrectID);
    idc.append("\nendAnswer\n\n");
  }

  /**
   * finalize the writing of the interaction components
   */
  public void finalizeInteractiveElements() {
    try {
      Writer fw = new BufferedWriter(new FileWriter(fileName));
      fw.write(idc.toString());
      fw.close();
      System.err.println("Wrote file "+fileName +".");
    } catch (Exception ex) {
      System.err.println("Error while writing file:");
      System.err.println("Filename: " + fileName);
      System.err.println(ex.getMessage());
    }
  } 
}