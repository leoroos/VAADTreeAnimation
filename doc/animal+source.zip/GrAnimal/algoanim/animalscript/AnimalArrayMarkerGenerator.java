package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.ArrayMarker;
import algoanim.primitives.generators.ArrayMarkerGenerator;
import algoanim.primitives.generators.Language;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.ArrayMarkerProperties;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.ArrayMarkerGenerator
 * @author Stephan Mehlhase
 */
public class AnimalArrayMarkerGenerator extends AnimalGenerator implements
		ArrayMarkerGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalArrayMarkerGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.ArrayMarkerGenerator
	 *      #create(algoanim.primitives.ArrayMarker)
	 */
	public void create(ArrayMarker am) {
		if (this.isNameUsed(am.getName()) || am.getName() == "") {
			am.setName("ArrayMarker" + AnimalArrayMarkerGenerator.count);
			AnimalArrayMarkerGenerator.count++;
		}
		lang.addItem(am);

		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("arrayMarker \"").append(am.getName()).append("\" on \"");
		def.append(am.getArray().getName()).append("\" atIndex ");
		def.append(am.getPosition());

		ArrayMarkerProperties props = am.getProperties();
		Object current = props.get(AnimationPropertiesKeys.LABEL_PROPERTY);
		if (current != null && !((String)current).equals("")) {
			def.append(" label \"").append(
					(String) props.get(AnimationPropertiesKeys.LABEL_PROPERTY)).append(
					"\"");
		}
		current = props.get(AnimationPropertiesKeys.LONG_MARKER_PROPERTY);
		if (current != null && ((Boolean)current).booleanValue())
//			 ((Boolean)props.get(AnimationPropertiesKeys.LONG_MARKER_PROPERTY)) == Boolean.TRUE)
			def.append(" long");
		else {
		  current = props.get(AnimationPropertiesKeys.SHORT_MARKER_PROPERTY);
		  if (current != null && ((Boolean)current).booleanValue())
	      def.append(" short");
		}
		current = props.get(AnimationPropertiesKeys.COLOR_PROPERTY);
		if (current != null) {
			def.append(" color ");
			Color c = (Color)current;
			def.append(AnimalGenerator.makeColorDef(c.getRed(),
					c.getGreen(), c.getBlue()));
		}
		current = props.get(AnimationPropertiesKeys.DEPTH_PROPERTY);
		if (current != null) {
			def.append(" depth "
					+ ((Integer)current).toString());
		}

		def.append(AnimalGenerator.makeDisplayOptionsDef(am.getDisplayOptions(), props));

		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.ArrayMarkerGenerator #move(
	 *      algoanim.primitives.ArrayMarker, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void move(ArrayMarker am, int to, Timing delay, Timing duration) {
		StringBuilder sb = new StringBuilder(256);
		sb.append("moveArrayMarker \"").append(am.getName());
		sb.append("\" to position ").append(to).append(" ");
		sb.append(AnimalGenerator.makeOffsetTimingDef(delay)).append(" ");
		sb.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(sb.toString());
	}

	/**
   * @see algoanim.primitives.generators.ArrayMarkerGenerator #moveBeforeStart(
   *      algoanim.primitives.ArrayMarker, algoanim.util.Timing,
   *      algoanim.util.Timing)
   */ 
  public void moveBeforeStart(ArrayMarker am, Timing delay, Timing duration) {
    StringBuilder sb = new StringBuilder(256);
    sb.append("moveArrayMarker \"").append(am.getName());
    sb.append("\" to outside ");
    sb.append(AnimalGenerator.makeOffsetTimingDef(delay)).append(" ");
    sb.append(AnimalGenerator.makeDurationTimingDef(duration));
    lang.addLine(sb.toString());
  }
  
  
	/**
	 * @see algoanim.primitives.generators.ArrayMarkerGenerator #moveToEnd(
	 *      algoanim.primitives.ArrayMarker, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void moveToEnd(ArrayMarker am, Timing delay, Timing duration) {
		StringBuilder sb = new StringBuilder(256);
		sb.append("moveArrayMarker \"").append(am.getName());
		sb.append("\" to arrayEnd ");
		sb.append(AnimalGenerator.makeOffsetTimingDef(delay));
		sb.append(" ").append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(sb.toString());
	}

	/**
	 * @see algoanim.primitives.generators.ArrayMarkerGenerator
	 *      #moveOutside( algoanim.primitives.ArrayMarker,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void moveOutside(ArrayMarker am, Timing delay, Timing duration) {
		StringBuilder sb = new StringBuilder(256);
		sb.append("moveArrayMarker \"").append(am.getName());
		sb.append("\" to outside ");
		sb.append(AnimalGenerator.makeOffsetTimingDef(delay));
		sb.append(" ").append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(sb.toString());
	}
	
	public void decrement(ArrayMarker am, Timing delay, Timing duration) {
		StringBuilder sb = new StringBuilder(256);
		sb.append("moveArrayMarker \"").append(am.getName());
		sb.append("\" to position ").append(am.getPosition() - 1);
		sb.append(" ").append(AnimalGenerator.makeOffsetTimingDef(delay));
		sb.append( " ");
		sb.append(AnimalGenerator.makeDurationTimingDef(duration));	
		lang.addLine(sb.toString());
	}
	
	public void increment(ArrayMarker am, Timing delay, Timing duration) {
		StringBuilder sb = new StringBuilder(256);
		sb.append("moveArrayMarker \"").append(am.getName());
		sb.append("\" to position ").append(am.getPosition() + 1);
		sb.append(" ").append(AnimalGenerator.makeOffsetTimingDef(delay));
		sb.append( " ");
		sb.append(AnimalGenerator.makeDurationTimingDef(duration));	
		lang.addLine(sb.toString());

	}
}
