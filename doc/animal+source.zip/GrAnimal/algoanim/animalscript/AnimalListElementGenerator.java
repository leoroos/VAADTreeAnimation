package algoanim.animalscript;

import java.awt.Color;
import java.util.ListIterator;

import algoanim.primitives.ListElement;
import algoanim.primitives.Primitive;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.ListElementGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.ListElementProperties;
import algoanim.util.Node;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.ListElementGenerator
 * @author Stephan Mehlhase
 */
public class AnimalListElementGenerator extends AnimalGenerator implements
		ListElementGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalListElementGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.ListElementGenerator
	 *      #create(algoanim.primitives.ListElement)
	 */
	public void create(ListElement e) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(e.getName()) || e.getName() == "") {
			e.setName("ListElement" + AnimalListElementGenerator.count);
			AnimalListElementGenerator.count++;
		}
		lang.addItem(e);

		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("listelement \"" + e.getName() + "\"");
		def.append(" " + AnimalGenerator.makeNodeDef(e.getUpperLeft()));

		ListElementProperties props = e.getProperties();

		if (props.get(AnimationPropertiesKeys.TEXT_PROPERTY) != null) {
			def.append(" text \""
					+ props.get(AnimationPropertiesKeys.TEXT_PROPERTY).toString() + "\"");
		}

		def.append(" pointers " + e.getPointers());
		def.append(" position ");
        Integer o2 = (Integer)props.get(AnimationPropertiesKeys.POSITION_PROPERTY);
        switch(o2.intValue()) {
        case 0:
          def.append("none");
          break;
        case 1:
          def.append("right");
          break;
        case 2:
          def.append("left");
          break;
        case 3:
          def.append("top");
          break;
        default:
          def.append("bottom");
        }
        def.append(" ");
        // old:
//		def.append(" position "
//				+ e.getProperties().get(AnimationPropertiesKeys.POSITION_PROPERTY)
//						.toString());

		// writes pointer definitions as long as the loop does not reach
		// the number of the assigned pointers and the list of pointer location
		// definitions is not exhausted.
		if (e.getPointerLocations() != null) {
			int i = 1;
			ListIterator<Object> li = e.getPointerLocations().listIterator();
			int pointers = e.getPointers();

			while (i <= pointers && li.hasNext()) {
				Object o = li.next();

				// either use a Node definition as pointer location
				// or a "to targetID" definition, or skip the location for
				// the current pointer, if the entry in the LinkedList is null.
				if (o instanceof Node) {
					def.append(" ptr").append(i).append(" ").append(AnimalGenerator.makeNodeDef((Node) o));
				} else if (o instanceof Primitive) {
					def.append(" ptr").append(i).append(" to \"").append(((Primitive) o).getName()).append("\" ");
				}
				i++;
			}

		}

		if (e.getPrev() != null) {
			def.append(" prev \"");
			def.append(e.getPrev().getName());
			def.append("\" ");
		}
        
        if (e.getNext() != null) {
            def.append(" next \"");
            def.append(e.getNext().getName());
            def.append("\" ");
        }

		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append("color "
					+ AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
							((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue())
					+ " ");
		}

		if (props.get(AnimationPropertiesKeys.BOXFILLCOLOR_PROPERTY) != null) {
			def.append("boxFillColor "
					+ AnimalGenerator
							.makeColorDef(
									((Color) props
											.get(AnimationPropertiesKeys.BOXFILLCOLOR_PROPERTY))
											.getRed(), ((Color) props
											.get(AnimationPropertiesKeys.BOXFILLCOLOR_PROPERTY))
											.getGreen(), ((Color) props
											.get(AnimationPropertiesKeys.BOXFILLCOLOR_PROPERTY))
											.getBlue()) + " ");
		}

		if (props.get(AnimationPropertiesKeys.POINTERAREACOLOR_PROPERTY) != null) {
			def.append("pointerAreaColor "
					+ AnimalGenerator.makeColorDef(
							((Color) props
									.get(AnimationPropertiesKeys.POINTERAREACOLOR_PROPERTY))
									.getRed(), ((Color) props
									.get(AnimationPropertiesKeys.POINTERAREACOLOR_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.POINTERAREACOLOR_PROPERTY))
									.getBlue()) + " ");
		}

		if (props.get(AnimationPropertiesKeys.POINTERAREAFILLCOLOR_PROPERTY) != null) {
			def.append("pointerAreaFillColor "
					+ AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.POINTERAREAFILLCOLOR_PROPERTY))
							.getRed(), ((Color) props
							.get(AnimationPropertiesKeys.POINTERAREAFILLCOLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.POINTERAREAFILLCOLOR_PROPERTY))
							.getBlue()) + " ");
		}

		if (props.get(AnimationPropertiesKeys.TEXTCOLOR_PROPERTY) != null) {
			def.append("textColor "
					+ AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.TEXTCOLOR_PROPERTY)).getRed(),
							((Color) props.get(AnimationPropertiesKeys.TEXTCOLOR_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.TEXTCOLOR_PROPERTY)).getBlue())
					+ " ");
		}

		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append("depth " + props.get(AnimationPropertiesKeys.DEPTH_PROPERTY)
					+ " ");
        }
        def.append(AnimalGenerator.makeDisplayOptionsDef(e.getDisplayOptions(), props));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.ListElementGenerator #link(
	 *      algoanim.primitives.ListElement,
	 *      algoanim.primitives.ListElement, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void link(ListElement start, ListElement target, int linkno, Timing t,
			Timing d) {
		lang.addLine("setLink \"" + start.getName() + "\" link " + linkno + " to \""
				+ target.getName() + "\" " +AnimalGenerator.makeOffsetTimingDef(t) + " "
				+ AnimalGenerator.makeDurationTimingDef(d));
	}

	/**
	 * @see algoanim.primitives.generators.ListElementGenerator #unlink(
	 *      algoanim.primitives.ListElement, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void unlink(ListElement start, int linkno, Timing t, Timing d) {
		lang.addLine("clearLink \"" + start.getName() + "\" link " + linkno
				+ AnimalGenerator.makeOffsetTimingDef(t) + " "
				+ AnimalGenerator.makeDurationTimingDef(d));

	}

}
