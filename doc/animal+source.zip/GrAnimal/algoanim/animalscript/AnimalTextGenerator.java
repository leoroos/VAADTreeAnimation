package algoanim.animalscript;

import java.awt.Color;
import java.awt.Font;

import algoanim.primitives.Primitive;
import algoanim.primitives.Text;
import algoanim.primitives.generators.Language;
import algoanim.primitives.generators.TextGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.TextProperties;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.TextGenerator
 * @author Stephan Mehlhase
 */
public class AnimalTextGenerator extends AnimalGenerator implements
		TextGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalTextGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 * @see algoanim.primitives.generators.TextGenerator
	 *      #create(algoanim.primitives.Text)
	 */
	public void create(Text t) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(t.getName()) || t.getName() == "") {
			t.setName("Text" + AnimalTextGenerator.count);
			AnimalTextGenerator.count++;
		}
		lang.addItem(t);

		StringBuilder str = new StringBuilder();
		str.append("text \"" + t.getName() + "\" ");
		str.append("\"" + t.getText() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(t.getUpperLeft()));

		TextProperties props = t.getProperties();
		if (props.get(AnimationPropertiesKeys.CENTERED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.CENTERED_PROPERTY))
						.booleanValue()) {
			str.append(" centered");
		}
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null) {
			str.append(" font "
					+ ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY))
							.getFamily());
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null) {
			str
					.append(" size "
							+ ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY))
									.getSize());
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null
				&& ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY)).isBold()) {
			str.append(" bold");
		}
		if (props.get(AnimationPropertiesKeys.FONT_PROPERTY) != null
				&& ((Font) props.get(AnimationPropertiesKeys.FONT_PROPERTY)).isItalic()) {
			str.append(" italic");
		}

		str.append(AnimalGenerator.makeDisplayOptionsDef(t.getDisplayOptions(),
            props));

		lang.addLine(str);
	}

	/**
	 * updates the font of this text component (not supported by all primitives!).
	 * 
	 * @param p the <code>Primitive</code> to change.
	 * @param newFont the new text to be used
	 * @param delay the delay until the operation starts
	 * @param duration the duration for the operation
	 */
	public void setFont(Primitive p, Font newFont, Timing delay, Timing duration) {
		StringBuilder str = new StringBuilder();
		str.append("setFont of \"").append(p.getName()).append("\" to font ");
		str.append(newFont.getFamily()).append(" size ").append(newFont.getSize());
		if (newFont.isBold())
			str.append(" bold");
		if (newFont.isItalic())
			str.append(" italic");
		
		str.append(AnimalGenerator.makeOffsetTimingDef(delay));
		str.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(str);				
	}

	/**
	 * updates the text of this text component (not supported by all primitives!).
	 * 
	 * @param p the <code>Primitive</code> to change.
	 * @param newText the new text to be used
	 * @param delay the delay until the operation starts
	 * @param duration the duration for the operation
	 */

	public void setText(Primitive p, String newText, Timing delay, 
			Timing duration) {
		StringBuilder str = new StringBuilder();
		str.append("setText of \"").append(p.getName()).append("\" to \"");
		str.append(newText).append("\"");
		str.append(AnimalGenerator.makeOffsetTimingDef(delay));
		str.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(str);		
	}
}
