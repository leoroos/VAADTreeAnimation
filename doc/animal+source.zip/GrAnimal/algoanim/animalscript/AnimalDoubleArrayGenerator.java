package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.DoubleArray;
import algoanim.primitives.generators.DoubleArrayGenerator;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.ArrayProperties;
import algoanim.util.ArrayDisplayOptions;
import algoanim.util.Timing;

/**
 * @see algoanim.primitives.generators.DoubleArrayGenerator
 * @author Guido Roessling <roessling@acm.prg>
 */
public class AnimalDoubleArrayGenerator extends AnimalGenerator implements
		DoubleArrayGenerator {
	private static int count = 1;

	/**
	 * @param as
	 *          the associated <code>Language</code> object.
	 */
	public AnimalDoubleArrayGenerator(AnimalScript as) {
		super(as);
	}

	/**
	 * @see algoanim.primitives.generators.IntArrayGenerator
	 *      #create(algoanim.primitives.IntArray)
	 */
	public void create(DoubleArray anArray) {
		if (this.isNameUsed(anArray.getName()) || anArray.getName() == "") {
			anArray.setName("DoubleArray" + AnimalDoubleArrayGenerator.count);
			AnimalDoubleArrayGenerator.count++;
		}
		lang.addItem(anArray);

		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("array \"").append(anArray.getName()).append("\" ");
		def.append(AnimalGenerator.makeNodeDef(anArray.getUpperLeft()));
		def.append(' ');

		/* Properties */
		ArrayProperties ap = anArray.getProperties();

		if (ap.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			def.append("color "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.COLOR_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue())
					+ " ");
		}
		if (ap.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
			def
					.append("fillColor "
							+ AnimalGenerator.makeColorDef(((Color) ap
									.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
									((Color) ap.get(AnimationPropertiesKeys.FILL_PROPERTY))
											.getGreen(), ((Color) ap
											.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue())
							+ " ");
		}
		if (ap.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY) != null) {
			def.append("elementColor "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.ELEMENTCOLOR_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY) != null) {
			def.append("elemHighlight "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.ELEMHIGHLIGHT_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY) != null) {
			def.append("cellHighlight "
					+ AnimalGenerator.makeColorDef(((Color) ap
							.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY)).getRed(),
							((Color) ap.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY))
									.getGreen(), ((Color) ap
									.get(AnimationPropertiesKeys.CELLHIGHLIGHT_PROPERTY))
									.getBlue()) + " ");
		}
		if (ap.get(AnimationPropertiesKeys.DIRECTION_PROPERTY) != null
				&& ((Boolean) ap.get(AnimationPropertiesKeys.DIRECTION_PROPERTY))
						.booleanValue()) {
			def.append("vertical ");
		} else {
			def.append("horizontal ");
		}

		def.append("length ").append(anArray.getLength()).append(' ');

		for (int i = 0; i < anArray.getLength(); i++) {
			def.append("\"" + anArray.getData(i) + "\" ");
		}

		/* Properties */

		if (ap.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			def.append("depth " + ap.get(AnimationPropertiesKeys.DEPTH_PROPERTY)
					+ " ");
		}

		ArrayDisplayOptions ado = (ArrayDisplayOptions) anArray.getDisplayOptions();
		if (ado == null && ((Boolean)ap.get(AnimationPropertiesKeys.CASCADED_PROPERTY)).booleanValue())
          def.append(" cascaded");
        
		if (ado != null) {
			Timing o = ado.getOffset();
			if (o != null) {
				def.append(" " + AnimalGenerator.makeOffsetTimingDef(o));
			}
			if (ado.getCascaded() == true) {
				def.append(" cascaded");
				Timing d = ado.getDuration();
				if (d != null) {
					def.append(AnimalGenerator.makeDurationTimingDef(d));
				}
			}

		}

		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.IntArrayGenerator #swap(
	 *      algoanim.primitives.IntArray, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void swap(DoubleArray iap, int what, int with, Timing delay,
			Timing duration) {
//		if (what != with) {
			String def = "arraySwap on \"" + iap.getName() + "\" position " + what
			+ " with " + with;
			def += " " + AnimalGenerator.makeOffsetTimingDef(delay);
			def += " " + AnimalGenerator.makeDurationTimingDef(duration);
			lang.addLine(def);
//		}
	}

	/**
	 * @see algoanim.primitives.generators.IntArrayGenerator #put(
	 *      algoanim.primitives.IntArray, int, int,
	 *      algoanim.util.Timing, algoanim.util.Timing)
	 */
	public void put(DoubleArray iap, int where, double what, Timing delay,
			Timing duration) {
		String def = "arrayPut \"" + what + "\" on \"" + iap.getName()
				+ "\" position " + where;
		def += " " + AnimalGenerator.makeOffsetTimingDef(delay);
		def += " " + AnimalGenerator.makeDurationTimingDef(duration);
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator#highlightCell(DoubleArray,
	 * int, int, algoanim.util.Timing,algoanim.util.Timing)
	 */
	public void highlightCell(DoubleArray ia, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayCell on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #highlightCell(DoubleArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightCell(DoubleArray ia, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayCell on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #highlightElem(DoubleArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(DoubleArray ia, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayElem on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #highlightElem(DoubleArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void highlightElem(DoubleArray ia, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("highlightArrayElem on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #unhighlightCell(DoubleArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(DoubleArray ia, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayCell on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #unhighlightCell(DoubleArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightCell(DoubleArray ia, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayCell on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #unhighlightElem(DoubleArray, int, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(DoubleArray ia, int from, int to, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayElem on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" from " + from + " to " + to);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}

	/**
	 * @see algoanim.primitives.generators.DoubleArrayGenerator
	 *      #unhighlightElem(DoubleArray, int, algoanim.util.Timing,
	 *      algoanim.util.Timing)
	 */
	public void unhighlightElem(DoubleArray ia, int position, Timing offset,
			Timing duration) {
		StringBuilder def = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		def.append("unhighlightArrayElem on \"");
		def.append(ia.getName());
		def.append("\"");
		def.append(" position " + position);
		def.append(AnimalGenerator.makeOffsetTimingDef(offset));
		def.append(AnimalGenerator.makeDurationTimingDef(duration));
		lang.addLine(def);
	}
}
