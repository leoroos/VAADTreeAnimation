package algoanim.animalscript;

import java.awt.Color;

import algoanim.primitives.CircleSeg;
import algoanim.primitives.generators.CircleSegGenerator;
import algoanim.primitives.generators.Language;
import algoanim.properties.AnimationPropertiesKeys;
import algoanim.properties.CircleSegProperties;

/**
 * @see algoanim.primitives.generators.CircleSegGenerator
 * @author Stephan Mehlhase
 */
public class AnimalCircleSegGenerator extends AnimalGenerator implements
		CircleSegGenerator {
	private static int count = 1;

	/**
	 * @param aLang
	 *          the associated <code>Language</code> object.
	 */
	public AnimalCircleSegGenerator(Language aLang) {
		super(aLang);
	}

	/**
	 *      #create(animalscriptapi.primitives.CircleSeg)
     * @see algoanim.primitives.generators.CircleSegGenerator
	 */
	public void create(CircleSeg aseg) {
		// Check Name, if used already, create a new one silently
		if (this.isNameUsed(aseg.getName()) || aseg.getName() == "") {
			aseg.setName("CircleSeg" + AnimalCircleSegGenerator.count);
			AnimalCircleSegGenerator.count++;
		}
		lang.addItem(aseg);

		StringBuilder str = new StringBuilder(AnimalScript.INITIAL_GENBUFFER_SIZE);
		str.append("circleSeg \"" + aseg.getName() + "\" ");
		str.append(AnimalGenerator.makeNodeDef(aseg.getCenter()));
		str.append(" radius " + aseg.getRadius());

		CircleSegProperties props = aseg.getProperties();
		if (props.get(AnimationPropertiesKeys.ANGLE_PROPERTY) != null) {
			str.append(" angle "
					+ props.get(AnimationPropertiesKeys.ANGLE_PROPERTY).toString());
		}
		if (props.get(AnimationPropertiesKeys.STARTANGLE_PROPERTY) != null) {
			str.append(" startAngle "
					+ props.get(AnimationPropertiesKeys.STARTANGLE_PROPERTY).toString());
		}
		if (props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY))
						.booleanValue()) {
			str.append(" clockwise ");
		} else if (props.get(AnimationPropertiesKeys.CLOCKWISE_PROPERTY) != null
				&& ((Boolean) props
						.get(AnimationPropertiesKeys.COUNTERCLOCKWISE_PROPERTY))
						.booleanValue()) {
			str.append(" counterclockwise ");
		}
		if (props.get(AnimationPropertiesKeys.COLOR_PROPERTY) != null) {
			str.append(" color ");
			str.append(AnimalGenerator.makeColorDef(((Color) props
					.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getRed(),
					((Color) props.get(AnimationPropertiesKeys.COLOR_PROPERTY))
							.getGreen(), ((Color) props
							.get(AnimationPropertiesKeys.COLOR_PROPERTY)).getBlue()));
		}
		if (props.get(AnimationPropertiesKeys.DEPTH_PROPERTY) != null) {
			str.append(" depth "
					+ ((Integer) props.get(AnimationPropertiesKeys.DEPTH_PROPERTY))
							.toString());
		}
		if (props.get(AnimationPropertiesKeys.CLOSED_PROPERTY) != null
				&& ((Boolean) props.get(AnimationPropertiesKeys.CLOSED_PROPERTY))
						.booleanValue()) {
			str.append(" closed ");
			if (props.get(AnimationPropertiesKeys.FILLED_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.FILLED_PROPERTY))
							.booleanValue()) {
				str.append(" filled");
				if (props.get(AnimationPropertiesKeys.FILL_PROPERTY) != null) {
					str.append(" fillColor ");
					str.append(AnimalGenerator.makeColorDef(((Color) props
							.get(AnimationPropertiesKeys.FILL_PROPERTY)).getRed(),
							((Color) props.get(AnimationPropertiesKeys.FILL_PROPERTY))
									.getGreen(), ((Color) props
									.get(AnimationPropertiesKeys.FILL_PROPERTY)).getBlue()));
				}
			}
		} else {
			if (props.get(AnimationPropertiesKeys.FWARROW_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.FWARROW_PROPERTY))
							.booleanValue()) {
				str.append(" fwarrow ");
			}
			if (props.get(AnimationPropertiesKeys.BWARROW_PROPERTY) != null
					&& ((Boolean) props.get(AnimationPropertiesKeys.BWARROW_PROPERTY))
							.booleanValue()) {
				str.append(" bwarrow ");
			}
		}
		str.append(AnimalGenerator.makeDisplayOptionsDef(aseg.getDisplayOptions(), props));
		lang.addLine(str);
	}
}
