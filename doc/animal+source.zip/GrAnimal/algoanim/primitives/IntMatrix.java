/*
 * Created on 24.11.2004 
 */
package algoanim.primitives;

import algoanim.primitives.generators.IntMatrixGenerator;
import algoanim.properties.MatrixProperties;
import algoanim.util.DisplayOptions;
import algoanim.util.Node;
import algoanim.util.Timing;

/**
 * <code>IntMatrix</code> manages an internal matrix. Operations on objects of
 * <code>IntMatrix</code> are almost performed like on a simple matrix.
 * 
 * @author jens
 */
public class IntMatrix extends MatrixPrimitive {
  /**
   * The <code>IntMatrix</code> is internally represented by a simple matrix.
   */
  private int[][] data;

  /**
   * The related <code>IntMatrixGenerator</code>, which is responsible for
   * generating the appropriate scriptcode for operations performed on this
   * object.
   */
  protected IntMatrixGenerator generator;

  /**
   * the properties for a matrix
   */
  private MatrixProperties properties = null;

  /**
   * the upper left corner of the matrix, necessary for placing it on the screen
   */
  private Node upperLeft = null;

  /**
   * Instantiates the <code>IntMatrix</code> and calls the create() method of
   * the associated <code>IntMatrixGenerator</code>.
   * 
   * @param iag
   *          the appropriate code <code>Generator</code>.
   * @param upperLeftCorner
   *          the upper left corner of this <code>IntMatrix</code>.
   * @param matrixData
   *          the data of this <code>IntMatrix</code>.
   * @param name
   *          the name of this <code>IntMatrix</code>.
   * @param display
   *          [optional] the <code>DisplayOptions</code> of this
   *          <code>IntMatrix</code>.
   * @param iap
   *          [optional] the properties of this <code>IntMatrix</code>.
   */
  public IntMatrix(IntMatrixGenerator iag, Node upperLeftCorner,
      int[][] matrixData, String name, DisplayOptions display,
      MatrixProperties iap) {
    super(iag, display);

    if (upperLeftCorner == null) {
      throw new IllegalArgumentException("The coordinate of the "
          + "upper left Node shouldn't be null!");
    }

    if (matrixData == null) {
      throw new IllegalArgumentException(
          "Null matrix passed in to IntMatrix, named " + name);
    }

    upperLeft = upperLeftCorner;
    if (matrixData != null) {
      nrRows = matrixData.length;
      if (matrixData[0] != null)
        nrCols = matrixData[0].length;
    }
    data = matrixData;

    properties = iap;
    setName(name);

    generator = iag;
    generator.create(this);
  }

  private boolean checkForValidPosition(int row, int col, String methodName) {
    if (row < data.length && row >= 0 && col < getNrCols() && col >= 0)
      return true;

    StringBuilder sb = new StringBuilder("Invalid position [");
    sb.append(row).append("][").append(col).append("] in method ");
    sb.append(methodName).append(" of class IntMatrix");
    throw new IllegalArgumentException(sb.toString());
  }

  public int getElement(int row, int col) {
    if (checkForValidPosition(row, col, "getElement[" + row + "][" + col + "]"))
      return data[row][col];
    return 0;
  }

  /**
   * Puts the value <code>what</code> at position <code>[row][col]</code>.
   * This is the delayed version as specified by <code>t</code>. The
   * <code>duration</code> of this operation may also be specified.
   * 
   * @param row
   *          the row position of the element to write.
   * @param col
   *          the column position of the element to write.
   * @param what
   *          the new value.
   * @param t
   *          [optional] the delay which shall be applied to the operation.
   * @param d
   *          [optional] the duration this action needs.
   */
  public void put(int row, int col, int what, Timing t, Timing d)
      throws IndexOutOfBoundsException {
    if (checkForValidPosition(row, col, "put")) {
      data[row][col] = what;
      generator.put(this, row, col, what, t, d);
    }
  }

  /**
   * Swaps the elements at index <code>[sourceRow][sourceCol]</code> and
   * <code>[targetRow][targetCol]</code>. This is the delayed version. The
   * <code>duration</code> of this operation may also be specified.
   * 
   * @param sourceRow
   *          the row position of the first element to swap.
   * @param sourceCol
   *          the column position of the first element to swap.
   * @param targetRow
   *          the row position of the second element to swap.
   * @param targetCol
   *          the column position of the second element to swap.
   * @param t
   *          [optional] the delay which shall be applied to the operation.
   * @param d
   *          [optional] the duration this action needs.
   */
  public void swap(int sourceRow, int sourceCol, int targetRow, int targetCol,
      Timing t, Timing d) throws IndexOutOfBoundsException {
    if (checkForValidPosition(sourceRow, sourceCol, "swap param 1")
        && checkForValidPosition(targetRow, targetCol, "swap param 2")) {
      int tmp = data[sourceRow][sourceCol];
      data[sourceRow][sourceCol] = data[targetRow][targetCol];
      data[targetRow][targetCol] = tmp;
      generator.swap(this, sourceRow, sourceCol, targetRow, targetCol, t, d);
    }
  }

  /**
   * Returns the internal <code>int matrix</code>.
   * 
   * @return the internal <code>int matrix</code>.
   */
  public int[][] getData() {
    return data;
  }

  /**
   * Returns the data at the given position of the internal matrix.
   * 
   * @param row
   *          the position where to look for the data.
   * @return the data at position <code>i</code> in the internal
   *         <code>int matrix</code>.
   */
  public int[] getRow(int row) throws IndexOutOfBoundsException {
    if (row < 0 || row >= getNrRows()) {
      throw new IndexOutOfBoundsException("Matrix has only row indices [0, "
          + (getNrRows() - 1) + ", but " + row + " was requested");
    }
    return data[row];
  }

  /**
   * Returns the upper left corner of this matrix.
   * 
   * @return the upper left corner of this matrix.
   */
  public Node getUpperLeft() {
    return upperLeft;
  }

  /**
   * Returns the properties of this matrix.
   * 
   * @return the properties of this matrix.
   */
  public MatrixProperties getProperties() {
    return properties;
  }

  /**
   * @see algoanim.primitives.Primitive#setName(java.lang.String)
   */
  public void setName(String newName) {
    properties.setName(newName);
    super.setName(newName);
  }

  /**
   * Highlights the matrix cell at a given position after a distinct offset.
   * 
   * @param row
   *          the row of the cell to highlight.
   * @param col
   *          the column of the cell to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightCell(int row, int col, Timing offset, Timing duration) {
    if (checkForValidPosition(row, col, "highlightCell")) {
      generator.highlightCell(this, row, col, offset, duration);
    }
  }

  /**
   * Highlights a range of array cells of an <code>IntMatrix</code>.
   * 
   * @param row
   *          the row of the interval to highlight.
   * @param startCol
   *          the start column of the interval to highlight.
   * @param endCol
   *          the end column of the interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightCellColumnRange(int row, int startCol, int endCol,
      Timing offset, Timing duration) {
    if (checkForValidPosition(row, startCol, "highlightCellColumnRange param 1")
        && checkForValidPosition(row, endCol,
            "highlightCellColumnRange param 2")) {
      generator.highlightCellColumnRange(this, row, startCol, endCol, offset,
          duration);
    }
  }

  /**
   * Highlights a range of array cells of an <code>IntMatrix</code>.
   * 
   * @param startRow
   *          the start row of the interval to highlight.
   * @param endRow
   *          the end row of the interval to highlight.
   * @param col
   *          the column of the interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightCellRowRange(int startRow, int endRow, int col,
      Timing offset, Timing duration) {
    if (checkForValidPosition(startRow, col, "highlightCellRowRange param 1")
        && checkForValidPosition(endRow, col, "highlightCellRowRange param 2")) {
      generator.highlightCellRowRange(this, startRow, endRow, col, offset,
          duration);
    }
  }

  /**
   * Unhighlights the array cell of an <code>IntMatrix</code> at a given
   * position after a distinct offset.
   * 
   * @param row
   *          the row position of the cell to unhighlight.
   * @param col
   *          the column position of the cell to unhighlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightCell(int row, int col, Timing offset, Timing duration) {
    if (checkForValidPosition(row, col, "unhighlightCell"))
      generator.unhighlightCell(this, row, col, offset, duration);
  }

  /**
   * Unhighlights a range of array cells of an <code>IntMatrix</code>.
   * 
   * @param row
   *          the row of the interval to highlight.
   * @param startCol
   *          the start column of the interval to highlight.
   * @param endCol
   *          the end column of the interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightCellColumnRange(int row, int startCol, int endCol,
      Timing offset, Timing duration) {
    if (checkForValidPosition(row, startCol,
        "unhighlightCellColumnRange param 1")
        && checkForValidPosition(row, endCol,
            "unhighlightCellColumnRange param 2")) {
      generator.unhighlightCellColumnRange(this, row, startCol, endCol, offset,
          duration);
    }
  }

  /**
   * Unhighlights a range of array cells of an <code>IntMatrix</code>.
   * 
   * @param startRow
   *          the start row of the interval to highlight.
   * @param endRow
   *          the end row of the interval to highlight.
   * @param col
   *          the column of the interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightCellRowRange(int startRow, int endRow, int col,
      Timing offset, Timing duration) {
    if (checkForValidPosition(startRow, col, "unhighlightCellRowRange param 1")
        && checkForValidPosition(endRow, col, "unhighlightCellRowRange param 2")) {
      generator.unhighlightCellRowRange(this, startRow, endRow, col, offset,
          duration);
    }
  }

  /**
   * Highlights the matrix element at a given position after a distinct offset.
   * 
   * @param row
   *          the row of the element to highlight.
   * @param col
   *          the column of the element to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightElem(int row, int col, Timing offset, Timing duration) {
    if (checkForValidPosition(row, col, "highlightElem")) {
      generator.highlightElem(this, row, col, offset, duration);
    }
  }

  /**
   * Highlights a range of matrix elements.
   * 
   * @param row
   *          the row of the interval to highlight.
   * @param startCol
   *          the start of the column interval to highlight.
   * @param endCol
   *          the end of the column interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightElemColumnRange(int row, int startCol, int endCol,
      Timing offset, Timing duration) {
    if (checkForValidPosition(row, startCol, "highlightElemColumnRange param 1")
        && checkForValidPosition(row, endCol,
            "highlightElemColumnRange param 2")) {
      generator.highlightElemColumnRange(this, row, startCol, endCol, offset,
          duration);
    }
  }

  /**
   * Highlights a range of array elements of an <code>IntMatrix</code>.
   * 
   * @param startRow
   *          the start of the row interval to highlight.
   * @param endRow
   *          the end of the row interval to highlight.
   * @param col
   *          the column interval to highlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void highlightElemRowRange(int startRow, int endRow, int col,
      Timing offset, Timing duration) {
    if (checkForValidPosition(startRow, col, "highlightElemRowRange param 1")
        && checkForValidPosition(endRow, col, "highlightElemRowRange param 2")) {
      generator.highlightElemRowRange(this, startRow, endRow, col, offset,
          duration);
    }
  }

  /**
   * Unhighlights the matrix element at a given position after a distinct
   * offset.
   * 
   * @param row
   *          the row of the element to unhighlight.
   * @param col
   *          the column of the element to unhighlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightElem(int row, int col, Timing offset, Timing duration) {
    if (checkForValidPosition(row, col, "unhighlightElement")) {
      generator.unhighlightElem(this, row, col, offset, duration);
    }
  }

  /**
   * Unhighlights a range of array elements of an <code>IntMatrix</code>.
   * 
   * @param row
   *          the row of the interval to unhighlight.
   * @param startCol
   *          the start of the column interval to unhighlight.
   * @param endCol
   *          the end of the column interval to unhighlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightElemColumnRange(int row, int startCol, int endCol,
      Timing offset, Timing duration) {
    if (checkForValidPosition(row, startCol,
        "unhighlightElemColumnRange param 1")
        && checkForValidPosition(row, endCol,
            "unhighlightElemColumnRange param 2")) {
      generator.unhighlightElemColumnRange(this, row, startCol, endCol, offset,
          duration);
    }
  }

  /**
   * Unhighlights a range of array elements of an <code>IntMatrix</code>.
   * 
   * @param startRow
   *          the start row of the interval to unhighlight.
   * @param endRow
   *          the end row of the interval to unhighlight.
   * @param col
   *          the column interval to unhighlight.
   * @param offset
   *          [optional] the offset after which the operation shall be started.
   * @param duration
   *          [optional] the duration this operation lasts.
   */
  public void unhighlightElemRowRange(int startRow, int endRow, int col,
      Timing offset, Timing duration) {
    if (checkForValidPosition(startRow, col, "unhighlightElemRowRange param 1")
        && checkForValidPosition(endRow, col, "unhighlightElemRowRange param 2")) {
      generator.unhighlightElemRowRange(this, startRow, endRow, col, offset,
          duration);
    }
  }
}
