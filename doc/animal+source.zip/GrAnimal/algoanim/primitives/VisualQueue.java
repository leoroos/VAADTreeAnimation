package algoanim.primitives;

import java.util.LinkedList;
import java.util.List;

import algoanim.primitives.generators.GeneratorInterface;
import algoanim.properties.QueueProperties;
import algoanim.util.DisplayOptions;
import algoanim.util.Node;

/**
 * Base abstract class for all the (FIFO-)queues in <code>animalscriptapi.primitives</code>.<br> 
 * <code>VisualQueue</code> represents the common visual features of all the subclasses 
 * and manges the actual data using an internal <code>java.util.LinkedList</code>.<br>
 * The stored objects are of the generic data type T, so it is generally possible
 * to use <code>VisualQueue</code> with any objects.
 *
 * @see algoanim.primitives.ConceptualQueue
 * @see algoanim.primitives.ArrayBasedQueue
 * @see algoanim.primitives.ListBasedQueue
 * @author Dima Vronskyi
 */
public abstract class VisualQueue<T> extends Primitive  {

	// the internal java.util.LinkedList to manage the actual data
	private LinkedList<T> queue;
	
	// the initial content of the queue
	private List<T> initContent;
	
	// the upper left corner of the queue primitive
	private Node upperLeft;
	
	private QueueProperties properties;
	
	/**
	 * Constructor of the <code>VisualQueue</code>.
	 * @param g the appropriate code <code>Generator</code>.
	 * @param upperLeftCorner the upper left corner of this <code>VisualQueue</code>.
	 * @param content the initial content of the <code>VisualQueue</code>, consisting
	 * 				  of the elements of the generic type T.
	 * @param name the name of this <code>VisualQueue</code>.
	 * @param display [optional] the <code>DisplayOptions</code> of this <code>VisualQueue</code>.
	 * @param qp [optional] the properties of this <code>VisualQueue</code>.
	 */
	public VisualQueue(GeneratorInterface g, Node upperLeftCorner, List<T> content,
			String name, DisplayOptions display, QueueProperties qp) {
		super(g, display);
		if (upperLeftCorner == null) {
    		throw new IllegalArgumentException("The coordinate of the " 
    				+ "upper left Node shouldn't be null!");
    	}
		upperLeft = upperLeftCorner;
		initContent = content;
		queue = new LinkedList<T>();
		if (initContent != null)
			queue.addAll(initContent);
		properties = qp;
		setName(name);
	}
	
	/**
	 * Adds the element <code>elem</code> as the last element to the end of the queue. 
	 * @param elem the element to be added to the end of the queue.
	 * @see java.util.LinkedList#offer(Object)
	 */
	public void enqueue(T elem) {
		queue.offer(elem);
	}
	
	/**
	 * Removes and returns the first element of the queue.
	 * @return The first element of the queue.
	 * @see java.util.LinkedList#poll()
	 */
	public T dequeue() {
		return queue.poll();
	}
	
	/**
	 * Retrieves (without removing) the first element of the queue.
	 * @return The first element of the queue.
	 * @see java.util.LinkedList#peek()
	 */
	public T front() {
		return queue.peek();
	}
	
	/**
	 * Retrieves (without removing) the last element of the queue.
	 * @return The last element of the queue.
	 * @see java.util.LinkedList#getLast()
	 */
	public T tail() {
		return queue.getLast();
	}
	
	/**
	 * Tests if the queue is empty.
	 * @return <code>true</code> if and only if the queue contains no elements;
	 * <code>false</code> otherwise.
	 * @see java.util.AbstractCollection#isEmpty()
	 */
	public boolean isEmpty() {
		return queue.isEmpty();
	}
	
	/**
	 * Returns the upper left corner of the queue.
	 * @return the upper left corner of the queue.
	 */
	public Node getUpperLeft() {
		return upperLeft;
	}
	
	/**
	 * @see algoanim.primitives.Primitive#setName(java.lang.String)
	 */
	public void setName(String newName) {
		properties.setName(newName);
		super.setName(newName);
	}

	/**
	 * Returns the initial content of the queue.
	 * @return The initial content of the queue.
	 */
	public List<T> getInitContent() {
		return initContent;
	}

	/**
	 * Returns the properties of the queue.
	 * @return The properties of the queue.
	 */
	public QueueProperties getProperties() {
		return properties;
	}

	/**
	 * Returns the internal queue as <code>java.util.LinkedList</code>.
	 * @return The internal queue.
	 */
	public LinkedList<T> getQueue() {
		return queue;
	}
}
