package algoanim.primitives.generators;

import algoanim.primitives.IntArray;
import algoanim.util.Timing;

/**
 * <code>IntArrayGenerator</code> offers methods to request the included 
 * Language object to
 * append integer array related script code lines to the output.
 * It is designed to be included by an <code>IntArray</code> primitive, 
 * which just redirects action calls to the generator.
 * Each script language offering an <code>IntArray</code> primitive has to 
 * implement its own
 * <code>IntArrayGenerator</code>, which is then responsible to create 
 * proper script code.  
 * 
 * @author Stephan Mehlhase 
 */
public interface IntArrayGenerator extends GeneratorInterface {  
	/**
	 * Creates the originating script code for a given <code>IntArray</code>,
	 * due to the fact that before a primitive can be worked with it has to be 
	 * defined and made known to the script language.
	 * 
	 * @param ia the <code>IntArray</code> for which the initiate script 
	 * code shall be created. 
	 */
    public void create(IntArray ia);

    /**
     * Inserts an <code>int</code> at certain position in the given 
     * <code>IntArray</code>.
     * 
     * @param iap the <code>IntArray</code> in which to insert the value.
     * @param where the position where the value shall be inserted.
     * @param what the <code>int</code> value to insert.
     * @param delay the time to wait until the operation shall be performed.
     * @param duration the duration of the operation.
     */
    public void put(IntArray iap, int where, int what, Timing delay, 
    		Timing duration);
    
    /**
     * Swaps to values in a given <code>IntArray</code>.
     * 
     * @param iap the <code>IntArray</code> in which to swap the two 
     * indizes.	
     * @param what the first array element.
     * @param with the second array element.
     * @param delay the time to wait until the operation shall be performed.
     * @param duration the duration of the operation.
     */
    public void swap(IntArray iap, int what, int with, Timing delay, 
    		Timing duration);

	/**
	 * Highlights the array cell at a given position after a distinct offset of an
	 * <code>IntArray</code>.
	 * @param position the position of the cell to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightCell(IntArray ia, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Highlights a range of array cells of an <code>IntArray</code>.
	 * @param from the start of the interval to highlight.
	 * @param to the end of the interval to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightCell(IntArray ia, int from, int to, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights the array cell of an <code>IntArray</code> at a given position 
	 * after a distinct offset.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param position the position of the cell to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightCell(IntArray ia, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights a range of array cells of an <code>IntArray</code>.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param from the start of the interval to unhighlight.
	 * @param to the end of the interval to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightCell(IntArray ia, int from, int to, Timing offset, 
			Timing duration);
	
	
	/**
	 * Highlights the array element of an <code>IntArray</code> at a given position 
	 * after a distinct offset.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param position the position of the element to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightElem(IntArray ia, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Highlights a range of array elements of an <code>IntArray</code>.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param from the start of the interval to highlight.
	 * @param to the end of the interval to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightElem(IntArray ia, int from, int to, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights the array element of an <code>IntArray</code> at a given position 
	 * after a distinct offset.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param position the position of the element to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightElem(IntArray ia, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights a range of array elements of an <code>IntArray</code>.
	 * @param ia the <code>IntArray</code> to work on.
	 * @param from the start of the interval to unhighlight.
	 * @param to the end of the interval to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightElem(IntArray ia, int from, int to, Timing offset, 
			Timing duration);

}
