package algoanim.primitives.generators;

import algoanim.primitives.StringArray;
import algoanim.util.Timing;

/**
 * <code>StringArrayGenerator</code> offers methods to request the 
 * included Language object to
 * append String array related script code lines to the output.
 * It is designed to be included by a <code>StringArray</code> primitive, 
 * which just redirects action calls to the generator.
 * Each script language offering a <code>StringArray</code> primitive has 
 * to implement its own
 * <code>StringArrayGenerator</code>, which is then responsible to create 
 * proper script code.  
 * 
 * @author Stephan Mehlhase 
 */
public interface StringArrayGenerator extends GeneratorInterface {
	/**
	 * Creates the originating script code for a given 
	 * <code>StringArray</code>, due to the fact that before a primitive can 
	 * be worked with it has to be defined and made known to the script 
	 * language.
	 * 
	 * @param sa the <code>StringArray</code> for which the initiate script 
	 * code shall be created. 
	 */
    public void create(StringArray sa);
    
    /**
     * Inserts a <code>String</code> at certain position in the given 
     * <code>StringArray</code>.
     * 
     * @param iap the <code>StringArray</code> in which to insert the 
     * value.
     * @param where the position where the value shall be inserted.
     * @param what the <code>String</code> value to insert.
     * @param delay the time to wait until the operation shall be performed.
     * @param duration the duration of the operation.
     */
    public void put(StringArray iap, int where, String what, Timing delay, 
    		Timing duration);
    
    /**
     * Swaps to values in a given <code>StringArray</code>.
     * 
     * @param iap the <code>StringArray</code> in which to swap the two 
     * indexes.	
     * @param what the first array element.
     * @param with the second array element.
     * @param delay the time to wait until the operation shall be performed.
     * @param duration the duration of the operation.
     */
    public void swap(StringArray iap, int what, int with, Timing delay, 
    		Timing duration);
    
	/**
	 * Highlights the array cell at a given position after a distinct offset of an
	 * <code>StringArray</code>.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param position the position of the cell to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightCell(StringArray sa, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Highlights a range of array cells of an <code>StringArray</code>.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param from the start of the interval to highlight.
	 * @param to the end of the interval to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightCell(StringArray sa, int from, int to, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights the array cell of an <code>StringArray</code> at a given position 
	 * after a distinct offset.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param position the position of the cell to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightCell(StringArray sa, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights a range of array cells of an <code>StringArray</code>.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param from the start of the interval to unhighlight.
	 * @param to the end of the interval to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightCell(StringArray sa, int from, int to, Timing offset, 
			Timing duration);
	
	
	/**
	 * Highlights the array element of an <code>StringArray</code> at a given position 
	 * after a distinct offset.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param position the position of the element to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightElem(StringArray sa, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Highlights a range of array elements of an <code>StringArray</code>.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param from the start of the interval to highlight.
	 * @param to the end of the interval to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightElem(StringArray sa, int from, int to, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights the array element of an <code>StringArray</code> at a given position 
	 * after a distinct offset.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param position the position of the element to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightElem(StringArray sa, int position, Timing offset, 
			Timing duration);
	
	/**
	 * Unhighlights a range of array elements of an <code>StringArray</code>.
	 * @param sa the <code>StringArray</code> to work on.
	 * @param from the start of the interval to unhighlight.
	 * @param to the end of the interval to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started. 
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightElem(StringArray sa, int from, int to, Timing offset, 
			Timing duration);

}
