package algoanim.primitives;

import algoanim.primitives.generators.GraphGenerator;
import algoanim.properties.GraphProperties;
import algoanim.util.DisplayOptions;
import algoanim.util.Node;
import algoanim.util.Timing;

/**
 * Represents a graph 
 * 
 * @author Dr. Guido Roessling (roessling@acm.org>
 * @version 0.7 2007-04-04
 */
public class Graph extends Primitive {
	private GraphGenerator generator = null;

//	private String text = null;

	protected String[] nodeLabels = null;
	
	protected Node[] nodes = null;
	
	protected int[][] adjacencyMatrix = null;

	private GraphProperties properties = null;
	
	//Madi
	private Node startKnoten;
	private Node zielKnoten;

	/**
	 * Instantiates the <code>Graph</code> and calls the create() method of the
	 * associated <code>GraphGenerator</code>.
	 * 
	 * @param graphGen
	 *          the appropriate code <code>Generator</code>.
	 * @param name the name for the graph
	 * @param graphAdjacencyMatrix the adjacency matrix for the graph
	 * @param graphNodes the graph's nodes
	 * @param labels the labels for the graph nodes
	 * @param display
	 *          [optional] the <code>DisplayOptions</code> of this
	 *          <code>Text</code> element.
	 * @param props
	 *          [optional] the properties of this <code>Text</code> element.
	 */
	public Graph(GraphGenerator graphGen, String name,
			int[][] graphAdjacencyMatrix, Node[] graphNodes, String[] labels,  
		  DisplayOptions display, GraphProperties props) {
		super(graphGen, display);

		generator = graphGen;
		properties = props;
		setName(name);
		if (graphAdjacencyMatrix == null || graphNodes == null 
				|| graphAdjacencyMatrix.length != graphNodes.length)
			throw new IllegalArgumentException(
					"Adjacency matrix and nodes must not be empty and have same size!");
		adjacencyMatrix = graphAdjacencyMatrix;
		nodes = graphNodes;
		nodeLabels = labels;
		generator.create(this);
	}

	/**
	 * Returns the properties of this <code>Graph</code> element.
	 * 
	 * @return the properties of this <code>Graph</code> element.
	 */
	public GraphProperties getProperties() {
		return properties;
	}
	
	private boolean checkForValidIndex(int row, int col, String methodName) {
		if (adjacencyMatrix != null 
				&& row >= 0 && row < adjacencyMatrix.length
				&& col >= 0 && col < adjacencyMatrix[row].length)
			return true;
		throw new IllegalArgumentException("Invalid access for method "
				+methodName +" to non-existent cell [" +row +"][" +col +"]");
	}

	/**
	 * Returns the adjacency matrix of this <code>Graph</code> element.
	 * 
	 * @return the adjaceny matrix of this <code>Graph</code> element.
	 */
	public int[][] getAdjacencyMatrix() {
		return adjacencyMatrix;
	}
	
	public int getSize() {
		if (adjacencyMatrix != null)
			return adjacencyMatrix.length;
		return 0;
	}
	
	public Node getNode(int nodeNr) {
		if (checkForValidIndex(nodeNr, nodeNr, "getNode"))
			return nodes[nodeNr];
		return null;
	}
	
	public String getNodeLabel(int nodeNr) {
		if (checkForValidIndex(nodeNr, nodeNr, "getNodeLabels"))
			return nodeLabels[nodeNr];
		return null;
	}

	
	/**
	 * Returns the adjacency matrix of this <code>Graph</code> element.
	 * 
	 * @return the adjaceny matrix of this <code>Graph</code> element.
	 */
	public int[] getEdgesForNode(int node) {
		if (checkForValidIndex(node, 0, "getEdgesForNode"))
			return adjacencyMatrix[node];
		return null;
	}
	
	public int getEdgeWeight(int fromNode, int toNode) {
		if (checkForValidIndex(fromNode, toNode, "getEdgeWeight"))
			return adjacencyMatrix[fromNode][toNode];
		return 0;
	}

	public void setEdgeWeight(int fromNode, int toNode, int weight,
			Timing offset, Timing duration) {
		setEdgeWeight(fromNode, toNode, String.valueOf(weight), 
				offset, duration);
		adjacencyMatrix[fromNode][toNode] = weight;
	}
	
	public void setEdgeWeight(int fromNode, int toNode, String weight, 
			Timing offset, Timing duration) {
		if (checkForValidIndex(fromNode, toNode, "getEdgeWeight")) {
			generator.setEdgeWeight(this, fromNode, toNode, weight, offset,
					duration);
		}
	}

	
	/**
	 * hide a selected graph node by turning it invisible
	 * 
	 * @param index the index of the node to be hidden
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void hideNode(int index, Timing offset, Timing duration) {
		if (checkForValidIndex(index, index, "hideNode")) {
			generator.hideNode(this, index, offset, duration);
		}
	}

	
	/**
	 * hide a selected set of graph nodes by turning them invisible
	 * 
	 * @param indices the set of node indices to be hidden
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void hideNodes(int[] indices, Timing offset, Timing duration) {
		generator.hideNodes(this, indices, offset, duration);
	}

	/**
	 * show a selected (previously visible?) graph edge by turning it invisible
	 * 
	 * @param startNode the start node of the edge to be hidden
	 * @param endNode the end node of the edge to be hidden
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void hideEdge(int startNode, int endNode, Timing offset, 
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "hideEdge")) {
			generator.hideEdge(this, startNode, endNode, offset, duration);
		}
	}
	
	/**
	 * hides a selected (previously visible?) graph edge weight by turning it invisible
	 * 
	 * @param startNode the start node of the edge weight to be hidden
	 * @param endNode the end node of the edge weightto be hidden
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void hideEdgeWeight(int startNode, int endNode, Timing offset, 
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "hideEdge")) {
			generator.hideEdgeWeight(this, startNode, endNode, offset, duration);
		}
	}


	/**
	 * show a selected (previously hidden) graph edge by turning it visible
	 * 
	 * @param startNode the start node of the edge to be shown
	 * @param endNode the end node of the edge to be hidden
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void showEdge(int startNode, int endNode, Timing offset, 
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "showEdgeWeight")) {
			generator.showEdge(this, startNode, endNode, offset, duration);
		}
	}

	/**
	 * show a selected (previously invisible?) graph edge weight by turning it visible
	 * 
	 * @param startNode the start node of the edge weight to be shown
	 * @param endNode the end node of the edge weightto be shown
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void showEdgeWeight(int startNode, int endNode, Timing offset, 
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "showEdgeWeight")) {
			generator.showEdgeWeight(this, startNode, endNode, offset, duration);
		}
	}

	
	/**
	 * show a selected (previously hidden) graph node by turning it visible
	 * 
	 * @param index the index of the node to be shown
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void showNode(int index, Timing offset, Timing duration) {
		if (checkForValidIndex(index, index, "hideNode")) {
			generator.showNode(this, index, offset, duration);
		}
	}
	
	/**
	 * show a selected (previously hidden) graph node by turning it visible
	 * 
	 * @param indices the index of the node to be shown
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void showNodes(int[] indices, Timing offset, Timing duration) {
		generator.showNodes(this, indices, offset, duration);
	}

	
	
	/**
	 * Highlights the graph edge at a given position after a distinct offset.
	 * 
	 * @param startNode the start node of the edge to highlight.
	 * @param endNode the end node of the edge to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightEdge(int startNode, int endNode, Timing offset,
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "highlightEdge")) {
			generator.highlightEdge(this, startNode, endNode, offset, duration);
		}
	}
	
	
	/**
	 * Unhighlights the graph edge at a given position after a distinct offset.
	 * 
	 * @param startNode the start node of the edge to unhighlight.
	 * @param endNode the end node of the edge to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightEdge(int startNode, int endNode, Timing offset,
			Timing duration) {
		if (checkForValidIndex(startNode, endNode, "unhighlightEdge")) {
			generator.unhighlightEdge(this, startNode, endNode, offset, duration);
		}
	}
	
	/**
	 * Highlights the chosen graph node after a distinct offset.
	 * 
	 * @param node the node to highlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void highlightNode(int node, Timing offset,
			Timing duration) {
		if (checkForValidIndex(node, node, "highlightNode")) {
			generator.highlightNode(this, node, offset, duration);
		}
	}
	
	/**
	 * Unhighlights the chosen graph node after a distinct offset.
	 * 
	 * @param node the node to unhighlight.
	 * @param offset [optional] the offset after which the operation shall be 
	 * started.
	 * @param duration [optional] the duration this operation lasts.
	 */
	public void unhighlightNode(int node, Timing offset,
			Timing duration) {
		if (checkForValidIndex(node, node, "unhighlightNode")) {
			generator.unhighlightNode(this, node, offset, duration);
		}
	}
	
	public void translateNode(int nodeIndex, Node location, 
			Timing offset, Timing duration) {
		if (checkForValidIndex(nodeIndex, nodeIndex, "translateNode")) {
			generator.translateNode(this, nodeIndex, location, offset, 
					duration);
		}
	}

	public void translateWithFixedNodes(int[] nodeIndices, Node location, 
			Timing offset, Timing duration) {
		generator.translateWithFixedNodes(this, nodeIndices, location, offset, 
				duration);
	}
	public void translateNodes(int[] nodeIndices, Node location, 
			Timing offset, Timing duration) {
		generator.translateNodes(this, nodeIndices, location, offset, 
				duration);
	}

//	/**
//	 * Returns the upper left corner of this <code>Text</code> element.
//	 * 
//	 * @return the upper left corner of this <code>Text</code> element.
//	 */
//	public Node getUpperLeft() {
//		return upperLeft;
//	}

	/**
	 * @see algoanim.primitives.Primitive#setName(java.lang.String)
	 */
	public void setName(String newName) {
		properties.setName(newName);
		super.setName(newName);
	}
	
//	public void setEdgeWeight(int startNode, int endNode, int weight) {
//		setEdgeWeight(startNode, endNode, String.valueOf(weight));
//	}
	
	//Madieha
	public void setStartKnoten(Node node){
		this.startKnoten= node;
		
	}
	public void setZielKnoten(Node node){
		this.zielKnoten= node;
		
	}
	public Node getStartKnoten(){
		return this.startKnoten;
		
	}
	public Node getZielKnoten(){
		return this.zielKnoten;
		
	}
	
}
