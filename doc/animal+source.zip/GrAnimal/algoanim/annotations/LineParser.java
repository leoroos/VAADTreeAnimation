package algoanim.annotations;

import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LineParser {
  private String             line;
  private String             labelChar;

  private int                indent;
  private String             code;
  private Vector<Annotation> props;

  public LineParser(String line) {
    this(line, "@");
  }

  public LineParser(String line, String labelChar) {
    this.line = line.replaceAll("\\s", " ");
    this.labelChar = labelChar;

    parseIndent();
    parseCode();
    parseProperties();
  }

  private void parseIndent() {
    indent = 0;
    while (indent < line.length() && line.charAt(indent) == ' ')
      indent++;
  }

  private void parseCode() {
    Pattern p = Pattern.compile("([^" + labelChar + "]+)(" + labelChar + ".*)");
    Matcher m = p.matcher(line);

    if (m.find()) {
      code = m.group(1).trim();
    } else
      code = "";
  }

  private void parseProperties() {
    props = new Vector<Annotation>();

    // alle annotations finden
    String value = "[a-zA-Z0-9,.\\-_ +*/()]+";
    String regexp = labelChar + "([a-zA-Z]+)(?:\\((\"" + value + "\"(, \""
        + value + "\")*)?\\))?";

    Pattern p = Pattern.compile(regexp);
    Matcher m = p.matcher(line);

    // alle gefundenen annotations parsen
    while (m.find()) {
      String name = m.group(1);
      String options = m.group(2);

      Annotation prop = new Annotation(name);

      if (options != null) {
        String par_re = "\"(" + value + ")\"";
        Pattern par_p = Pattern.compile(par_re);
        Matcher par_m = par_p.matcher(options);

        while (par_m.find()) {
          prop.addParameter(par_m.group(1));
        }
      }
      props.add(prop);
    }
  }

  /**
   * @return identation level for this line
   */
  public int getIndent() {
    return indent;
  }

  /**
   * @return code part of this line
   */
  public String getCode() {
    return code;
  }

  /**
   * @return all parsed annotations of this line
   */
  public Vector<Annotation> getProperties() {
    return props;
  }

  public String getLabel() {
    for (int i = 0; i < props.size(); i++)
      if (props.get(i).getName().equals("label"))
        return props.get(i).getParameters().get(0);

    return null;
  }

  public boolean isContinue() {
    for (int i = 0; i < props.size(); i++)
      if (props.get(i).getName().equals("continue"))
        return true;

    return false;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder(256);
    sb.append("indentation: ").append((Integer.valueOf(indent)));
    sb.append("\ncode: ").append(code).append("\nprops: ").append(props);
    sb.append("\ncontinued: ").append(isContinue()).append("\nlabel: ");
    sb.append(getLabel()).append("\n");
    return sb.toString();
  }

  /**
   * @param args
   */
  public static void main(String[] args) {
    /*
     * System.out.println(newLineParser(
     * "public void sort(int[] array) {			@label(\"header\") @highlight(\"end\")"
     * )); System.out.println(new
     * LineParser("	int i, j;								@label(\"variables\") @var(\"i\") @var(\"j\")"
     * )); System.out.println(newLineParser(
     * "	boolean swapPerformed = true;			@label(\"initSwap\") @var(\"swapPerformed\", \"true\")"
     * )); System.out.println(newLineParser(
     * "	for (i = array.length;				@label(\"outerLoopInit\") @highlight(\"outerLoopEnd\") @set(\"i\", \"tja ^^\") @continued"
     * )); System.out.println(newLineParser(
     * "	swapPerformed && i > 0;				@label(\"outerLoopCond\") @highlight(\"outerLoopEnd\") @continued"
     * )); System.out.println(newLineParser(
     * "	i--) {								@label(\"outerLoopDec\") @highlight(\"outerLoopEnd\") @dec(\"i\")"
     * )); System.out.println(newLineParser(
     * "		swapPerformed = false;				@label(\"resetSwap\") @set(\"swapPerformed\", \"false\")"
     * )); System.out.println(newLineParser(
     * "		for (j = 1;							@label(\"innerLoopInit\")  @highlight(\"innerLoopEnd\") @continued"
     * )); System.out.println(newLineParser(
     * "		j < i;								@label(\"innerLoopCond\") @highlight(\"innerLoopEnd\") @continued"
     * )); System.out.println(newLineParser(
     * "		j++) {								@label(\"innerLoopInc\") @inc(\"j\") @highlight(\"innerLoopEnd\")"
     * )); System.out.println(newLineParser(
     * "			if (array[j - 1] > array[j]) {	@label(\"if\") @highlight(\"endif\")"
     * )); System.out.println(new
     * LineParser("				swap(array, j - 1, j);			@label(\"swap\")"));
     * System.out.println(newLineParser(
     * "				swapPerformed = true;			@label(\"swap=true\") @set(\"swapPerformed\", \"true\")"
     * )); System.out.println(new LineParser("			}									@label(\"endif\")"));
     * System.out.println(new
     * LineParser("		}									@label(\"innerLoopEnd\")"));
     * System.out.println(new
     * LineParser("	}										@label(\"outerLoopEnd\")"));
     * System.out.println(new LineParser("}										@label(\"end\")"));
     * System.out.println(newLineParser(
     * "function int ComplexFormula() {		@label(\"header\") @highlight(\"end\")\n"
     * )); System.out.println(newLineParser(
     * "	int a = 3;							@label(\"vars\") @declare(\"int\", \"a\" , \"3\") @exec(\"vars1\") @exec(\"vars2\") @exec(\"vars3\")\n"
     * )); System.out.println(newLineParser(
     * "	int b = 2;							@label(\"vars1\") @declare(\"int\", \"b\", \"2\")\n"
     * )); System.out.println(newLineParser(
     * "	int a = 3;							@label(\"vars\") @declare(\"int\", \"a\", \"3\")  @declare(\"int\", \"b\", \"2\") @declare(\"float\", \"c\", \"1.43\") @highlight(\"vars1\") @declare(\"float\", \"res\", \"0\") @highlight(\"vars2\") @highlight(\"vars3\")\n"
     * ));
     */
    String line = "res = -3 * (a + (-b))/c;					@label(\"calc\") @eval(\"res\", \"-(3 * 2) /  1.234 -var\")";
    System.out.println(line + (new LineParser(line)));

  }

}
