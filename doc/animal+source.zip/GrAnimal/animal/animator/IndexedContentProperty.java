package animal.animator;

public class IndexedContentProperty {

	
	private Object property;

	public IndexedContentProperty(Object property) {
		this.property = property;
	}

	public Object getProperty() {
		return property;
	}

}
