package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTEllipse;
import animal.graphics.PTGraphicObject;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Polyline
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class EllipseEditor extends ArcBasedShapeEditor implements ItemListener,
    ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  public EllipseEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    Box contentBox = createCommonElements(generator);

    // create type-specific stuff
    filledCB = generator.generateJCheckBox("GenericEditor.filled", null, this);
    filledCB.addItemListener(this);
    contentBox.add(filledCB);

    // finish the boxes
    finishBoxes();
  }

  public int pointsNeeded() {
    return 2;
  }

  public boolean nextPoint(int num, Point p) {
    PTEllipse shape = (PTEllipse) getCurrentObject();
    if (num == 1)
      shape.setCenter(p.x, p.y);
    if (num == 2)
      shape.setRadius(Math.abs(p.x - shape.getCenter().x), Math.abs(p.y
          - shape.getCenter().y));
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTEllipse pg = (PTEllipse) go;
    Point a = new Point(pg.getCenter().x, pg.getCenter().y);
    Rectangle boundingBox = pg.getBoundingBox();
    if (boundingBox.contains(p.x, p.y))
      return 0;

    // (ULC, URC)
    Point b = new Point(a.x + pg.getXRadius(), a.y);
    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (URC, LRC)
    b.translate(0, pg.getXRadius());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (LRC, LLC)
    a.translate(pg.getXRadius(), pg.getYRadius());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    newDist = MSMath.dist(p, a, pg.getCenter());
    if (newDist < minDist)
      minDist = newDist;
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTEllipse pg = (PTEllipse) go;
    Point radius = pg.getRadius();
    // add change points(nodes)
    EditPoint[] result = new EditPoint[5];
    Point helper = pg.getCenter();
 
    int x = helper.x;
    int y = helper.y;
    int nr = 0;
    result[nr++] = new EditPoint(2, new Point(x + radius.x, y + radius.y));
    result[nr++] = new EditPoint(-1, new Point(x - radius.x, y));
    result[nr++] = new EditPoint(-2, new Point(x, y + radius.y));
    result[nr++] = new EditPoint(-3, new Point(x + radius.x, y));
    result[nr++] = new EditPoint(-4, new Point(x, y - radius.y));

    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(PTEllipse.ELLIPSE_TYPE
        + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(PTEllipse.ELLIPSE_TYPE + ".depth",
        "16"));
    fillColorChooser.setColor(props.getColorProperty(PTEllipse.ELLIPSE_TYPE
        + ".fillColor", Color.black));
    filledCB.setSelected(props
        .getBoolProperty(PTEllipse.ELLIPSE_TYPE + ".filled"));
  }

  public void getProperties(XProperties props) {
    props.put(PTEllipse.ELLIPSE_TYPE + ".color", colorChooser.getColor());
    props.put(PTEllipse.ELLIPSE_TYPE + ".depth", depthBox.getSelectedItem());
    props.put(PTEllipse.ELLIPSE_TYPE + ".fillColor", fillColorChooser.getColor());
    props.put(PTEllipse.ELLIPSE_TYPE + ".filled", filledCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTEllipse p = (PTEllipse) getCurrentObject();

    if (e.getSource() == filledCB) {
      if (p != null)
        p.setFilled(filledCB.isSelected());
    }

    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTEllipse pg = new PTEllipse();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTEllipse p = (PTEllipse) eo;
    p.setColor(colorChooser.getColor());
    p.setFilled(filledCB.isSelected());
    p.setFillColor(fillColorChooser.getColor());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTEllipse p = (PTEllipse) eo;
    colorChooser.setColor(p.getColor());
    filledCB.setEnabled(true);
    filledCB.setSelected(p.isFilled());
    fillColorChooser.setColor(p.getFillColor());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    EllipseEditor result = new EllipseEditor();
    // important! result must be of type EllipseEditor (or cast)
    // and the parameter passed must be of type PTEllipse.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("EllipseEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTEllipse p = (PTEllipse) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTEllipse poly = (PTEllipse) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    else if ("fillColor".equals(eventName))
      poly.setFillColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTEllipse.ELLIPSE_TYPE;
  }
} // EllipseEditor
