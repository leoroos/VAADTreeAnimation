/*
 * Created on 25.04.2007 by Guido Roessling (roessling@acm.org>
 */
package animal.editor.graphics;

import java.awt.Color;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.text.DefaultEditorKit;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.graphics.PTArc;
import animal.main.Animal;
import animal.misc.ColorChooserAction;
import animal.misc.TextUtilities;

/**
 * support for text editors
 * @author roessling
 * @version 1.1 2008-06-23
 */
public abstract class AbstractTextEditor extends GraphicEditor {

  /**
	 * 
	 */
	private static final long serialVersionUID = -3830670048284912742L;

protected JTextField textField;

  protected JComboBox fontName;

  protected JComboBox fontSize;

  protected JCheckBox bold;

  protected JCheckBox italic;

  protected ColorChooserAction textColorChooser;

  public Box generateTextOperationsBox(TranslatableGUIElement generator,
      String borderKey) {
    Box textEntryBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        borderKey);

    // add a text input field
    textField = new JTextField(16);
    textField.addActionListener(this);
    textEntryBox.add(textField);

    // add a box with cut, copy, paste buttons
    Box textEditBox = new Box(BoxLayout.LINE_AXIS);
    Action theAction = TextUtilities
        .findTextFieldAction(DefaultEditorKit.cutAction);
    textEditBox.add(generator.generateActionButton("AbstractTextEditor.cut", null, theAction));

    theAction = TextUtilities.findTextFieldAction(DefaultEditorKit.copyAction);
    textEditBox.add(generator.generateActionButton("AbstractTextEditor.copy", null, theAction));

    theAction = TextUtilities.findTextFieldAction(DefaultEditorKit.pasteAction);
    textEditBox.add(generator.generateActionButton("AbstractTextEditor.paste", null, theAction));
    textEntryBox.add(textEditBox);

    return textEntryBox;
  }

  public Box generateTextComponentBox(TranslatableGUIElement generator) {
    Box textBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "AbstractTextEditor.textCompBL");
    // OK like this?

    // first, add text entry and cut/copy/paste
    textBox.add(generateTextOperationsBox(generator, "AbstractTextEditor.textBL"));
    // now, add font, size, bold/italics selection
    textBox.add(generateFontAndStyleBox(generator, "AbstractTextEditor.fontBL"));

    // finally, add text color choice
    Box textColorBox = generator.generateBorderedBox(BoxLayout.LINE_AXIS,
        "textColorBL");
    textColorBox.add(generator.generateJLabel("GenericEditor.colorLabel"));
    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTArc) getCurrentObject()).getTextComponent().getColor();
    textColorChooser = createColorChooser("textColor", 
        "AbstractTextEditor.textColor", initialColor);
    textColorBox.add(new ExtendedActionButton(textColorChooser, KeyEvent.VK_T));
    textBox.add(textColorBox);
    return textBox;
  }

  public Box generateFontAndStyleBox(TranslatableGUIElement generator,
      String borderKey) {
    Box fontBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS, borderKey);

    // add a box for choosing the font
    Box fontNameBox = new Box(BoxLayout.LINE_AXIS);
    fontNameBox.add(AnimalTranslator.getGUIBuilder()
        .generateJLabel("GenericEditor.nameLabel"));
    String[] fonts = Animal.GLOBAL_FONTS; // Toolkit.getDefaultToolkit().getFontList();
    fontName = new JComboBox();
    for (int j = 0; j < fonts.length; j++)
      fontName.addItem(fonts[j]);
    fontName.addActionListener(this);
    fontNameBox.add(fontName);
    fontBox.add(fontNameBox);

    // add a font size choice box
    Box fontSizeBox = new Box(BoxLayout.LINE_AXIS);
    fontSizeBox.add(generator.generateJLabel("AbstractTextEditor.fontSizeLabel"));
    fontSize = new JComboBox();
    fontSize.setEditable(true);
    fontSize.addItem("8");
    fontSize.addItem("10");
    fontSize.addItem("12");
    fontSize.addItem("14");
    fontSize.addItem("16");
    fontSize.addItem("24");
    fontSize.setSelectedItem("12");
    fontSize.addActionListener(this);
    fontSizeBox.add(fontSize);
    fontBox.add(fontSizeBox);

    // add a font style choice box (bold? italic?)
    Box fontTypeBox = new Box(BoxLayout.LINE_AXIS);

    fontTypeBox.add(generator.generateJLabel("AbstractTextEditor.fontStyleLabel"));
    italic = generator.generateJCheckBox("italic", null, this);
    italic.setHorizontalAlignment(SwingConstants.CENTER);
    fontTypeBox.add(italic);

    bold = generator.generateJCheckBox("bold", null, this);
    bold.setHorizontalAlignment(SwingConstants.CENTER);
    fontTypeBox.add(bold);
    fontBox.add(fontTypeBox);

    return fontBox;
  }
}
