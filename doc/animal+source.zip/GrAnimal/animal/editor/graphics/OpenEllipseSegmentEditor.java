package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTOpenEllipseSegment;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a closed circle segment (also known as a "pie" for pie charts)
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class OpenEllipseSegmentEditor extends OrientedArcBasedShapeEditor
    implements ItemListener, ActionListener, PropertyChangeListener {
  private JCheckBox fwArrowBox, bwArrowBox;

  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  public OpenEllipseSegmentEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    Box contentBox = createCommonOpenArcElements(generator);
    addBox(contentBox);

    Box optionsBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "OpenEllipseSegmentEditor.oeProps");
    Box arrowsBox = new Box(BoxLayout.PAGE_AXIS);
    // Box addOnBox = new Box(BoxLayout.LINE_AXIS);
    // create type-specific stuff
    fwArrowBox = generator.generateJCheckBox("ArrowableShapeEditor.fwArrow",
        null, this);
    fwArrowBox.addItemListener(this);
    arrowsBox.add(fwArrowBox);

    bwArrowBox = generator.generateJCheckBox("ArrowableShapeEditor.bwArrow",
        null, this);
    bwArrowBox.addItemListener(this);
    arrowsBox.add(bwArrowBox);
    optionsBox.add(arrowsBox);

    clockwise = generator.generateJCheckBox("ArcBasedShapeEditor.clockwise",
        null, this);
    clockwise.addItemListener(this);
    optionsBox.add(clockwise);

    addBox(optionsBox);
    // finish the boxes
    finishBoxes();
  }

  /**
   * returns the number of points or clicks needed to draw this primitive Here,
   * the number is four:
   * 
   * <ol>
   * <li>the primitive's center</li>
   * <li>the primitive's radius</li>
   * <li>the primitive's start angle</li>
   * <li>the primitive's end angle</li>
   * </ol>
   */
  public int pointsNeeded() {
    return 4;
  }

  public boolean nextPoint(int num, Point p) {
    PTOpenEllipseSegment shape = (PTOpenEllipseSegment) getCurrentObject();
    switch (num) {
    case 1:
      shape.setCenter(p.x, p.y);
      break;
    case 2:
      shape.setRadius(MSMath.diff(p, shape.getCenter()));
      break;
    case 3:
      shape.setStartAngle(shape.getAngle(p));
      break;
    case 4:
      int angle = shape.getAngle(p) - shape.getStartAngle();
      if (angle <= 0)
        angle += 360;
      shape.setTotalAngle(angle);
      // now use the real attributes again
      shape.setFWArrow(fwArrowBox.isSelected());
      shape.setBWArrow(bwArrowBox.isSelected());
      break;
    }
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTOpenEllipseSegment pg = (PTOpenEllipseSegment) go;
    Point a = new Point(pg.getCenter().x, pg.getCenter().y);
    Rectangle boundingBox = pg.getBoundingBox();
    if (boundingBox.contains(p.x, p.y))
      return 0;

    // (ULC, URC)
    Point b = new Point(a.x + pg.getRadius().x, a.y);
    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (URC, LRC)
    b.translate(0, pg.getRadius().y);
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (LRC, LLC)
    a.translate(pg.getRadius().x, pg.getRadius().y);
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    newDist = MSMath.dist(p, a, pg.getCenter());
    if (newDist < minDist)
      minDist = newDist;
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTOpenEllipseSegment pg = (PTOpenEllipseSegment) go;
    // add change points(nodes)
    EditPoint[] result = new EditPoint[7];
    int x = pg.getCenter().x, rx = pg.getRadius().x;
    int y = pg.getCenter().y, ry = pg.getRadius().y;
    int nr = 0;
    result[nr++] = new EditPoint(2, new Point(x + rx, y + ry));
    result[nr++] = new EditPoint(3, pg.getPointAtLength(pg.getStartAngle()));
    result[nr++] = new EditPoint(4, pg.getPointAtLength(pg.getStartAngle()
        + pg.getTotalAngle()));

    result[nr++] = new EditPoint(-1, new Point(x - rx, y));
    result[nr++] = new EditPoint(-2, new Point(x, y + ry));
    result[nr++] = new EditPoint(-3, new Point(x + rx, y));
    result[nr++] = new EditPoint(-4, new Point(x, y - ry));

    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(
        PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE
        + ".depth", "16"));
    bwArrowBox.setSelected(props.getBoolProperty(
        PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".bwArrow", false));
    fwArrowBox.setSelected(props.getBoolProperty(
        PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".fwArrow", false));
  }

  public void getProperties(XProperties props) {
    props.put(PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".color", colorChooser
        .getColor());
    props.put(PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".depth", depthBox
        .getSelectedItem());
    props.put(PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".bwArrow", bwArrowBox
        .isSelected());
    props.put(PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE + ".fwArrow", fwArrowBox
        .isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTOpenEllipseSegment p = (PTOpenEllipseSegment) getCurrentObject();
    if (e.getSource() == clockwise)
      p.setClockwise(clockwise.isSelected());
    if (e.getSource() == bwArrowBox)
      p.setBWArrow(bwArrowBox.isSelected());
    if (e.getSource() == fwArrowBox)
      p.setFWArrow(fwArrowBox.isSelected());

    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTOpenEllipseSegment pg = new PTOpenEllipseSegment();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTOpenEllipseSegment p = (PTOpenEllipseSegment) eo;
    p.setColor(colorChooser.getColor());
    p.setFWArrow(fwArrowBox.isSelected());
    p.setBWArrow(bwArrowBox.isSelected());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTOpenEllipseSegment p = (PTOpenEllipseSegment) eo;
    colorChooser.setColor(p.getColor());
    bwArrowBox.setSelected(p.hasBWArrow());
    fwArrowBox.setSelected(p.hasFWArrow());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    OpenEllipseSegmentEditor result = new OpenEllipseSegmentEditor();
    // important! result must be of type CircleEditor (or cast)
    // and the parameter passed must be of type PTOpenEllipseSegment.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage(
        "OpenEllipseSegmentEditor.statusLine", new Object[] {
            DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTOpenEllipseSegment p = (PTOpenEllipseSegment) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTOpenEllipseSegment poly = (PTOpenEllipseSegment) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTOpenEllipseSegment.OPEN_ELLIPSE_SEGMENT_TYPE;
  }
} // OpenEllipseSegmentEditor
