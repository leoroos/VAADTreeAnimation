package animal.editor.graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTArc;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTText;
import animal.gui.DrawCanvas;
import animal.main.Animal;
import animal.main.Animation;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * The Editor for the Arc.
 * 
 * @see animal.graphics.PTArc
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class ArcEditor extends AbstractTextEditor implements ItemListener,
    PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = 3323874737657161500L;

  private ColorChooserAction colorChooser;

  private ColorChooserAction fillColorChooser;

  private ExtendedActionButton fillColorChooserButton;

  private JCheckBox isCircle;

  private JCheckBox isFilled;

  private JCheckBox isClosed;

  private JCheckBox orientationIsClockwise;

  private boolean isItalic, isBold;

  // arrows can only be set if the arc is neither closed nor filled
  private JCheckBox hasFwArrow;

  private JCheckBox hasBwArrow;

  /**
   * The Editor's constructor. Writes the components into a Panel and adds this
   * Panel to the Editor, then adds the Buttons.
   */
  public ArcEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    Box colorBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "GenericEditor.colorBL");
    Box firstRowBox = new Box(BoxLayout.LINE_AXIS);
    firstRowBox.add(generator.generateJLabel("GenericEditor.colorLabel"));
    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTText) getCurrentObject(false)).getColor();
    colorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "color", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor",
            new Object[] { AnimalTranslator
                .translateMessage("ArcEditor.lineColor") }), initialColor);
    firstRowBox.add(new ExtendedActionButton(colorChooser, KeyEvent.VK_C));
    colorBox.add(firstRowBox);

    Box secondRowBox = new Box(BoxLayout.LINE_AXIS);
    secondRowBox.add(generator.generateJLabel("GenericEditor.fillColorLabel"));

    initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTArc) getCurrentObject()).getFillColor();
    fillColorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "fillColor", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor",
            new Object[] { AnimalTranslator
                .translateMessage("GenericEditor.fillColor") }), initialColor);
    fillColorChooserButton = new ExtendedActionButton(fillColorChooser,
        KeyEvent.VK_F);
    secondRowBox.add(fillColorChooserButton);
    colorBox.add(secondRowBox);
    addBox(colorBox);

    // create entries for arc properties
    isCircle = new JCheckBox(AnimalTranslator
        .translateMessage("ArcEditor.circle"));
    isCircle.addActionListener(this);

    isFilled = new JCheckBox(AnimalTranslator
        .translateMessage("GenericEditor.filled"));
    isFilled.addItemListener(this);

    isClosed = new JCheckBox(AnimalTranslator
        .translateMessage("ArcEditor.closed"));
    isClosed.addItemListener(this);

    orientationIsClockwise = new JCheckBox(AnimalTranslator
        .translateMessage("ArcBasedShapeEditor.clockwise"));
    orientationIsClockwise.addActionListener(this);

    hasFwArrow = new JCheckBox(AnimalTranslator
        .translateMessage("ArrowableShapeEditor.fwArrow"));
    hasFwArrow.addItemListener(this);

    hasBwArrow = new JCheckBox(AnimalTranslator
        .translateMessage("ArrowableShapeEditor.bwArrow"));
    hasBwArrow.addItemListener(this);

    Box arcPropertiesBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "ArcEditor.arcPropsBL");

    Box closedFilledBox = new Box(BoxLayout.LINE_AXIS);
    closedFilledBox.add(isClosed);
    closedFilledBox.add(isFilled);

    Box circleClockwiseBox = new Box(BoxLayout.LINE_AXIS);
    circleClockwiseBox.add(isCircle);
    circleClockwiseBox.add(orientationIsClockwise);

    Box arrowModeBox = new Box(BoxLayout.LINE_AXIS);
    arrowModeBox.add(hasFwArrow);
    arrowModeBox.add(hasBwArrow);

    arcPropertiesBox.add(closedFilledBox);
    arcPropertiesBox.add(circleClockwiseBox);
    arcPropertiesBox.add(arrowModeBox);
    addBox(arcPropertiesBox);

    addBox(generateTextComponentBox(generator));
    // finish the boxes
    finishBoxes();
  }

  /**
   * how many points do we need to specify a Arc?
   * 
   * @see #nextPoint
   */
  public int pointsNeeded() {
    return 4;
  }

  /**
   * sets one of the Arc's points. <br>
   * 1: center 2: size(xRadius and yRadius) 3: startAngle 4: arcAngle
   */
  public boolean nextPoint(int num, Point p) {
    PTArc arc = (PTArc) getCurrentObject();
    switch (num) {
    case 1:
      // must only be called from nextPoint when creating
      // not when moving!
      arc.setCenter(p);
      arc.setStartAngle(0);
      // use arcAngle as a tag to determine whether the arc
      // is just being created. This is important, as during
      // creation only a line is drawn for the start angle while
      // afterwards all the arc is shifted.
      // In addition, by using 720 degrees, always a full ellipse
      // is painted.

      arc.setTotalAngle(720);
      break;
    case 2:
      if (arc.isCircular())
        arc.setRadius(MSMath.dist(arc.getCenter(), p));
      else {
        int xRadius = Math.abs(p.x - arc.getCenter().x);
        int yRadius = Math.abs(p.y - arc.getCenter().y);
        arc.setRadius(new Point(xRadius, yRadius));
      }
      break;
    case 3:
      arc.setStartAngle(arc.getAngle(p));
      if (Math.abs(arc.getTotalAngle()) == 720) {
        // arc was just created? see case 1:
        // then enable drawing of just a line, otherwise use
        // the current attributes.
        arc.setClosed(true);
        arc.setFilled(false);
      }
      break;
    case 4:
      int angle = arc.getAngle(p) - arc.getStartAngle();
      if (arc.isClockwise())
        angle = -angle;
      if (angle <= 0)
        angle += 360;
      arc.setTotalAngle(angle);
      // now use the real attributes again
      arc.setClosed(isClosed.isSelected());
      arc.setFilled(isFilled.isSelected());
      break;
    }
    return true;
  } // nextPoint;

  /**
   * returns the minimal distance from point <i>p</i> to the Arc. IMPORTANT:
   * use <code>PTGraphicObject</code> as first parameter and cast it to a
   * PTArc inside the method. Otherwise this method won't be called.
   */
  public int getMinDist(PTGraphicObject go, Point p) {
    int dist;
    PTArc arc = (PTArc) go;
    int angle = arc.getAngle(p);
    Point c = arc.getCenter();
    Point firstPoint = arc.getPointAtAngle(arc.getStartAngle());
    Point secondPoint = arc.getPointAtAngle(arc.getStartAngle()
        + arc.getTotalAngle());

    if (arc.isAngleInside(angle)) {
      // d is the "distance" according to the normal form of the
      // ellipse: x^2/a^2+y^2/b^2 = d = 1 for points on the ellipse
      double d = MSMath.sqr((double) (p.x - c.x) / arc.getXRadius())
          + MSMath.sqr((double) (p.y - c.y) / arc.getYRadius());
      if (d >= 1)// outside the ellipse

        dist = (int) Math.sqrt((d - 1) * 500);
      // scaling to get reasonable values
      else {
        if (arc.isFilled())
          dist = 0;
        else if (arc.isClosed())
          // minimum of distance to the border and the distance
          // to the lines from the border to the center
          dist = Math.min((int) Math.sqrt((1 - d) * 500), Math.min(MSMath.dist(
              p, firstPoint, c), MSMath.dist(p, secondPoint, c)));
        else
          // inside without lines from border to center
          // only consider the distance to the border

          dist = (int) Math.sqrt((1 - d) * 500);
      }
    } else { // !isAngleInside
      if (arc.isFilled() || arc.isClosed())// distance to the lines from border
        // to center

        dist = Math.min(MSMath.dist(p, firstPoint, c), MSMath.dist(p,
            secondPoint, c)); // as above.
      else
        // distance to the start and end point of the ellipse

        dist = Math
            .min(MSMath.dist(p, firstPoint), MSMath.dist(p, secondPoint));
    }
    return dist;
  }

  /**
   * returns the EditPoints of the Arc. Again, the parameter has to be of type
   * <b>PTGraphicObject</b>. A Arc has only one MovePoint(its center) and six
   * ChangePoints: if a circle, its radiuses; if an arc, the corners of its
   * bounding box, and the start and end angle.
   */
  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTArc arc = (PTArc) go;
    Point c = arc.getCenter();
    if (arc.isCircular()) {
      int r = arc.getRadius();
      return new EditPoint[] {
          new EditPoint(-1, c),
          // arcAngle must be before startAngle because if they coincide
          // still the arcAngle must be changeable
          new EditPoint(4, arc.getPointAtAngle(arc.getStartAngle()
              + arc.getTotalAngle())),
          new EditPoint(3, arc.getPointAtAngle(arc.getStartAngle())),
          // both arcAngle and startAngle must be before the radiuses
          // as those points may coincide
          new EditPoint(2, new Point(c.x - r, c.y)),
          new EditPoint(2, new Point(c.x + r, c.y)),
          new EditPoint(2, new Point(c.x, c.y - r)),
          new EditPoint(2, new Point(c.x, c.y + r)), };
    }

    int xr = arc.getXRadius();
    int yr = arc.getYRadius();
    return new EditPoint[] {
        new EditPoint(-1, c),
        new EditPoint(2, new Point(c.x - xr, c.y - yr)),
        new EditPoint(2, new Point(c.x - xr, c.y + yr)),
        new EditPoint(2, new Point(c.x + xr, c.y - yr)),
        new EditPoint(2, new Point(c.x + xr, c.y + yr)),
        // the above edit points are outside the arc, so
        // the order doesn't matter here.
        new EditPoint(4, arc.getPointAtAngle(arc.getStartAngle()
            + arc.getTotalAngle())),
        new EditPoint(3, arc.getPointAtAngle(arc.getStartAngle())), };

  } // getEditPoints

  /**
   * extract the properties from <i>props</i>. All components are set according
   * to these properties.
   */
  public void setProperties(XProperties props) {
    bold.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".bold"));
    hasBwArrow.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".bwArrow"));
    isCircle.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".circle"));
    orientationIsClockwise.setSelected(props
        .getBoolProperty(PTArc.TYPE_LABEL + ".clockwise"));
    isClosed.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".closed"));
    colorChooser.setColor(props.getColorProperty(PTArc.TYPE_LABEL + ".color",
        Color.black));
    fillColorChooser.setColor(props.getColorProperty(PTArc.TYPE_LABEL
        + ".fillColor", Color.black));
    fontName.setSelectedItem(props.getProperty(PTArc.TYPE_LABEL + ".fontName",
        "SansSerif"));
    fontSize.setSelectedItem(props.getProperty(PTArc.TYPE_LABEL + ".fontSize",
        "12"));
    isFilled.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".filled"));
    hasFwArrow.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".fwArrow"));
    italic.setSelected(props.getBoolProperty(PTArc.TYPE_LABEL + ".italic"));
    if (textField != null)
      textField.setText(props.getProperty(PTArc.TYPE_LABEL + ".text"));
    textColorChooser.setColor(props.getColorProperty(PTArc.TYPE_LABEL
        + ".textColor", Color.black));
  }

  /**
   * writes the Editor's current permanent attributes to the Properties object.
   */
  public void getProperties(XProperties props) {
    props.put(PTArc.TYPE_LABEL + ".bold", bold.isSelected());
    props.put(PTArc.TYPE_LABEL + ".bwArrow", hasBwArrow.isSelected());
    props.put(PTArc.TYPE_LABEL + ".circle", isCircle.isSelected());
    props.put(PTArc.TYPE_LABEL + ".clockwise", orientationIsClockwise.isSelected());
    props.put(PTArc.TYPE_LABEL + ".closed", isClosed.isSelected());
    props.put(PTArc.TYPE_LABEL + ".color", colorChooser.getColor());
    props.put(PTArc.TYPE_LABEL + ".fillColor", fillColorChooser.getColor());
    props.put(PTArc.TYPE_LABEL + ".filled", isFilled.isSelected());
    props.put(PTArc.TYPE_LABEL + ".fontName", fontName.getSelectedItem());
    props.put(PTArc.TYPE_LABEL + ".fontSize", fontSize.getSelectedItem());
    props.put(PTArc.TYPE_LABEL + ".fwArrow", hasFwArrow.isSelected());
    props.put(PTArc.TYPE_LABEL + ".italic", italic.isSelected());
    props.put(PTArc.TYPE_LABEL + ".text", textField.getText());
    props.put(PTArc.TYPE_LABEL + ".textColor", textColorChooser.getColor());
  }

  /**
   * creates a new Arc and uses the attributes of this Editor as default values.
   */
  public EditableObject createObject() {
    PTArc arc = new PTArc();
    storeAttributesInto(arc);
    return arc;
  }

  /**
   * applies the Editor's settings to the Arc by setting all of Arcs attributes
   * according to the components. Parameter must be of type <b>EditableObject</b>
   * and be casted inside the method.
   */
  protected void storeAttributesInto(EditableObject eo) {
    // don't forget to store the parent's attributes!
    super.storeAttributesInto(eo);
    PTArc arc = (PTArc) eo; // just a shortcut
    if (textField != null)
      arc.setText(textField.getText());
    else
      arc.setText("");
    arc.getTextComponent().setFont(storeFont());
    arc.setCircle(isCircle.isSelected());
    arc.setFilled(isFilled.isSelected());
    arc.setClosed(isClosed.isSelected());
    arc.setClockwise(orientationIsClockwise.isSelected());
    arc.setFWArrow(hasFwArrow.isSelected());
    arc.setBWArrow(hasBwArrow.isSelected());
    arc.setColor(colorChooser.getColor());
    arc.setFillColor(fillColorChooser.getColor());
    arc.setTextColor(textColorChooser.getColor());
    PTText textCompo = arc.getTextComponent();
    String name = (String) fontName.getSelectedItem();
    String size = (String) fontSize.getSelectedItem();
    Font targetFont = new Font(name, Font.PLAIN + (isBold ? Font.BOLD : 0)
        + (isItalic ? Font.ITALIC : 0), getInt(size, 12));
    textCompo.setFont(targetFont);
    int width = 10;
    if (textField != null)
      width = Animal.getStringWidth(textField.getText(), targetFont);
    textCompo.setPosition(arc.getCenter().x - width / 2, arc.getCenter().y
        + targetFont.getSize() / 2);

  }

  /**
   * extracts the Font from the components' settings.
   */
  Font storeFont() {
    String name = (String) fontName.getSelectedItem();
    String size = (String) fontSize.getSelectedItem();
    return new Font(name, Font.PLAIN + (isBold ? Font.BOLD : 0)
        + (isItalic ? Font.ITALIC : 0), getInt(size, 12));
  }

  /**
   * sets the components according to the font.
   */
  void extractFont(Font f) {
    fontName.setSelectedItem(f.getName());
    fontSize.setSelectedItem(String.valueOf(f.getSize()));
    italic.setSelected(f.isItalic());
    bold.setSelected(f.isBold());
  }

  /**
   * makes the Editor reflect the Arc's attributes by setting all components
   * according to the attributes. Parameter must be of type <b>EditableObject</b>,
   * otherwise there may be problems with calls to super that can be difficult
   * to debug.
   */
  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTArc arc = (PTArc) eo;
    textField.setText(arc.getTextComponent().getText());
    extractFont(arc.getTextComponent().getFont());
    isCircle.setSelected(arc.isCircular());
    isFilled.setSelected(arc.isFilled());
    isClosed.setSelected(arc.isClosed());
    orientationIsClockwise.setSelected(arc.isClockwise());
    hasFwArrow.setSelected(arc.hasFWArrow());
    hasBwArrow.setSelected(arc.hasBWArrow());
    colorChooser.setColor(arc.getColor());
    fillColorChooser.setColor(arc.getFillColor());
    textColorChooser.setColor(arc.getTextComponent().getColor());
  }

  /**
   * creates a secondary Editor for the given <b>EditableObject</b> and copies
   * all of the object's attributes into the components. We can rely on this
   * object always being a <b>PTArc</b>.
   */
  public Editor getSecondaryEditor(EditableObject eo) {
    ArcEditor result = new ArcEditor();
    result.extractAttributesFrom(eo);
    return result;
  }

  /**
   * returns a short description how to create a Arc
   */
  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("ArcEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateCancelButton() });
  }

  /**
   * arrows can only be set if the arc is neither closed nor filled
   */
  public void itemStateChanged(ItemEvent e) {
    PTArc arc = (PTArc) getCurrentObject();

    if (arc != null) {
      if (e.getSource() == isClosed) {
        // only closed arcs may be filled
        isFilled.setEnabled(isClosed.isSelected());

        // only open arcs may have arrows
        hasFwArrow.setEnabled(!isClosed.isSelected());
        hasBwArrow.setEnabled(!isClosed.isSelected());
        arc.setClosed(isClosed.isSelected());
      } // else if (e.getSource() == filled)

      if (!isClosed.isSelected())
        arc.setFilled(false);
      else
        arc.setFilled(isFilled.isSelected());

      if (e.getSource() == isFilled)
        arc.setFilled(isFilled.isSelected());

      if (e.getSource() == hasFwArrow)
        arc.setFWArrow(hasFwArrow.isSelected());

      if (e.getSource() == hasBwArrow)
        arc.setBWArrow(hasBwArrow.isSelected());

      // in either case, set fillColor
      // fillColor.setEnabled(closed.isSelected() && filled.isSelected());
      fillColorChooserButton.setEnabled(isClosed.isSelected()
          && isFilled.isSelected());

      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  /**
   * handles the button press by calling a BoxPointer method.
   */
  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);

    PTArc arc = (PTArc) getCurrentObject();

    isItalic = arc.getTextComponent().getFont().isItalic(); // important
    isBold = arc.getTextComponent().getFont().isBold();

    if (e.getSource() == textField)
      arc.setText(textField.getText());

    if ((e.getSource() == fontName) || (e.getSource() == fontSize))
      arc.getTextComponent().setFont(storeFont());

    if (e.getSource() == italic) {
      isItalic = !isItalic;
      String name = (String) fontName.getSelectedItem();
      String size = (String) fontSize.getSelectedItem();
      Font newFont = new Font(name, Font.PLAIN
          + (bold.isSelected() ? Font.BOLD : 0)
          + (italic.isSelected() ? Font.ITALIC : 0), getInt(size, 12));
      arc.getTextComponent().setFont(newFont);
    }

    if (e.getSource() == bold) {
      isBold = !isBold;
      String name = (String) fontName.getSelectedItem();
      String size = (String) fontSize.getSelectedItem();
      Font newFont = new Font(name, Font.PLAIN
          + (bold.isSelected() ? Font.BOLD : 0)
          + (italic.isSelected() ? Font.ITALIC : 0), getInt(size, 12));
      arc.getTextComponent().setFont(newFont);
    }

    if (e.getSource() == isCircle)
      arc.setCircle(isCircle.isSelected());

    if (e.getSource() == orientationIsClockwise)
      arc.setClockwise(orientationIsClockwise.isSelected());

    if (Animation.get() != null)
      Animation.get().doChange();
    repaintNow();
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTArc arc = (PTArc) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      arc.setColor((Color) event.getNewValue());
    else if ("fillColor".equals(eventName))
      arc.setFillColor((Color) event.getNewValue());
    else if ("textColor".equals(eventName))
      arc.setTextColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTArc.TYPE_LABEL;
  }
} // ArcEditor
