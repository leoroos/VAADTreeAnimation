package animal.editor.graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import translator.AnimalTranslator;

import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.gui.AnimalMainWindow;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;

/**
 * Editor for GraphicObjects.
 * 
 * @see animal.graphics.PTGraphicObject
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public abstract class GraphicEditor extends Editor {

  /**
	 * 
	 */
	private static final long serialVersionUID = 633413558545294186L;

public GraphicEditor() {
    super(AnimalMainWindow.getWindowCoordinator().getDrawWindow(false));
    buildGUI();
  }

  protected abstract void buildGUI();

  /**
   * the number of points needed for the construction of a graphic object.
   * 
   * @return -1, if the object needs arbitrarily many points (e.g. a polyline)
   *         <p>
   *         Otherwise, the number of points needed.
   */
  public abstract int pointsNeeded();

  /**
   * insert/set a point of the graphic object. This method is called by <a
   * href=ObjectPanel.html>ObjectPanel</a>, when the mouse is dragged or moved.
   * <code>num</code> is increased every time the mousebutton is pressed.
   * 
   * @param num
   *          the number of the point to be set/changed, starting with -1.
   * @param p
   *          the coordinates of the point to be set/changed
   */
  public abstract boolean nextPoint(int num, Point p);

  /**
   * force a new paint, e.g. if parameters have changed
   */
  public void repaintNow() {
    AnimalMainWindow.getWindowCoordinator().getDrawWindow(true).getDrawCanvas()
        .repaintAll();
  }

  /**
   * returns the distance of the object to the point p, i.e. the length of a
   * shortest line linking the object with p
   */
  public abstract int getMinDist(PTGraphicObject go, Point p);

  /**
   * returns the Edit points of the given graphic object. The type of the given
   * graphic object must correspond to the type of the editor, which is(at least
   * should be :) ) the case, if this method is called by
   * <code>go.getEditor().getEditPoints(go)</code>, <em>go</em> being the
   * graphic object. Must be implemented by subclasses to return the specific
   * Editpoints of the graphic object implemented, i.e. a PolylineEditor must
   * return the Editpoints of a Polyline and can rely on the parameter passed
   * being a Polyline(but must not(!) use PTPolyline as a parameter, but cast
   * the given EditableObject to a PTPolyline).
   */
  public abstract EditPoint[] getEditPoints(PTGraphicObject go);

  /**
   * returns a new ColorChooser
   * @return the concrete ColorChooserAction
   */
  public ColorChooserAction createColorChooser(String translatedColorName, Color initialColor) {
    return createColorChooser("color", "GenericEditor.chooseColor",
        translatedColorName, initialColor);
  }
   /**
   * returns a new ColorChooser
   * @return the concrete ColorChooserAction
   */
  public ColorChooserAction createColorChooser(String colorName,
      String translatedColorName, Color initialColor) {
    return createColorChooser(colorName, "GenericEditor.chooseColor",
        translatedColorName, initialColor);
  }
  
  /**
   * returns a new ColorChooser
   * @return the concrete ColorChooserAction
   */
  public ColorChooserAction createColorChooser(String colorName, String promptMessage,
      String translatedColorName, Color initialColor) {
    ColorChooserAction colorChooserAction = new ColorChooserAction(this, 
        ColorChoice.getColorName(initialColor), colorName, 
        AnimalTranslator.translateMessage(promptMessage, 
              new Object[] { AnimalTranslator.translateMessage(translatedColorName) }),
              initialColor);
    return colorChooserAction;
  }

  public abstract String getBasicType();

  /**
   * paints this editor's GraphicObject.
   */
  public void paintObject(Graphics g) {
    ((PTGraphicObject) getCurrentObject()).paint(g);
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    if (eo instanceof PTGraphicObject) {
      PTGraphicObject go = (PTGraphicObject) eo;
      go.setDepth(Integer.valueOf((String) depthBox.getSelectedItem())
          .intValue());
      go.setObjectName(objectNameField.getText());
    }
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    if (eo instanceof PTGraphicObject) {
      PTGraphicObject p = (PTGraphicObject) eo;
      if (p.getDepth() > 16 && p.getDepth() != Integer.MAX_VALUE)
        depthBox.addItem(String.valueOf(p.getDepth()));
      depthBox.addItem(String.valueOf(Integer.MAX_VALUE));
      depthBox.setSelectedItem(String.valueOf(p.getDepth()));
      objectNameField.setText(p.getObjectName());
    }
  }

  /**
   * returns a message describing how to create a new object in the DrawCanvas.
   * This message is displayed in DrawWindow's statusline whenever this editor
   * is active.
   */
  public String getStatusLineMsg() {
    return null;
  }
}
