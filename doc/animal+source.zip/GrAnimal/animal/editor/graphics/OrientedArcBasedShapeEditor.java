/*
 * Created on 29.08.2007 by Guido Roessling (roessling@acm.org>
 */
package animal.editor.graphics;

import java.awt.Color;
import java.awt.event.KeyEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.graphics.PTSquare;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;

/**
 * abstract editor for oriented arc based shapes
 * 
 * @author Dr. Guido Roessling <roessling@acm.org>
 * @version 2.5 2008-06-23
 */
public abstract class OrientedArcBasedShapeEditor extends ArcBasedShapeEditor {
  /**
	 * 
	 */
	private static final long serialVersionUID = 6199592133277102205L;
protected JCheckBox clockwise;

  public Box createCommonOpenArcElements(TranslatableGUIElement generator) {
    Box colorBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "GenericEditor.colorBL");

    // first row: outline color
    Box firstRowBox = new Box(BoxLayout.LINE_AXIS);
    firstRowBox.add(generator.generateJLabel("GenericEditor.colorLabel")); // color
    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTSquare) getCurrentObject(false)).getColor();
    colorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "color", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor",
            new Object[] { AnimalTranslator
                .translateMessage("OpenObjectEditor.outline") }), initialColor);
    firstRowBox.add(new ExtendedActionButton(colorChooser, KeyEvent.VK_C));
    colorBox.add(firstRowBox);
    return colorBox;
  }

  public Box createCommonClosedArcElements(TranslatableGUIElement generator) {
    return createColorBox(generator);
  }
}
