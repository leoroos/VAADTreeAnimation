package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTLine;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Polyline
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class LineEditor extends GraphicEditor implements ItemListener,
    ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  private JCheckBox bwArrowCB;

  private ColorChooserAction colorChooser;

  private JCheckBox fwArrowCB;

  public LineEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    addBox(createColorBox(generator));
    // create entries for pol properties
    fwArrowCB = generator.generateJCheckBox("ArrowableShapeEditor.fwArrow", null, this);
    fwArrowCB.addItemListener(this);
    bwArrowCB = generator.generateJCheckBox("ArrowableShapeEditor.bwArrow", null, this);
    bwArrowCB.addItemListener(this);

    // create properties box
    Box polylinePropertiesBox = generator.generateBorderedBox(
        BoxLayout.LINE_AXIS, "LineEditor.propertiesBL");
    polylinePropertiesBox.add(fwArrowCB);
    polylinePropertiesBox.add(bwArrowCB);

    // add properties box
    addBox(polylinePropertiesBox);

    // finish the boxes
    finishBoxes();
  }

  public Box createColorBox(TranslatableGUIElement generator) {
    Box colorBox = generator.generateBorderedBox(BoxLayout.LINE_AXIS,
        "GenericEditor.colorBL");

    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTLine) getCurrentObject(false)).getColor();
    colorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "color", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor",
            new Object[] { AnimalTranslator
                .translateMessage("OpenObjectEditor.outline") }), initialColor);
    colorBox.add(new ExtendedActionButton(colorChooser, KeyEvent.VK_C));
    return colorBox;
  }

  public int pointsNeeded() {
    return 2;
  }

  public boolean nextPoint(int num, Point p) {
    PTLine line = (PTLine) getCurrentObject();
    if (num == 1)
      line.setFirstNode(p.x, p.y);
    else if (num == 2)
      line.setLastNode(p.x, p.y);
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTLine pg = (PTLine) go;
    Rectangle boundingBox = pg.getBoundingBox();
    if (boundingBox.contains(p.x, p.y))
      return 0;

    // (ULC, URC)
    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, pg.getFirstNode().toPoint(), pg.getLastNode().toPoint());
    if (newDist < minDist)
      minDist = newDist;

    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTLine pg = (PTLine) go;
    // add change points(nodes)
    EditPoint[] result = new EditPoint[3];
    Point startNode = pg.getFirstNode().toPoint();
    Point endNode = pg.getLastNode().toPoint();
    result[0] = new EditPoint(0, startNode);
    result[1] = new EditPoint(1, endNode);
    result[2] = new EditPoint(-1, new Point((startNode.x + endNode.x) / 2,
    		(startNode.y + endNode.y) / 2));
    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(PTLine.LINE_TYPE + ".color",
        Color.black));
    depthBox.setSelectedItem(props.getProperty(PTLine.LINE_TYPE + ".depth",
        "16"));
    bwArrowCB.setSelected(props.getBoolProperty(PTLine.LINE_TYPE
        + ".bwArrow"));
    fwArrowCB.setSelected(props.getBoolProperty(PTLine.LINE_TYPE
        + ".fwArrow"));
  }

  public void getProperties(XProperties props) {
    props.put(PTLine.LINE_TYPE + ".color", colorChooser.getColor());
    props.put(PTLine.LINE_TYPE + ".depth", depthBox.getSelectedItem());
    props.put(PTLine.LINE_TYPE + ".bwArrow", bwArrowCB.isSelected());
    props.put(PTLine.LINE_TYPE + ".fwArrow", fwArrowCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(
  ItemEvent e) {
  	PTLine p = (PTLine)getCurrentObject();
    if (e.getSource() == fwArrowCB) {
      if (p != null)
        p.setFWArrow(fwArrowCB.isSelected());
    }

    if (e.getSource() == bwArrowCB) {
      if (p != null)
        p.setBWArrow(bwArrowCB.isSelected());
    }
    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTLine pg = new PTLine();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTLine p = (PTLine) eo;
    p.setColor(colorChooser.getColor());
    p.setFWArrow(fwArrowCB.isSelected());
    p.setBWArrow(bwArrowCB.isSelected());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTLine p = (PTLine) eo;
    colorChooser.setColor(p.getColor());
    fwArrowCB.setSelected(p.hasFWArrow());
    bwArrowCB.setSelected(p.hasBWArrow());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    LineEditor result = new LineEditor();
    // important! result must be of type SquareEditor (or cast)
    // and the parameter passed must be of type PTLine.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("LineEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTLine p = (PTLine) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTLine poly = (PTLine) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTLine.LINE_TYPE;
  }
} // LineEditor
