package animal.editor.graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTText;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * The Editor for Text.
 * 
 * @see animal.graphics.PTText
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class TextEditor extends AbstractTextEditor // GraphicEditor
    implements PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -1180513717753983571L;

  private boolean isItalic, isBold;

  /**
   * The Editor's constructor. Writes the components into a Panel and adds this
   * Panel to the Editor, then adds the Buttons.
   */
  public TextEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();
    addBox(generateTextComponentBox(generator));
    finishBoxes(); // was: tp
  }

  /**
   * how many points do we need to specify a Text?
   * 
   * @see #nextPoint
   */
  public int pointsNeeded() {
    return 2;
  }

  /**
   * sets one of the Text's points. <br>
   * 1st and 2nd: set Location(by this, the Text is not displayed before the
   * mouse is clicked once)<br>
   */
  public boolean nextPoint(int num, Point p) {
    PTText t = (PTText) getCurrentObject();
    switch (num) {
    case 1:
    case 2:
      t.setLocation(p);
      break;
    }
    return true;
  } // nextPoint;

  /**
   * returns the minimal distance from point <i>p</i> to the Text. IMPORTANT:
   * use <code>PTGraphicObject</code> as first parameter and cast it to a
   * PTText inside the method. Otherwise this method won't be called.
   */
  public int getMinDist(PTGraphicObject go, Point p) {
    return MSMath.dist(p, go.getBoundingBox());
  }

  /**
   * returns the EditPoints of the Text. Again, the parameter has to be of type
   * <b>PTGraphicObject</b>. A Text only has one MovePoint(its upper left
   * corner) and one ChangePoint(its tip).
   */
  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTText t = (PTText) go;
    Rectangle r = t.getBoundingBox();
    return new EditPoint[] { // only move points
    new EditPoint(-1, t.getLocation()), // at the baseline
        new EditPoint(-2, new Point(r.x, r.y)), // upper left
        new EditPoint(-3, new Point(r.x + r.width, r.y)), // upper right
        new EditPoint(-4, new Point(r.x, r.y + r.height)), // lower left
        new EditPoint(-5, new Point(r.x + r.width, r.y + r.height)),
    // lower right
    };
  } // getEditPoints

  /**
   * extract the properties from <em>props</em>. All components are set
   * according to these properties.
   */
  public void setProperties(XProperties props) {
    if (textField != null)
      textField.setText(props.getProperty(PTText.TEXT_TYPE + ".text", ""));
    italic.setSelected(props.getBoolProperty(PTText.TEXT_TYPE + ".italic",
        false));
    bold.setSelected(props.getBoolProperty(PTText.TEXT_TYPE + ".bold", false));
    fontName.setSelectedItem(props.getProperty(PTText.TEXT_TYPE + ".fontName",
        "SansSerif"));
    fontSize.setSelectedItem(props.getProperty(PTText.TEXT_TYPE + ".fontSize",
        "12"));
    textColorChooser.setColor(props.getColorProperty(PTText.TEXT_TYPE + ".color",
        Color.black));
  }

  /**
   * writes the Editor's current permanent attributes to the Properties object.
   */
  public void getProperties(XProperties props) {
    props.put(PTText.TEXT_TYPE + ".color", textColorChooser.getColor());
    props.put(PTText.TEXT_TYPE + ".text", textField.getText());
    props.put(PTText.TEXT_TYPE + ".fontName", fontName.getSelectedItem());
    props.put(PTText.TEXT_TYPE + ".fontSize", fontSize.getSelectedItem());
    props.put(PTText.TEXT_TYPE + ".italic", italic.isSelected());
    props.put(PTText.TEXT_TYPE + ".bold", bold.isSelected());
  }

  /**
   * creates a new Text and uses the attributes of this Editor as default
   * values.
   */
  public EditableObject createObject() {
    PTText t = new PTText();
    storeAttributesInto(t);
    return t;
  }

  /**
   * applies the Editor's settings to the Text by setting all of Texts
   * attributes according to the components. Parameter must be of type
   * <b>EditableObject</b> and be casted inside the method.
   */
  protected void storeAttributesInto(EditableObject eo) {
    // don't forget to store the parent's attributes!
    super.storeAttributesInto(eo);
    PTText t = (PTText) eo; // just a shortcut
    t.setColor(textColorChooser.getColor());
    t.setText(textField.getText());
    t.setFont(storeFont());
  }

  /**
   * extracts the Font from the components' settings.
   */
  Font storeFont() {
    String name = (String) fontName.getSelectedItem();
    String size = (String) fontSize.getSelectedItem();
    return new Font(name, Font.PLAIN + (isBold ? Font.BOLD : 0)
        + (isItalic ? Font.ITALIC : 0), getInt(size, 12));
  }

  /**
   * sets the components according to the font.
   */
  void extractFont(Font f) {
    fontName.setSelectedItem(f.getName());
    fontSize.setSelectedItem(String.valueOf(f.getSize()));
    italic.setSelected(f.isItalic());
    bold.setSelected(f.isBold());
  }

  /**
   * makes the Editor reflect the Text's attributes by setting all components
   * according to the attributes. Parameter must be of type <b>EditableObject</b>,
   * otherwise there may be problems with calls to super that can be difficult
   * to debug.
   */
  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTText t = (PTText) eo;
    textColorChooser.setColor(t.getColor());
    textField.setText(t.getText());
    extractFont(t.getFont());
  }

  /**
   * creates a secondary Editor for the given <b>EditableObject</b> and copies
   * all of the object's attributes into the components. We can rely on this
   * object always being a <b>PTText</b>.
   */
  public Editor getSecondaryEditor(EditableObject go) {
    TextEditor result = new TextEditor();
    result.extractAttributesFrom(go);
    return result;
  }

  /**
   * returns a short description how to create a Text
   */
  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("TextEditor.statusLine", new Object[] {
        DrawCanvas.translateDrawButton(), DrawCanvas.translateFinishButton(),
        DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);

    PTText t = (PTText) getCurrentObject();

    isItalic = t.getFont().isItalic();
    isBold = t.getFont().isBold();

    if (e.getSource() == textField)
      t.setText(textField.getText());

    if (e.getSource() == fontName || e.getSource() == fontSize)
      t.setFont(storeFont());

    if (e.getSource() == italic) {
      isItalic = !isItalic;
      String name = (String) fontName.getSelectedItem();
      String size = (String) fontSize.getSelectedItem();
      Font newFont = new Font(name, Font.PLAIN
          + (bold.isSelected() ? Font.BOLD : 0)
          + (italic.isSelected() ? Font.ITALIC : 0), getInt(size, 12));
      t.setFont(newFont);
    }

    if (e.getSource() == bold) {
      isBold = !isBold;
      String name = (String) fontName.getSelectedItem();
      String size = (String) fontSize.getSelectedItem();
      Font newFont = new Font(name, Font.PLAIN
          + (bold.isSelected() ? Font.BOLD : 0)
          + (italic.isSelected() ? Font.ITALIC : 0), getInt(size, 12));
      t.setFont(newFont);
    }

    repaintNow();
    if (Animation.get() != null)
      Animation.get().doChange();
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTText t = (PTText) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("textColor".equals(eventName))
      t.setColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTText.TEXT_TYPE;
  }
} // TextEditor
