/*
 * The Editor for a PTDoubleArray.
 * @see animal.graphics.PTDoubleArray
 *
 * @author <a href="mailto:roessling@acm.org">Dr. Guido R&ouml;&szlig;ling</a>
 * @version 1.4
 * @date 2008-03-07
 */
package animal.editor.graphics;

import java.awt.event.KeyEvent;

import animal.graphics.PTDoubleArray;
import animal.misc.EditableObject;

/**
 * Editor for a double-based array
 * 
 * @author Dr. Guido Roessling <roessling@acm.org>
 * @version 2.5 2008-06-23
 */
public class DoubleArrayEditor extends AbstractArrayEditor {

  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = 2295451210277833754L;

  /**
   * Construct a new DoubleArrayEditor window
   */
  public DoubleArrayEditor() {
    super(PTDoubleArray.TYPE_LABEL);
  }

  /**
   * Constructor used by the secondary editor window. This one is (and must be)
   * different from the default constructor, because by definition the array
   * size is static, so the according tab is missing in this version of the
   * DoubleArrayEditor window.
   * 
   * @param i
   *          the size of the DoubleArray used to determine the correct indices of
   *          the array cells
   */
  protected DoubleArrayEditor(int i) {
    super(PTDoubleArray.TYPE_LABEL, i);
  }

  protected void buildGUI() {
    buildGUI(PTDoubleArray.TYPE_LABEL);
  }

  /**
   * Finally create a new DoubleArray by this editor.
   * 
   * @return the created <code>PTDoubleArray</code>
   */
  public EditableObject createObject() {
    PTDoubleArray result = new PTDoubleArray(getInt(arraySize.getText(), 1));
    storeAttributesInto(result);
    return result;
  }

  public void keyTyped(KeyEvent e) {
    PTDoubleArray array = (PTDoubleArray) getCurrentObject();
    if (e.getSource() == content) {
      // this is tricky!!! :-)
      // ---
      // the opposite of the condition is valid, so negate everything
      if (!
      // check if String isn't a negative number when entering '-' at first
      // position
      (((e.getKeyChar() == '-') && (content.getCaretPosition() == 0) && (getInt(
          content.getText(), 0) >= 0)) ||
      // check for decimal point - must be only one!
      (e.getKeyChar() == '.' && content.getText().indexOf('.') == -1) ||
      // check for digit pressed and...
      (Character.isDigit(e.getKeyChar()) &&
      // ... not at position 0 or String doesn't contain '-'
      ((content.getCaretPosition() > 0) || (getInt(content.getText(), 0) >= 0))))) {
        e.consume();
      }
      array.enterValue(calcIndex(), getInt(content.getText(), calcIndex()));
    }
    repaintNow();
  }

  public String getBasicType() {
    return PTDoubleArray.TYPE_LABEL;
  }

} // DoubleArrayEditor