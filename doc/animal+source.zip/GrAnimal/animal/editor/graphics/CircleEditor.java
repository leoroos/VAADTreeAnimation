package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTCircle;
import animal.graphics.PTGraphicObject;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Polyline
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class CircleEditor extends ArcBasedShapeEditor implements ItemListener,
    ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  public CircleEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    Box contentBox = createCommonElements(generator);

    // create type-specific stuff
    filledCB = generator.generateJCheckBox("GenericEditor.filled", null, this);
    filledCB.addItemListener(this);
    contentBox.add(filledCB);

    // finish the boxes
    finishBoxes();
  }

  public int pointsNeeded() {
    return 2;
  }

  public boolean nextPoint(int num, Point p) {
    PTCircle shape = (PTCircle) getCurrentObject();
    if (num == 1)
      shape.setCenter(p.x, p.y);
    if (num == 2)
      shape.setRadius(Math.abs(p.x - shape.getCenter().x));
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTCircle pg = (PTCircle) go;
    Point a = new Point(pg.getCenter().x, pg.getCenter().y);
    Rectangle boundingBox = pg.getBoundingBox();
    if (boundingBox.contains(p.x, p.y))
      return 0;

    // (ULC, URC)
    Point b = new Point(a.x + pg.getRadius(), a.y);
    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (URC, LRC)
    b.translate(0, pg.getRadius());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (LRC, LLC)
    a.translate(pg.getRadius(), pg.getRadius());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    newDist = MSMath.dist(p, a, pg.getCenter());
    if (newDist < minDist)
      minDist = newDist;
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTCircle pg = (PTCircle) go;
    int radius = pg.getRadius();
    // add change points(nodes)
    EditPoint[] result = new EditPoint[5];
    Point helper = pg.getCenter();
    // helper = new Point(helper.x + radius, helper.y + radius);
    // result[0] = new EditPoint(1, helper);

    int x = helper.x;
    int y = helper.y;
    int nr = 0;
    result[nr++] = new EditPoint(2, new Point(x + radius, y + radius));
    result[nr++] = new EditPoint(-1, new Point(x - radius, y));
    result[nr++] = new EditPoint(-2, new Point(x, y + radius));
    result[nr++] = new EditPoint(-3, new Point(x + radius, y));
    result[nr++] = new EditPoint(-4, new Point(x, y - radius));

    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(
        PTCircle.CIRCLE_TYPE + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(PTCircle.CIRCLE_TYPE + ".depth",
        "16"));
    // depthBox.setSelectedItem(props.getProperty(PTGraphicObject.DEPTH_LABEL,
    // String.valueOf(16)));
    fillColorChooser.setColor(props.getColorProperty(PTCircle.CIRCLE_TYPE
        + ".fillColor", Color.black));
    filledCB
        .setSelected(props.getBoolProperty(PTCircle.CIRCLE_TYPE + ".filled"));
  }

  public void getProperties(XProperties props) {
    props.put(PTCircle.CIRCLE_TYPE + ".color", colorChooser.getColor());
    props.put(PTCircle.CIRCLE_TYPE + ".depth", depthBox.getSelectedItem());
    // props.put(PTGraphicObject.DEPTH_LABEL, depthBox.getSelectedItem());
    props.put(PTCircle.CIRCLE_TYPE + ".fillColor", fillColorChooser.getColor());
    props.put(PTCircle.CIRCLE_TYPE + ".filled", filledCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTCircle p = (PTCircle) getCurrentObject();

    if (e.getSource() == filledCB) {
      if (p != null)
        p.setFilled(filledCB.isSelected());
    }

    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTCircle pg = new PTCircle();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTCircle p = (PTCircle) eo;
    p.setColor(colorChooser.getColor());
    p.setFilled(filledCB.isSelected());
    p.setFillColor(fillColorChooser.getColor());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTCircle p = (PTCircle) eo;
    colorChooser.setColor(p.getColor());
    filledCB.setEnabled(true);
    filledCB.setSelected(p.isFilled());
    fillColorChooser.setColor(p.getFillColor());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    CircleEditor result = new CircleEditor();
    // important! result must be of type CircleEditor (or cast)
    // and the parameter passed must be of type PTCircle.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("CircleEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTCircle p = (PTCircle) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTCircle poly = (PTCircle) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    else if ("fillColor".equals(eventName))
      poly.setFillColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTCircle.CIRCLE_TYPE;
  }
} // CircleEditor
