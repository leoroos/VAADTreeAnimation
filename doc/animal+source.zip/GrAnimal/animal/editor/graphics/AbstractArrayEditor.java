/*
 * The Editor for a AbstractArray.
 * @see animal.graphics.PTArray
 *
 * @author <a href="mailto:roessling@acm.org">Dr. Guido R&ouml;&szlig;ling</a>
 * @version 1.4
 * @date 2008-03-08
 */
package animal.editor.graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTArray;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTIntArray;
import animal.graphics.PTStringArray;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * abstract editor for arrays
 * 
 * @author Dr. Guido Roessling <roessling@acm.org>
 * @version 2.5 2008-06-23
 */
public abstract class AbstractArrayEditor extends AbstractTextEditor implements
    ChangeListener, ActionListener, PropertyChangeListener, KeyListener {

  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = 2295451210979833754L;
  protected String actualType;
  protected ColorChooserAction colorChooser,
      highlightColorChooser, elemHighlightColorChooser,
      fillColorChooser,
      fontColorChooser;

  protected JTextField arraySize, content;

  protected int nrArrayElems = 10;

  protected JSpinner arraySpinner;

  protected JCheckBox showIndicesCB;

  /**
   * This is used in secondaryEditor to prohibit entry and thus change of
   * arraySize as an array is commonly understood to be of static size, and
   * cannot be resized while being used
   */
  // GR
  protected boolean firstEdit = true;

  /**
   * Construct a new AbstractrrayEditor window
   */
  public AbstractArrayEditor(String arrayType) {
    super();
    actualType = arrayType;
  }

  protected void buildGUI(String arrayType) {
    actualType = arrayType;
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();
    // if (firstEdit) {
    // add array size selection box
    addBox(createArraySizeBox(generator));
    // } else {
    if (nrArrayElems == 0)
      nrArrayElems = 10;
    addBox(createArrayValueBox(generator, nrArrayElems));
    addBox(createIndicesOptionsBox(generator));
    // }
    // add a box for the colors
    addBox(createColorBox(generator, arrayType));

    // add a box for the font choice
    addBox(generateFontAndStyleBox(generator, "AbstractTextEditor.fontBL"));

    finishBoxes(); // was: tp
  }

  /**
   * Constructor used by the secondary editor window. This one is (and must be)
   * different from the default constructor, because by definition the array
   * size is static, so the according tab is missing in this version of the
   * IntArrayEditor window.
   * 
   * @param i
   *          the size of the IntArray used to determine the correct indices of
   *          the array cells
   */
  protected AbstractArrayEditor(String type, int i) {
    this(type);
    arraySize.setText(String.valueOf(i));
  }

  protected Box createArrayValueBox(TranslatableGUIElement generator,
      int targetSize) {
    Box spinnerBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "AbstractArrayEditor.arrayValuesBL");

    Box elementChoiceBox = new Box(BoxLayout.LINE_AXIS);
    // add label for values
    elementChoiceBox.add(generator.generateJLabel("AbstractArrayEditor.arrayCell"));
    SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0, 0,
        targetSize - 1, 1);
    arraySpinner = new JSpinner(spinnerModel);
    elementChoiceBox.add(arraySpinner);
    arraySpinner.addChangeListener(this);
    elementChoiceBox.add(new JLabel(" / " + String.valueOf(targetSize)));
    spinnerBox.add(elementChoiceBox);

    Box valueBox = new Box(BoxLayout.LINE_AXIS);
    valueBox.add(generator.generateJLabel("AbstractArrayEditor.cellContent"));
    int spinnerValue = spinnerModel.getNumber().intValue();
    String text = (getCurrentObject(false) == null) ? "" : 
      ((PTArray)getCurrentObject(false)).getStringValueAt(spinnerValue);
    content = new JTextField(15);
    content.setText(text);
    content.addKeyListener(this);
    valueBox.add(content);

    spinnerBox.add(valueBox);
    return spinnerBox;
  }

  protected Box createColorBox(TranslatableGUIElement generator, String type) {
    // create color box
    Box colorBox = generator.generateBorderedBox(BoxLayout.LINE_AXIS,
        "GenericEditor.colorBL");
    Box firstColumnBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "AbstractArrayEditor.basicColors");

    // first row: int[] color
    firstColumnBox.add(generator.generateJLabel("GenericEditor.colorLabel")); // color
    Color initialColor = (getCurrentObject(false) == null) ? Color.white
        : ((PTArray) getCurrentObject(false)).getOutlineColor();
    colorChooser = createColorChooser("color", type+"Editor.arrayType", initialColor);
    firstColumnBox.add(new ExtendedActionButton(colorChooser, KeyEvent.VK_C));

    // third row: int[] highlight color
    firstColumnBox.add(generator.generateJLabel("AbstractArrayEditor.fontColorLabel"));
    Color fontInitialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTArray) getCurrentObject(false)).getFontColor();
    fontColorChooser = createColorChooser("fontColor", type +"Editor.arrayType", fontInitialColor);
    firstColumnBox
        .add(new ExtendedActionButton(fontColorChooser, KeyEvent.VK_F));

    firstColumnBox.add(generator.generateJLabel("GenericEditor.fillColorLabel"));
    Color initialFillColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTArray) getCurrentObject(false)).getOutlineColor();
    fillColorChooser = createColorChooser("fillColor", type+"Editor.arrayType", initialFillColor);
    firstColumnBox.add(new ExtendedActionButton(fillColorChooser,
        KeyEvent.VK_O));

    colorBox.add(firstColumnBox);

    Box secondColumnBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "AbstractArrayEditor.highlightColors");

    secondColumnBox.add(generator.generateJLabel("AbstractIndexedStructureEditor.hlColorLabel")); // background
                                                                    // color

    Color highlightInitialColor = (getCurrentObject(false) == null) ? Color.yellow
        : ((PTArray) getCurrentObject(false)).getHighlightColor();
    highlightColorChooser = createColorChooser("highlightColor", 
        type+"Editor.arrayType", highlightInitialColor);
    secondColumnBox.add(new ExtendedActionButton(highlightColorChooser,
        KeyEvent.VK_H));

    secondColumnBox.add(generator.generateJLabel("AbstractIndexedStructureEditor.elemHighlightColorLabel"));
    Color elemHighlightInitialColor = (getCurrentObject(false) == null) ? Color.red
        : ((PTArray) getCurrentObject(false)).getElemHighlightColor();
    elemHighlightColorChooser = createColorChooser("elemHighlightColor", type+"Editor.arrayType", 
        elemHighlightInitialColor);
    secondColumnBox.add(new ExtendedActionButton(elemHighlightColorChooser,
        KeyEvent.VK_E));

    colorBox.add(firstColumnBox);
    colorBox.add(secondColumnBox);
    // finally, return the color box!
    return colorBox;
  }

  protected void ensureTypeSet() {
    if (actualType == null) {
      Object o = getCurrentObject(false);
      if (o instanceof PTIntArray)
        actualType = PTIntArray.TYPE_LABEL;
      else if (o instanceof PTStringArray)
        actualType = PTStringArray.TYPE_LABEL;
    }
  }
  
  /**
   * Set the current properties in the editor window as defined in the
   * XProperties.
   * 
   * @param props
   *          the used properties file
   */
  public void setProperties(XProperties props) {
    ensureTypeSet();
    colorChooser.setColor(props.getColorProperty(actualType
        + ".outlineColor", Color.WHITE));
    highlightColorChooser.setColor(props.getColorProperty(actualType
        + ".highlightColor", Color.YELLOW));
    elemHighlightColorChooser.setColor(props.getColorProperty(
        actualType + ".elemHighlightColor", Color.RED));
    fillColorChooser.setColor(props.getColorProperty(actualType
        + ".bgColor", Color.BLACK));
    fontColorChooser.setColor(props.getColorProperty(actualType
        + ".fontColor", Color.BLACK));
    arraySize.setText(String.valueOf(props.getIntProperty(actualType
        + ".arraySize", 1)));
    fontName.setSelectedItem(props.getProperty(actualType
        + ".fontName", "Monospaced"));
    fontSize.setSelectedItem(props.getProperty(actualType
        + ".fontSize", "14"));
    showIndicesCB.setSelected(props.getBoolProperty(actualType
        + ".showIndices", true));
  }

  protected Box createArraySizeBox(TranslatableGUIElement generator) {
    Box sizeBox = generator.generateBorderedBox(BoxLayout.PAGE_AXIS,
        "arraySizeBL");
    Box internalBox = new Box(BoxLayout.LINE_AXIS);
    internalBox.add(generator.generateJLabel("AbstractArrayEditor.arraySize"));
    arraySize = new JTextField(8);
    arraySize.addActionListener(this);
    internalBox.add(arraySize);
    sizeBox.add(internalBox);

    sizeBox.add(createIndicesOptionsBox(generator));

    return sizeBox;
  }

  protected Box createIndicesOptionsBox(TranslatableGUIElement generator) {
    Box optionsBox = new Box(BoxLayout.LINE_AXIS);
    showIndicesCB = generator.generateJCheckBox("AbstractIndexedStructureEditor.showIndices",
        null, this);
    optionsBox.add(showIndicesCB);
    return optionsBox;
  }

  /**
   * Store the current properties to the XProperties.
   * 
   * @param props
   *          the used properties file
   */
  public void getProperties(XProperties props) {
    ensureTypeSet();
    props.put(actualType + ".outlineColor", colorChooser.getColor());
    props.put(actualType + ".highlightColor", highlightColorChooser
        .getColor());
    props.put(actualType + ".elemHighlightColor",
        elemHighlightColorChooser.getColor());
    props.put(actualType + ".bgColor", fillColorChooser
        .getColor());
    props
        .put(actualType + ".fontColor", fontColorChooser.getColor());
    props.put(actualType + ".arraySize", getInt(arraySize.getText(),
        1));
    props.put(actualType + ".fontName", fontName.getSelectedItem());
    props.put(actualType + ".fontSize", fontSize.getSelectedItem());
    props.put(actualType + ".font", new Font((String) fontName
        .getSelectedItem(), Font.PLAIN, getInt((String) fontSize
        .getSelectedItem(), 14)));
    props.put(actualType + ".showIndices", showIndicesCB
        .isSelected());
  }

  /**
   * How many points are needed to create a new instance of the IntArray.
   * 
   * @return the number of the creation points (= 2).
   */
  public int pointsNeeded() {
    return 2;
  }

  /**
   * Executes the necessary actions when a new <code>PTStringArray</code> is
   * created. This depends on the number of mouse clicks that have to be
   * executed to create a new array.
   * 
   * @param num
   *          the number of the current point
   * @param p
   *          the current Point of the cursor
   * @return always true
   */
  public boolean nextPoint(int num, Point p) {
    switch (num) {
    case 1:
    case 2:
      ((PTArray) getCurrentObject()).setOrigin(p);
      break;
    }
    return true;
  }

  /**
   * Determines the minimum distance from a point to the IntArray.
   * 
   * @param go
   *          an object to which the distance is to be calculated
   * @param p
   *          the point of which the distance shall be determined
   */
  public int getMinDist(PTGraphicObject go, Point p) {
    return MSMath.dist(p, go.getBoundingBox());
  }

  /**
   * Returns the EditPoints of the Array. An array has only MovePoints because
   * the size is calculated automatically. DragPoints have negative indices,
   * while EditPoints are positive.
   * 
   * @param go
   *          the graphic object of which to return the edit points
   * @return an array of the edit point for this PTIntArray.
   */
  public EditPoint[] getEditPoints(PTGraphicObject go) {
    Rectangle bBox = ((PTArray) go).getBoundingBox();
    return new EditPoint[] {
        new EditPoint(-1, new Point(bBox.x, bBox.y)),
        new EditPoint(-2, new Point(bBox.x + bBox.width, bBox.y)),
        new EditPoint(-3, new Point(bBox.x, bBox.y + bBox.height)),
        new EditPoint(-4, new Point(bBox.x + bBox.width, bBox.y + bBox.height)),
        new EditPoint(-5, new Point(bBox.x + bBox.width / 2, bBox.y
            + bBox.height / 2)) };
  }

  /**
   * Set the values of the current IntArray to the ones chosen in the editor.
   * 
   * @param eo
   *          the current IntArray
   */
  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTArray array = (PTArray) eo;
    array.setOutlineColor(colorChooser.getColor());
    array.setHighlightColor(highlightColorChooser.getColor());
    array.setElemHighlightColor(elemHighlightColorChooser.getColor());
    array.setBGColor(fillColorChooser.getColor());
    array.setFontColor(fontColorChooser.getColor());
    if (arraySize != null)
      array.setSize(getInt(arraySize.getText(), 1));
    array.enterStringValueAt(calcIndex(), content.getText());
    // Font setzen
    array.setFont(storeFont());
    array.showIndices(showIndicesCB.isSelected());
  }

  /**
   * extracts the Font from the components' settings.
   */
  Font storeFont() {
    String name = (String) fontName.getSelectedItem();
    String size = (String) fontSize.getSelectedItem();
    int fontStyle = Font.PLAIN;
    if (italic.isSelected())
      fontStyle |= Font.ITALIC;
    if (bold.isSelected())
      fontStyle |= Font.BOLD;

    return new Font(name, fontStyle, getInt(size, 12));
  }

  /**
   * sets the components according to the font.
   */
  void extractFont(Font f) {
    fontName.setSelectedItem(f.getName());
    fontSize.setSelectedItem(String.valueOf(f.getSize()));
    italic.setSelected(f.isItalic());
    bold.setSelected(f.isBold());
  }
  
  /**
   * The alternative editor after a StringArray has already been created.
   * 
   * @param e
   *          the StringArray that should be edited.
   * 
   * See <code>StringArrayEditor(int i)</code> for details.
   */
  public Editor getSecondaryEditor(EditableObject e) {
    AbstractArrayEditor result = null;
    if (getCurrentObject(false) instanceof PTStringArray)
      result = new StringArrayEditor(((PTArray) e).getSize());
    else if (getCurrentObject(false) instanceof PTIntArray)
      result = new IntArrayEditor(((PTArray) e).getSize());
    // don't display tab asking for number of stringArray elements
    result.firstEdit = false;
    nrArrayElems = ((PTArray) e).getSize();
    result.extractAttributesFrom(e);
    return result;
  }


  /**
   * Determines the currently chosen array cell; returns -1 if IntArray is not
   * yet created.
   */
  protected int calcIndex() {
    return (arraySpinner == null) ? -1 : ((SpinnerNumberModel) arraySpinner
        .getModel()).getNumber().intValue();
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTArray array = (PTArray) eo;
    colorChooser.setColor(array.getOutlineColor());
    highlightColorChooser.setColor(array.getHighlightColor());
    elemHighlightColorChooser.setColor(array.getElemHighlightColor());
    fillColorChooser.setColor(array.getBGColor());
    fontColorChooser.setColor(array.getFontColor());
    if (arraySize != null)
      arraySize.setText(String.valueOf(array.getSize()));
    content.setText(array.getStringValueAt(calcIndex()));
    extractFont(array.getFont());
    showIndicesCB.setSelected(array.indicesShown());
  }

  /**
   * Load the text that is displayed in the status line of the ANIMAL drawing
   * window
   * 
   * @return the text of the status line
   */
  public String getStatusLineMsg() {
    return translator.AnimalTranslator.translateMessage(actualType +"Editor.statusLine", new Object[] {
            DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);

    PTArray array = (PTArray) getCurrentObject();

    // change entry in the array cell, that corresponds to the chosen
    // value of the arraySpinner, if the text in content-field is changed
    if (e.getSource() == content) {
      array.enterStringValueAt(calcIndex(), content.getText());
    }
    if (e.getSource() == arraySize) {
      array.setSize(getInt(arraySize.getText(), 1));
    }
    if (e.getSource() == fontName || e.getSource() == fontSize) {
      array.setFont(storeFont());
    }
    if (e.getSource() == showIndicesCB) {
      array.showIndices(showIndicesCB.isSelected());
    }
    repaintNow();
    Animation.get().doChange();
  }

  public void keyPressed(
  KeyEvent e) {
    // do nothing; only used for serialization
  }

  public void keyReleased(KeyEvent e) {
    PTArray array = (PTArray) getCurrentObject();
    if (e.getSource() == content) {
      array.enterStringValueAt(calcIndex(), content.getText());
    }
    repaintNow();
    Animation.get().doChange();
  }

  public abstract void keyTyped(KeyEvent e) ;

  /**
   * Listener that executes if another cell is chosen in the editor. This is
   * <em> not </em> an ActionListener but a ChangeEventListener.
   * 
   * @param e
   *          the event to react upon
   */
  public void stateChanged(ChangeEvent e) {
    // super.stateChanged (e);
    PTArray array = (PTArray) getCurrentObject();
    if (e.getSource() == arraySpinner) {
      content.setText(array.getStringValueAt(calcIndex()));
    }
    repaintNow();
    Animation.get().doChange();
  }

  /**
   * Set the objects properties according to those in the editor if these have
   * changed.
   * 
   * @param event
   *          the event to react upon
   */
  public void propertyChange(PropertyChangeEvent event) {
    PTArray array = (PTArray) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      array.setOutlineColor((Color) event.getNewValue());
    if ("highlightColor".equals(eventName)) {
      array.setHighlightColor((Color) event.getNewValue());
      array.getCell(0).setFillColor((Color) event.getNewValue());
    }
    if ("elemHighlightColor".equals(eventName)) {
      array.setElemHighlightColor((Color) event.getNewValue());
      array.getEntry(0).setColor((Color) event.getNewValue());
    }
    if ("fillColor".equals(eventName))
      array.setBGColor((Color) event.getNewValue());
    if ("fontColor".equals(eventName))
      array.setFontColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      Animation.get().doChange();
    }
  }
}