package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTPoint;
import animal.graphics.PTPolyline;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Polyline
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.0 2001-03-16
 */
public class PolylineEditor extends GraphicEditor implements ItemListener,
    ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  private JCheckBox fwArrowCB;

  private JCheckBox bwArrowCB;

  private ColorChooserAction colorChooser;

  public PolylineEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    Box colorBox = generator
        .generateBorderedBox(BoxLayout.PAGE_AXIS, "GenericEditor.colorBL");

    // first row: polyline / polygon color
    Box firstRowBox = new Box(BoxLayout.LINE_AXIS);
    firstRowBox.add(generator.generateJLabel("GenericEditor.colorLabel")); // color
    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTPolyline) getCurrentObject(false)).getColor();
    colorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "color", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor", new Object[] { AnimalTranslator
            .translateMessage("OpenObjectEditor.outline") }), initialColor);
    firstRowBox.add(new ExtendedActionButton(colorChooser, KeyEvent.VK_C));
    colorBox.add(firstRowBox);

    addBox(colorBox);

    // create entries for pol properties
    fwArrowCB = generator.generateJCheckBox("ArrowableShapeEditor.fwArrow", null, this);
    fwArrowCB.addItemListener(this);
    bwArrowCB = generator.generateJCheckBox("ArrowableShapeEditor.bwArrow", null, this);
    bwArrowCB.addItemListener(this);

    // create properties box
    Box polylinePropertiesBox = generator.generateBorderedBox(
        BoxLayout.LINE_AXIS, "PolylineEditor.propertiesBL");
    polylinePropertiesBox.add(fwArrowCB);
    polylinePropertiesBox.add(bwArrowCB);

    // add properties box
    addBox(polylinePropertiesBox);

    // finish the boxes
    finishBoxes();
  }

  public int pointsNeeded() {
    return -1;
  }

  public boolean nextPoint(int num, Point p) {
    PTPolyline pl = (PTPolyline) getCurrentObject();
    pl.setNode(num - 1, new PTPoint(p));
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTPolyline pg = (PTPolyline) go;
    // if the polyline is a filled polygon and the point is inside
    // there is not much of distance
    Point a;
    Point b = pg.getNodeAsPoint(0);
    int minDist = Integer.MAX_VALUE;
    int newDist;
    // iterate all edges of the polyline
    for (int i = 1; i < pg.getNodeCount(); i++) {
      a = b;
      b = pg.getNodeAsPoint(i);
      if (!a.equals(b) && (newDist = MSMath.dist(p, a, b)) < minDist)
        minDist = newDist;
    }
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTPolyline pg = (PTPolyline) go;
    int pSize = pg.getNodeCount();
    int size = pSize * 2 - 1;
    int i;
    // add change points(nodes)
    EditPoint[] result = new EditPoint[size];
    for (i = 0; i < pSize; i++)
      result[i] = new EditPoint(i + 1, pg.getNodeAsPoint(i));
    // add move points(points halfway the edges
    Point a;
    Point b;
    b = pg.getNodeAsPoint(0);
    for (i = 1; i < pSize; i++) {
      a = b;
      b = pg.getNodeAsPoint(i);
      result[i + pSize - 1] = new EditPoint(-i, new Point((a.x + b.x) / 2,
          (a.y + b.y) / 2));
    }
    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    bwArrowCB.setSelected(props.getBoolProperty(PTPolyline.POLYLINE_TYPE
        + ".bwArrow"));
    colorChooser.setColor(props.getColorProperty(PTPolyline.POLYLINE_TYPE
        + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(
        PTPolyline.POLYLINE_TYPE + ".depth", "16"));
    // depthBox.setSelectedItem(props.getProperty(PTGraphicObject.DEPTH_LABEL,
    // String.valueOf(16)));
    fwArrowCB.setSelected(props.getBoolProperty(PTPolyline.POLYLINE_TYPE
        + ".fwArrow"));
  }

  public void getProperties(XProperties props) {
    props.put(PTPolyline.POLYLINE_TYPE + ".bwArrow", bwArrowCB.isSelected());
    props.put(PTPolyline.POLYLINE_TYPE + ".color", colorChooser.getColor());
    props.put(PTPolyline.POLYLINE_TYPE + ".depth", depthBox.getSelectedItem());
    // props.put(PTGraphicObject.DEPTH_LABEL, depthBox.getSelectedItem());
    props.put(PTPolyline.POLYLINE_TYPE + ".fwArrow", fwArrowCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTPolyline p = (PTPolyline) getCurrentObject();

    if (e.getSource() == fwArrowCB) {
      if (p != null)
        p.setFWArrow(fwArrowCB.isSelected());
    }

    if (e.getSource() == bwArrowCB) {
      if (p != null)
        p.setBWArrow(bwArrowCB.isSelected());
    }
    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTPolyline pg = new PTPolyline();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTPolyline p = (PTPolyline) eo;
    p.setColor(colorChooser.getColor());
    p.setFWArrow(fwArrowCB.isSelected());
    p.setBWArrow(bwArrowCB.isSelected());
    p.setObjectName(objectNameField.getText());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTPolyline p = (PTPolyline) eo;
    colorChooser.setColor(p.getColor());
    fwArrowCB.setSelected(p.hasFWArrow());
    bwArrowCB.setSelected(p.hasBWArrow());
    objectNameField.setText(p.getObjectName());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    PolylineEditor result = new PolylineEditor();
    // important! result must be of type PolylineEditor(or casted)
    // and the parameter passed must be of type PTPolyline.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("PolylineEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTPolyline p = (PTPolyline) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTPolyline poly = (PTPolyline) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTPolyline.POLYLINE_TYPE;
  }
} // PolylineEditor
