package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;

import translator.AnimalTranslator;
import translator.ExtendedActionButton;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTPoint;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.ColorChoice;
import animal.misc.ColorChooserAction;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * The Editor for a PTPoint.
 * 
 * @see animal.graphics.PTPoint
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class PointEditor extends GraphicEditor implements
    PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = 2295451210977833754L;

  private ColorChooserAction colorChooser;

  public PointEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();
    Box colorBox = generator
        .generateBorderedBox(BoxLayout.LINE_AXIS, "GenericEditor.colorBL");

    // add color setting at (1, 1)
    JLabel colorLabel = AnimalTranslator.getGUIBuilder().generateJLabel(
        "GenericEditor.colorLabel");
    colorBox.add(colorLabel);

    Color initialColor = (getCurrentObject(false) == null) ? Color.black
        : ((PTPoint) getCurrentObject(false)).getColor();
    colorChooser = new ColorChooserAction(this, ColorChoice
        .getColorName(initialColor), "color", AnimalTranslator
        .translateMessage("GenericEditor.chooseColor", new Object[] { "Point" }),
        initialColor);
    ExtendedActionButton button = new ExtendedActionButton(colorChooser,
        KeyEvent.VK_C);
    colorBox.add(button);

    addBox(colorBox);

    finishBoxes();
  }

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty("Point.color",
    // PTPoint.POINT_COLOR,
        Color.black));
  }

  public void getProperties(XProperties props) {
    props.put("Point.color",
        colorChooser.getColor());
  }

  public int pointsNeeded() {
    return 1;
  }

  public boolean nextPoint(int num, Point p) {
    if (num == 1)
      ((PTPoint) getCurrentObject()).set(p);
    return true;
  }

  public int getMinDist(PTGraphicObject go, Point p) {
    return MSMath.dist(((PTPoint) go).toPoint(), p);
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    return new EditPoint[] { new EditPoint(-1, ((PTPoint) go).toPoint()) };
  }

  public EditableObject createObject() {
    PTPoint result = new PTPoint();
    storeAttributesInto(result);
    return result;
  }

  public Editor getSecondaryEditor(EditableObject e) {
    PointEditor result = new PointEditor();
    result.extractAttributesFrom(e);
    return result;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTPoint point = (PTPoint) eo;
    point.setColor(colorChooser.getColor());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTPoint point = (PTPoint) eo;
    colorChooser.setColor(point.getColor());
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("PointEditor.statusLine", new Object[] {
        DrawCanvas.translateDrawButton(), DrawCanvas.translateFinishButton(),
        DrawCanvas.translateCancelButton() });
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTPoint point = (PTPoint) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      point.setColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTPoint.POINT_TYPE;
  }
} // PointEditor
