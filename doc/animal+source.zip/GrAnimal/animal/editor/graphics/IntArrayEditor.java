/*
 * The Editor for a PTIntArray.
 * @see animal.graphics.PTIntArray
 *
 * @author <a href="mschmitt@rbg.informatik.tu-darmstadt.de"> Michael Schmitt </a>,
 * <a href="mailto:roessling@acm.org">Dr. Guido R&ouml;&szlig;ling</a>
 * @version 1.4
 * @date 2006-06-16
 */
package animal.editor.graphics;

import java.awt.event.KeyEvent;

import animal.graphics.PTIntArray;
import animal.misc.EditableObject;

/**
 * Editor for int-based arrays
 * 
 * @author Dr. Guido Roessling <roessling@acm.org>
 * @version 2.5 2008-06-23
 */
public class IntArrayEditor extends AbstractArrayEditor {

  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = 2295451210277833754L;

  /**
   * Construct a new IntArrayEditor window
   */
  public IntArrayEditor() {
    super(PTIntArray.TYPE_LABEL);
  }

  /**
   * Constructor used by the secondary editor window. This one is (and must be)
   * different from the default constructor, because by definition the array
   * size is static, so the according tab is missing in this version of the
   * IntArrayEditor window.
   * 
   * @param i
   *          the size of the IntArray used to determine the correct indices of
   *          the array cells
   */
  protected IntArrayEditor(int i) {
    super(PTIntArray.TYPE_LABEL, i);
  }

  protected void buildGUI() {
    buildGUI(PTIntArray.TYPE_LABEL);
  }

  /**
   * Finally create a new IntArray by this editor.
   * 
   * @return the created <code>PTIntArray</code>
   */
  public EditableObject createObject() {
    PTIntArray result = new PTIntArray(getInt(arraySize.getText(), 1));
    storeAttributesInto(result);
    return result;
  }

  public void keyTyped(KeyEvent e) {
    PTIntArray intArray = (PTIntArray) getCurrentObject();
    if (e.getSource() == content) {
      // this is tricky!!! :-)
      // ---
      // the opposite of the condition is valid, so negate everything
      if (!
      // check if String isn't a negative number when entering '-' at first
      // position
      (((e.getKeyChar() == '-') && (content.getCaretPosition() == 0) && (getInt(
          content.getText(), 0) >= 0)) ||
      // check for digit pressed and...
      (java.lang.Character.isDigit(e.getKeyChar()) &&
      // ... not at position 0 or String doesn't contain '-'
      ((content.getCaretPosition() > 0) || (getInt(content.getText(), 0) >= 0))))) {
        e.consume();
      }
      intArray.enterValue(calcIndex(), getInt(content.getText(), calcIndex()));
    }
    repaintNow();
  }

  public String getBasicType() {
    return PTIntArray.TYPE_LABEL;
  }

} // IntArrayEditor