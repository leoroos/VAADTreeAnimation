package animal.editor.graphics;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTTriangle;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Triangle
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class TriangleEditor extends PolygonalShapeEditor implements
    ItemListener, ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  public TriangleEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    Box contentBox = createCommonElements(generator);

    // create type-specific stuff
    filledCB = generator.generateJCheckBox("GenericEditor.filled", null, this);
    filledCB.addItemListener(this);
    contentBox.add(filledCB);

    // finish the boxes
    finishBoxes();
  }

  public int pointsNeeded() {
    return 3;
  }

  public boolean nextPoint(int num, Point p) {
    PTTriangle triangle = (PTTriangle) getCurrentObject();
    switch (num) {
    case 1:
      triangle.setFirstNode(p.x, p.y);
      if (triangle.getSecondNode().x == triangle.getThirdNode().x
          && triangle.getSecondNode().y == triangle.getThirdNode().y) {
        triangle.setSecondNode(p.x + 5, p.y);
        triangle.setThirdNode(p.x + 5, p.y + 5);
      }
      break;
    case 2:
      triangle.setSecondNode(p.x, p.y);
      break;
    case 3:
      triangle.setThirdNode(p.x, p.y);
      break;
    }
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTTriangle pg = (PTTriangle) go;
    Rectangle boundingBox = pg.getBoundingBox();
    // if point is inside, there is not much of distance ;-)
    if (boundingBox.contains(p.x, p.y))
      return 0;

    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, pg.getFirstNode(), pg.getSecondNode());
    if (newDist < minDist)
      minDist = newDist;
    newDist = MSMath.dist(p, pg.getSecondNode(), pg.getThirdNode());
    if (newDist < minDist)
      minDist = newDist;
    newDist = MSMath.dist(p, pg.getThirdNode(), pg.getFirstNode());
    if (newDist < minDist)
      minDist = newDist;
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTTriangle pg = (PTTriangle) go;
    // add change points(nodes)
    EditPoint[] result = new EditPoint[6];
    result[0] = new EditPoint(1, pg.getFirstNode());
    result[1] = new EditPoint(2, pg.getSecondNode());
    result[2] = new EditPoint(3, pg.getThirdNode());
    Point start = pg.getFirstNode();
    Point end = pg.getSecondNode();
    result[3] = new EditPoint(-1, new Point((start.x + end.x) / 2,
        (start.y + end.y) / 2));
    start = end;
    end = pg.getThirdNode();
    result[4] = new EditPoint(-1, new Point((start.x + end.x) / 2,
        (start.y + end.y) / 2));
    start = end;
    end = pg.getFirstNode();
    result[5] = new EditPoint(-1, new Point((start.x + end.x) / 2,
        (start.y + end.y) / 2));

    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(PTTriangle.TRIANGLE_TYPE
        + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(
        PTTriangle.TRIANGLE_TYPE + ".depth", "16"));
    fillColorChooser.setColor(props.getColorProperty(PTTriangle.TRIANGLE_TYPE
        + ".fillColor", Color.black));
    filledCB.setSelected(props.getBoolProperty(PTTriangle.TRIANGLE_TYPE
        + ".filled"));
  }

  public void getProperties(XProperties props) {
    props.put(PTTriangle.TRIANGLE_TYPE + ".color", colorChooser.getColor());
    props.put(PTTriangle.TRIANGLE_TYPE + ".depth", depthBox.getSelectedItem());
    props
        .put(PTTriangle.TRIANGLE_TYPE + ".fillColor", fillColorChooser.getColor());
    props.put(PTTriangle.TRIANGLE_TYPE + ".filled", filledCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTTriangle p = (PTTriangle) getCurrentObject();

    if (e.getSource() == filledCB) {
      if (p != null)
        p.setFilled(filledCB.isSelected());
    }

    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTTriangle pg = new PTTriangle();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTTriangle p = (PTTriangle) eo;
    p.setColor(colorChooser.getColor());
    p.setFilled(filledCB.isSelected());
    p.setFillColor(fillColorChooser.getColor());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTTriangle p = (PTTriangle) eo;
    colorChooser.setColor(p.getColor());
    filledCB.setEnabled(true);
    filledCB.setSelected(p.isFilled());
    fillColorChooser.setColor(p.getFillColor());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    TriangleEditor result = new TriangleEditor();
    // important! result must be of type RectangleEditor (or cast)
    // and the parameter passed must be of type PTTriangle.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("TriangleEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTTriangle p = (PTTriangle) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTTriangle poly = (PTTriangle) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    else if ("fillColor".equals(eventName))
      poly.setFillColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTTriangle.TRIANGLE_TYPE;
  }
} // TriangleEditor
