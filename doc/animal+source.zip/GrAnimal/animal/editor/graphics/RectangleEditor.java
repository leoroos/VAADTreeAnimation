package animal.editor.graphics;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;

import translator.AnimalTranslator;
import translator.TranslatableGUIElement;
import animal.editor.Editor;
import animal.graphics.PTGraphicObject;
import animal.graphics.PTRectangle;
import animal.gui.DrawCanvas;
import animal.main.Animation;
import animal.misc.EditPoint;
import animal.misc.EditableObject;
import animal.misc.MSMath;
import animal.misc.XProperties;

/**
 * Editor for a Polyline
 * 
 * @author <a href="http://www.algoanim.info/Animal2/">Guido R&ouml;&szlig;ling</a>
 * @version 2.5 2008-06-23
 */
public class RectangleEditor extends PolygonalShapeEditor implements
    ItemListener, ActionListener, PropertyChangeListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -2413776784253970663L;

  public RectangleEditor() {
    super();
  }

  protected void buildGUI() {
    TranslatableGUIElement generator = AnimalTranslator.getGUIBuilder();

    // create shared entries (color, fill color)
    Box contentBox = createCommonElements(generator);

    // create type-specific stuff
    filledCB = generator.generateJCheckBox("GenericEditor.filled", null, this);
    filledCB.addItemListener(this);
    contentBox.add(filledCB);

    // finish the boxes
    finishBoxes();
  }

  public int pointsNeeded() {
    return 2;
  }

  public boolean nextPoint(int num, Point p) {
    PTRectangle rectangle = (PTRectangle) getCurrentObject();
    if (num == 1)
      rectangle.setStartNode(p.x, p.y);
    if (num == 2) {
      Point firstNode = rectangle.getStartNode();
      rectangle.setSize(new Dimension(p.x - firstNode.x, p.y - firstNode.y));
    }
    return true;
  } // nextPoint;

  public int getMinDist(PTGraphicObject go, Point p) {
    PTRectangle pg = (PTRectangle) go;
    Point a = new Point(pg.getStartNode().x, pg.getStartNode().y);
    Rectangle boundingBox = pg.getBoundingBox();
    // if point is inside, there is not much of distance ;-)
    if (boundingBox.contains(p.x, p.y))
      return 0;

    // (ULC, URC)
    Point b = new Point(a.x + pg.getWidth(), a.y);
    int minDist = Integer.MAX_VALUE;
    int newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (URC, LRC)
    b.translate(0, pg.getHeight());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    // (LRC, LLC)
    a.translate(pg.getWidth(), pg.getHeight());
    newDist = MSMath.dist(p, a, b);
    if (newDist < minDist)
      minDist = newDist;

    newDist = MSMath.dist(p, a, pg.getStartNode());
    if (newDist < minDist)
      minDist = newDist;
    return minDist;
  }

  public EditPoint[] getEditPoints(PTGraphicObject go) {
    PTRectangle pg = (PTRectangle) go;
    // int pSize = 2;
    int width = pg.getWidth();
    int height = pg.getHeight();
    // int i;
    // add change points(nodes)
    EditPoint[] result = new EditPoint[5];
    Point helper = pg.getStartNode();
    // result[5] = new EditPoint(1, helper);
    helper = new Point(helper.x + width, helper.y + height);
    result[0] = new EditPoint(2, helper);

    int x = pg.getStartNode().x;
    int y = pg.getStartNode().y;
    result[1] = new EditPoint(-2, new Point(x + (width / 2), y));
    result[2] = new EditPoint(-3, new Point(x + width, y + (height / 2)));
    result[3] = new EditPoint(-4, new Point(x + (width / 2), y + height));
    result[4] = new EditPoint(-5, new Point(x, y + (height / 2)));

    return result;
  } // getEditPoints

  public void setProperties(XProperties props) {
    colorChooser.setColor(props.getColorProperty(PTRectangle.RECTANGLE_TYPE
        + ".color", Color.black));
    depthBox.setSelectedItem(props.getProperty(PTRectangle.RECTANGLE_TYPE
        + ".depth", "16"));
    fillColorChooser.setColor(props.getColorProperty(PTRectangle.RECTANGLE_TYPE
        + ".color", Color.black));
    filledCB.setSelected(props.getBoolProperty(PTRectangle.RECTANGLE_TYPE
        + ".filled"));
  }

  public void getProperties(XProperties props) {
    props.put(PTRectangle.RECTANGLE_TYPE + ".color", colorChooser.getColor());
    props.put(PTRectangle.RECTANGLE_TYPE + ".depth", depthBox.getSelectedItem());
    props.put(PTRectangle.RECTANGLE_TYPE + ".fillColor", fillColorChooser
        .getColor());
    props.put(PTRectangle.RECTANGLE_TYPE + ".filled", filledCB.isSelected());
  }

  /**
   * enable or disable some CheckBoxes according to whether the polyline is
   * closed or not
   */
  public void itemStateChanged(ItemEvent e) {
    PTRectangle p = (PTRectangle) getCurrentObject();

    if (e.getSource() == filledCB) {
      if (p != null)
        p.setFilled(filledCB.isSelected());
    }

    Animation.get().doChange();
    repaintNow();
  } // itemStateChanged

  public EditableObject createObject() {
    PTRectangle pg = new PTRectangle();
    storeAttributesInto(pg);
    return pg;
  }

  protected void storeAttributesInto(EditableObject eo) {
    super.storeAttributesInto(eo);
    PTRectangle p = (PTRectangle) eo;
    p.setColor(colorChooser.getColor());
    p.setFilled(filledCB.isSelected());
    p.setFillColor(fillColorChooser.getColor());
  }

  protected void extractAttributesFrom(EditableObject eo) {
    super.extractAttributesFrom(eo);
    PTRectangle p = (PTRectangle) eo;
    colorChooser.setColor(p.getColor());
    filledCB.setEnabled(true);
    filledCB.setSelected(p.isFilled());
    fillColorChooser.setColor(p.getFillColor());
  }

  public Editor getSecondaryEditor(EditableObject go) {
    RectangleEditor result = new RectangleEditor();
    // important! result must be of type RectangleEditor (or cast)
    // and the parameter passed must be of type PTRectangle.
    // Otherwise, not all attributes are copied!
    result.extractAttributesFrom(go);
    return result;
  }

  public String getStatusLineMsg() {
    return AnimalTranslator.translateMessage("RectangleEditor.statusLine",
        new Object[] { DrawCanvas.translateDrawButton(),
            DrawCanvas.translateFinishButton(),
            DrawCanvas.translateCancelButton() });
  }

  public void actionPerformed(ActionEvent e) {
    super.actionPerformed(e);
    PTRectangle p = (PTRectangle) getCurrentObject();

    if (p != null) {
      if (Animation.get() != null)
        Animation.get().doChange();
      repaintNow();
    }
  }

  public void propertyChange(PropertyChangeEvent event) {
    PTRectangle poly = (PTRectangle) getCurrentObject();
    String eventName = event.getPropertyName();
    if ("color".equals(eventName))
      poly.setColor((Color) event.getNewValue());
    else if ("fillColor".equals(eventName))
      poly.setFillColor((Color) event.getNewValue());
    if (!event.getOldValue().equals(event.getNewValue())) {
      repaintNow();
      if (Animation.get() != null)
        Animation.get().doChange();
    }
  }

  public String getBasicType() {
    return PTRectangle.RECTANGLE_TYPE;
  }
} // RectangleEditor
