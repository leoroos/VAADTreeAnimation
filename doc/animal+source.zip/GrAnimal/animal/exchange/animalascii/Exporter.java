/*
 * Created on 23.11.2006 by Guido Roessling (roessling@acm.org>
 */
package animal.exchange.animalascii;

/**
 * empty interface for exporting entries in Animal's ASCII format.
 * 
 * @author Guido Roessling (roessling@acm.org>
 * @version 0.7 05.09.2007
 */
public interface Exporter {
  // empty
}
