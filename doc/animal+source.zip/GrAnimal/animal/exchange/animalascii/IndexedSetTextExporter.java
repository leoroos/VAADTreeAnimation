package animal.exchange.animalascii;

public class IndexedSetTextExporter extends SetTextExporter {

}
