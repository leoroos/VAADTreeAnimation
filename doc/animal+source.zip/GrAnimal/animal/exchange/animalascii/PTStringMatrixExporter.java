package animal.exchange.animalascii;

import animal.graphics.PTMatrix;
import animal.graphics.PTText;

public class PTStringMatrixExporter extends PTMatrixExporter {

  @Override
  String getDataAt(int r, int c, PTMatrix matrix) {
    return "\"" + PTText.escapeText(matrix.getElementAt(r, c)) + "\"";
  }

}
